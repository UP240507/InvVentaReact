import { FileText } from 'lucide-react';
export default function FacturasScreen() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-black flex items-center gap-2"><FileText /> Facturación CFDI</h1>
      <p className="text-slate-500 mt-2">Emisión y consulta de facturas electrónicas.</p>
    </div>
  );
}