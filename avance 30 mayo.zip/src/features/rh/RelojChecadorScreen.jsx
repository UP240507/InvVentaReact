import { useState, useEffect } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { useSyncStore } from '../../store/useSyncStore';
import { Clock, Delete, CheckCircle, AlertTriangle, LogIn, LogOut, UserCircle } from 'lucide-react';

export default function RelojChecadorScreen() {
  const { staff, asistencias, configuracion } = useAppStore();
  const { enqueueAction } = useSyncStore();
  
  const [horaActual, setHoraActual] = useState(new Date());
  const [pin, setPin] = useState('');
  const [feedback, setFeedback] = useState(null);

  useEffect(() => {
    const timer = setInterval(() => setHoraActual(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleKeyClick = (numero) => {
    if (pin.length < 4) setPin(prev => prev + numero);
  };

  const handleBorrar = () => {
    setPin(prev => prev.slice(0, -1));
  };

  const registrarMovimiento = (tipoMovimiento) => {
    if (pin.length < 4) {
      mostrarFeedback('error', 'El PIN debe tener 4 dígitos.');
      return;
    }

    const empleado = (staff || []).find(s => s.pin === pin && s.activo !== false);
    
    if (!empleado) {
      mostrarFeedback('error', 'PIN incorrecto o empleado inactivo.');
      setPin('');
      return;
    }

    const hoyStr = new Date().toISOString().split('T')[0];
    const asistenciasHoy = (asistencias || []).filter(a => 
      a.empleado_id === empleado.id && a.fecha_hora?.startsWith(hoyStr)
    );

    const turnoAbierto = asistenciasHoy.find(a => a.tipo === 'Entrada' && !a.salida_id);

    if (tipoMovimiento === 'Entrada') {
      if (turnoAbierto) {
        mostrarFeedback('error', `Ya tienes una entrada registrada a las ${new Date(turnoAbierto.fecha_hora).toLocaleTimeString('es-MX', {hour:'2-digit', minute:'2-digit'})}.`);
        setPin('');
        return;
      }
      
      const nuevoRegistro = {
        id: Date.now(),
        empleado_id: empleado.id,
        empleado_nombre: empleado.nombre,
        tipo: 'Entrada',
        fecha_hora: new Date().toISOString(),
      };
      
      enqueueAction('asistencias', 'insert', nuevoRegistro);
      useAppStore.setState(prev => ({ asistencias: [nuevoRegistro, ...(prev.asistencias || [])] }));
      mostrarFeedback('success', 'Entrada registrada con éxito.', empleado.nombre);
    
    } else if (tipoMovimiento === 'Salida') {
      if (!turnoAbierto) {
        mostrarFeedback('error', 'No tienes una entrada activa para registrar salida.');
        setPin('');
        return;
      }

      const registroSalida = {
        id: Date.now(),
        empleado_id: empleado.id,
        empleado_nombre: empleado.nombre,
        tipo: 'Salida',
        fecha_hora: new Date().toISOString(),
        entrada_id: turnoAbierto.id 
      };

      const entradaActualizada = { ...turnoAbierto, salida_id: registroSalida.id };

      enqueueAction('asistencias', 'insert', registroSalida);
      enqueueAction('asistencias', 'upsert', entradaActualizada);
      
      useAppStore.setState(prev => ({
        asistencias: [
          registroSalida, 
          ...prev.asistencias.map(a => a.id === turnoAbierto.id ? entradaActualizada : a)
        ]
      }));
      mostrarFeedback('success', 'Salida registrada. ¡Buen turno!', empleado.nombre);
    }

    setPin('');
  };

  const mostrarFeedback = (tipo, mensaje, usuario = '') => {
    setFeedback({ tipo, mensaje, usuario });
    setTimeout(() => setFeedback(null), 3500); 
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-ui-obsidiana flex items-center justify-center p-6 transition-colors duration-500 relative">
      
      <div className="absolute inset-0 opacity-[0.03] dark:opacity-[0.05] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)', backgroundSize: '32px 32px' }}></div>

      <div className="max-w-5xl w-full grid grid-cols-1 lg:grid-cols-2 gap-10 items-center relative z-10">
        
        {/* RELOJ E INFO DE BRANDING */}
        <div className="flex flex-col items-center lg:items-start text-center lg:text-left space-y-6">
          <div className="bg-white dark:bg-ui-humo p-6 rounded-[2rem] border-2 border-slate-200 dark:border-ui-border shadow-xl inline-flex mb-4 transition-colors">
            <Clock className="w-12 h-12 text-brand-amatista" />
          </div>
          <h1 className="text-7xl lg:text-8xl font-black font-syne text-slate-900 dark:text-brand-nacar tracking-tighter tabular-nums leading-none transition-colors">
            {horaActual.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' })}
          </h1>
          <p className="text-xl font-bold text-slate-500 dark:text-ui-muted uppercase tracking-widest transition-colors">
            {horaActual.toLocaleDateString('es-MX', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
          
          {/* 🌟 AQUÍ SE INYECTA LA REGLA DE BRANDING COMBINADA */}
          <div className="pt-8">
            <p className="text-sm font-black text-brand-amatista uppercase tracking-widest truncate max-w-[300px]" title={configuracion?.nombre_empresa || 'Restaurante'}>
              {configuracion?.nombre_empresa || 'Restaurante'}
            </p>
            <p className="text-xs font-bold text-slate-400 dark:text-ui-muted transition-colors">
              InvVenta - Control de Acceso
            </p>
          </div>
        </div>

        {/* TERMINAL TÁCTIL */}
        <div className="bg-white/80 dark:bg-ui-humo/90 backdrop-blur-xl rounded-[3rem] border-2 border-slate-200 dark:border-ui-border shadow-2xl p-8 md:p-12 relative overflow-hidden transition-colors">
          
          {feedback && (
            <div className="absolute inset-0 z-50 bg-white/95 dark:bg-ui-humo/95 backdrop-blur-md flex flex-col items-center justify-center p-8 text-center animate-in mercantile duration-300">
              {feedback.tipo === 'success' ? (
                <>
                  <div className="w-24 h-24 bg-emerald-100 dark:bg-brand-cesped/20 rounded-full flex items-center justify-center mb-6">
                    <CheckCircle className="w-12 h-12 text-emerald-500 dark:text-brand-cesped" />
                  </div>
                  <p className="text-sm font-black text-slate-400 dark:text-ui-muted uppercase tracking-widest mb-2">Acceso Concedido</p>
                  <h2 className="text-3xl font-black font-syne text-slate-800 dark:text-brand-nacar mb-4">{feedback.usuario}</h2>
                  <p className="text-emerald-600 dark:text-brand-cesped font-bold text-lg">{feedback.mensaje}</p>
                </>
              ) : (
                <>
                  <div className="w-24 h-24 bg-rose-100 dark:bg-brand-arrecife/20 rounded-full flex items-center justify-center mb-6">
                    <AlertTriangle className="w-12 h-12 text-rose-500 dark:text-brand-arrecife" />
                  </div>
                  <h2 className="text-3xl font-black font-syne text-slate-800 dark:text-brand-nacar mb-4">Acceso Denegado</h2>
                  <p className="text-rose-600 dark:text-brand-arrecife font-bold text-lg">{feedback.mensaje}</p>
                </>
              )}
            </div>
          )}

          <div className="mb-8">
            <p className="text-center text-xs font-black text-slate-400 dark:text-ui-muted uppercase tracking-widest mb-4 transition-colors">Ingresa tu PIN personal</p>
            <div className="flex justify-center gap-4">
              {[0, 1, 2, 3].map(index => (
                <div key={index} className={`w-14 h-16 rounded-2xl flex items-center justify-center border-2 transition-all ${
                  pin.length > index 
                    ? 'border-brand-amatista bg-indigo-50 dark:bg-brand-amatista/10 shadow-[0_0_15px_rgba(139,92,246,0.3)]' 
                    : 'border-slate-200 dark:border-ui-border bg-slate-50 dark:bg-ui-obsidiana'
                }`}>
                  {pin.length > index && <div className="w-4 h-4 bg-brand-amatista rounded-full"></div>}
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 mb-8">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
              <button key={num} onClick={() => handleKeyClick(num.toString())}
                className="aspect-square text-3xl font-black font-syne text-slate-800 dark:text-brand-nacar bg-slate-50 dark:bg-ui-obsidiana border border-slate-200 dark:border-ui-border rounded-2xl hover:bg-slate-200 dark:hover:bg-ui-border active:scale-95 transition-all flex items-center justify-center shadow-sm"
              >
                {num}
              </button>
            ))}
            <button onClick={() => setPin('')} className="aspect-square text-sm font-black text-slate-500 dark:text-ui-muted bg-slate-100 dark:bg-ui-obsidiana/50 border border-transparent dark:border-ui-border rounded-2xl hover:bg-slate-200 dark:hover:bg-ui-border active:scale-95 transition-all flex items-center justify-center uppercase tracking-widest">
              Limpiar
            </button>
            <button onClick={() => handleKeyClick('0')} className="aspect-square text-3xl font-black font-syne text-slate-800 dark:text-brand-nacar bg-slate-50 dark:bg-ui-obsidiana border border-slate-200 dark:border-ui-border rounded-2xl hover:bg-slate-200 dark:hover:bg-ui-border active:scale-95 transition-all flex items-center justify-center shadow-sm">
              0
            </button>
            <button onClick={handleBorrar} disabled={pin.length === 0} className="aspect-square text-slate-500 dark:text-ui-muted bg-slate-100 dark:bg-ui-obsidiana/50 border border-transparent dark:border-ui-border rounded-2xl hover:text-brand-arrecife dark:hover:text-brand-arrecife active:scale-95 transition-all flex items-center justify-center disabled:opacity-50">
              <Delete className="w-8 h-8" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={() => registrarMovimiento('Entrada')}
              disabled={pin.length < 4}
              className="bg-emerald-500 hover:bg-emerald-600 dark:bg-brand-cesped dark:hover:bg-[#00c98c] disabled:bg-slate-200 dark:disabled:bg-ui-border disabled:text-slate-400 dark:disabled:text-ui-muted text-white dark:text-ui-obsidiana py-5 rounded-2xl font-black shadow-lg dark:shadow-[0_0_20px_rgba(0,229,160,0.2)] disabled:shadow-none active:scale-95 transition-all flex flex-col items-center justify-center gap-1"
            >
              <LogIn className="w-6 h-6 mb-1" />
              <span className="uppercase tracking-widest text-[10px]">Registrar</span>
              <span className="text-lg leading-none">Entrada</span>
            </button>

            <button 
              onClick={() => registrarMovimiento('Salida')}
              disabled={pin.length < 4}
              className="bg-slate-800 hover:bg-slate-900 dark:bg-brand-arrecife dark:hover:bg-orange-600 disabled:bg-slate-200 dark:disabled:bg-ui-border disabled:text-slate-400 dark:disabled:text-ui-muted text-white dark:text-ui-obsidiana py-5 rounded-2xl font-black shadow-lg dark:shadow-[0_0_20px_rgba(255,95,64,0.2)] disabled:shadow-none active:scale-95 transition-all flex flex-col items-center justify-center gap-1"
            >
              <LogOut className="w-6 h-6 mb-1" />
              <span className="uppercase tracking-widest text-[10px]">Registrar</span>
              <span className="text-lg leading-none">Salida</span>
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}