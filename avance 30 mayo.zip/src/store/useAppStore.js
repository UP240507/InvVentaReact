import { create } from 'zustand';
import { supabase } from '../api/supabase';
import { useAuthStore } from '../features/auth/useAuthStore';
import { localDB } from './localDB';

export const useAppStore = create((set, get) => ({
  // ─── 1. ESTADO GLOBAL (RAM) ──────────────────────────────────────────────
  isLoading: false,           // ✅ FIX #3: estaba ausente → App.jsx siempre veía undefined
  toast: null,                // ✅ FIX #1: estaba ausente → todas las notificaciones eran invisibles
  temaGlobal: localStorage.getItem('theme') || 'light', // ✅ FIX #5: requerido por PerfilScreen

  configuracion: null,
  productos: [],
  recetas: [],
  mesas: [],
  ventas: [],
  proveedores: [],
  usuarios: [],
  movimientos: [],
  turnos: [],
  ordenesCompra: [],
  facturas: [],
  modificadores: [],
  staff: [],
  nominas: [],
  roles_permisos: [],
  clientes: [],
  auditoria: [],
  asistencias: [],
  comandas_activas: [],

  // ─── 2. CARGA INICIAL (ONLINE / OFFLINE HYBRID) ────────────────────────
  fetchInitialData: async () => {
    set({ isLoading: true });

    // ✅ TENANT GUARD: sin restaurante_id no cargamos nada
    const restauranteId = useAuthStore.getState().restauranteId;
    if (!restauranteId) {
      console.error('❌ [Store] fetchInitialData llamado sin restaurante_id. Abortando.');
      set({ isLoading: false });
      return;
    } // ✅ FIX #3

    try {
      if (navigator.onLine) {
        console.log('🌐 [Network] Sincronizando con Supabase...');

        const [
          { data: confData }, { data: prodData }, { data: recData },
          { data: mesasData }, { data: ventasData }, { data: provData },
          { data: usersData }, { data: movData }, { data: turnosData },
          { data: ocData }, { data: factData }, { data: modifData },
          { data: staffData }, { data: nominasData }, { data: rolesData },
          { data: clientesData }, { data: auditoriaData }, { data: asistenciasData },
          { data: comandasData }
        ] = await Promise.all([
          supabase.from('configuracion').select('*').eq('restaurante_id', restauranteId).single(),
          supabase.from('productos').select('*').eq('restaurante_id', restauranteId).eq('activo', true),
          supabase.from('recetas').select('*').eq('restaurante_id', restauranteId).eq('activo', true),
          supabase.from('mesas').select('*').eq('restaurante_id', restauranteId),
          supabase.from('ventas').select('*').eq('restaurante_id', restauranteId).order('fecha', { ascending: false }).limit(500),
          supabase.from('proveedores').select('*').eq('restaurante_id', restauranteId).eq('activo', true),
          supabase.from('usuarios').select('*').eq('restaurante_id', restauranteId),
          supabase.from('movimientos').select('*').eq('restaurante_id', restauranteId).order('fecha', { ascending: false }).limit(500),
          supabase.from('turnos').select('*').eq('restaurante_id', restauranteId).order('fecha_apertura', { ascending: false }),
          supabase.from('ordenes_compra').select('*').eq('restaurante_id', restauranteId),
          supabase.from('facturas').select('*').eq('restaurante_id', restauranteId),
          supabase.from('modificadores').select('*').eq('restaurante_id', restauranteId),
          supabase.from('staff').select('*').eq('restaurante_id', restauranteId),
          supabase.from('nominas').select('*').eq('restaurante_id', restauranteId),
          supabase.from('roles_permisos').select('*').eq('restaurante_id', restauranteId),
          supabase.from('clientes').select('*').eq('restaurante_id', restauranteId),
          supabase.from('auditoria').select('*').eq('restaurante_id', restauranteId).order('fecha', { ascending: false }).limit(200),
          supabase.from('asistencias').select('*').eq('restaurante_id', restauranteId).order('fecha_hora', { ascending: false }),
          supabase.from('comandas').select('*').eq('restaurante_id', restauranteId).neq('estado', 'completada').order('fecha_hora', { ascending: true })
        ]);

        const payload = {
          configuracion: confData || null, productos: prodData || [], recetas: recData || [],
          mesas: mesasData || [], ventas: ventasData || [], proveedores: provData || [],
          usuarios: usersData || [], movimientos: movData || [], turnos: turnosData || [],
          ordenesCompra: ocData || [], facturas: factData || [], modificadores: modifData || [],
          staff: staffData || [], nominas: nominasData || [], roles_permisos: rolesData || [],
          clientes: clientesData || [], auditoria: auditoriaData || [], asistencias: asistenciasData || [],
          comandas_activas: comandasData || []
        };

        set(payload);

        // 🌟 Backup silencioso en Dexie (Modo Offline)
        const safe = (arr) => arr || [];
        await localDB.transaction('rw',
          localDB.configuracion, localDB.productos, localDB.recetas, localDB.mesas,
          localDB.ventas, localDB.proveedores, localDB.usuarios, localDB.movimientos,
          localDB.turnos, localDB.ordenes_compra, localDB.facturas, localDB.modificadores,
          localDB.staff, localDB.nominas, localDB.roles_permisos, localDB.clientes,
          localDB.auditoria, localDB.asistencias, localDB.comandas,
          async () => {
            if (confData) await localDB.configuracion.put(confData);
            await localDB.productos.bulkPut(safe(prodData));
            await localDB.recetas.bulkPut(safe(recData));
            await localDB.mesas.bulkPut(safe(mesasData));
            await localDB.ventas.bulkPut(safe(ventasData));
            await localDB.proveedores.bulkPut(safe(provData));
            await localDB.usuarios.bulkPut(safe(usersData));
            await localDB.movimientos.bulkPut(safe(movData));
            await localDB.turnos.bulkPut(safe(turnosData));
            await localDB.ordenes_compra.bulkPut(safe(ocData));
            await localDB.facturas.bulkPut(safe(factData));
            await localDB.modificadores.bulkPut(safe(modifData));
            await localDB.staff.bulkPut(safe(staffData));
            await localDB.nominas.bulkPut(safe(nominasData));
            await localDB.roles_permisos.bulkPut(safe(rolesData));
            await localDB.clientes.bulkPut(safe(clientesData));
            await localDB.auditoria.bulkPut(safe(auditoriaData));
            await localDB.asistencias.bulkPut(safe(asistenciasData));
            await localDB.comandas.bulkPut(safe(comandasData));
          }
        );

      } else {
        console.log('⚠️ [Network] Modo Offline: Rescatando estado desde Dexie...');
        set({
          configuracion: await localDB.configuracion.toCollection().first() || null,
          productos: await localDB.productos.toArray(),
          recetas: await localDB.recetas.toArray(),
          mesas: await localDB.mesas.toArray(),
          ventas: await localDB.ventas.toArray(),
          proveedores: await localDB.proveedores.toArray(),
          usuarios: await localDB.usuarios.toArray(),
          movimientos: await localDB.movimientos.toArray(),
          turnos: await localDB.turnos.toArray(),
          ordenesCompra: await localDB.ordenes_compra.toArray(),
          facturas: await localDB.facturas.toArray(),
          modificadores: await localDB.modificadores.toArray(),
          staff: await localDB.staff.toArray(),
          nominas: await localDB.nominas.toArray(),
          roles_permisos: await localDB.roles_permisos.toArray(),
          clientes: await localDB.clientes.toArray(),
          auditoria: await localDB.auditoria.toArray(),
          asistencias: await localDB.asistencias.toArray(),
          comandas_activas: await localDB.comandas.toArray()
        });
      }
    } catch (error) {
      console.error('❌ [Store] Falla crítica cargando datos:', error);
    } finally {
      set({ isLoading: false }); // ✅ FIX #3: siempre libera el spinner
    }
  },

  // ─── 3. MOTORES KDS (REALTIME) ───────────────────────────────────────────
  iniciarSuscripcionKDS: () => {
    console.log('📡 [KDS] Túnel WebSocket abierto...');
    const suscripcion = supabase
      .channel('kds-channel')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'comandas' }, (payload) => {
        const comanda = payload.new;
        if (payload.eventType === 'INSERT') {
          set(state => {
            if (state.comandas_activas.find(c => c.id === comanda.id)) return state;
            return { comandas_activas: [...state.comandas_activas, comanda] };
          });
        }
        if (payload.eventType === 'UPDATE') {
          set(state => ({
            comandas_activas: state.comandas_activas.map(c => c.id === comanda.id ? comanda : c)
          }));
        }
        if (payload.eventType === 'DELETE') {
          set(state => ({
            comandas_activas: state.comandas_activas.filter(c => c.id !== payload.old.id)
          }));
        }
      })
      .subscribe();
    return suscripcion;
  },

  registrarComandaKDS: (nuevaComanda) => {
    set(state => ({ comandas_activas: [...state.comandas_activas, nuevaComanda] }));
  },

  // ─── 4. SEGURIDAD Y AUDITORÍA ────────────────────────────────────────────
  registrarAuditoria: async (logInfo) => {
    const logCompleto = {
      id: logInfo.id || Date.now(),
      fecha: logInfo.fecha || new Date().toISOString(),
      usuario: logInfo.usuario || 'Sistema',
      accion: logInfo.accion || 'ACCIÓN_DESCONOCIDA',
      modulo: logInfo.modulo || 'GENERAL',
      detalles: logInfo.detalles || '',
      nivel: logInfo.nivel || 'info'
    };

    set(state => ({ auditoria: [logCompleto, ...(state.auditoria || [])] }));

    try {
      await localDB.auditoria.put(logCompleto);
      if (navigator.onLine) {
        const { id, ...logParaSupabase } = logCompleto;
        supabase.from('auditoria').insert(logParaSupabase).then(({ error }) => {
          if (error) console.error('⚠️ Error subiendo auditoría:', error.message);
        });
      }
    } catch (err) {
      console.error('⚠️ Error guardando auditoría:', err);
    }
  },

  // ─── 5. LÓGICA DE NEGOCIO Y FINANZAS ─────────────────────────────────────
  getRestauranteId: () => {
    return useAuthStore.getState().restauranteId;
  },

  getIva: () => {
    return get().configuracion?.iva || 0.16;
  },

  cerrarTurno: async (datosCierre) => {
    // ✅ FIX: buscamos el turno ACTIVO y lo mutamos — no creamos uno nuevo
    const turnoActivo = get().turnos.find(t => t.estado === 'abierto');
    if (!turnoActivo) {
      console.warn('[cerrarTurno] No hay turno abierto para cerrar.');
      return;
    }

    const turnoCerrado = {
      ...turnoActivo,
      usuario_cierre:   datosCierre.usuario,
      fecha_cierre:     new Date().toISOString(),
      ventas_totales:   datosCierre.ventasTotales,
      propinas_totales: datosCierre.propinasTotales,
      estado:           'cerrado',
    };

    // ✅ FIX: actualiza el turno existente en el array local (no prepend)
    set(state => ({
      turnos: state.turnos.map(t => t.id === turnoActivo.id ? turnoCerrado : t)
    }));

    try {
      const { localDB } = await import('./localDB');
      await localDB.turnos.put(turnoCerrado);

      if (navigator.onLine) {
        await supabase
          .from('turnos')
          .update({
            usuario_cierre:   turnoCerrado.usuario_cierre,
            fecha_cierre:     turnoCerrado.fecha_cierre,
            ventas_totales:   turnoCerrado.ventas_totales,
            propinas_totales: turnoCerrado.propinas_totales,
            estado:           'cerrado',
          })
          .eq('id', turnoActivo.id);
      }

      get().registrarAuditoria({
        id: Date.now(), fecha: new Date().toISOString(),
        usuario: datosCierre.usuario, accion: 'CIERRE_TURNO',
        modulo: 'CAJA', nivel: 'warning',
        detalles: `Turno #${turnoActivo.id} cerrado. Ventas: $${datosCierre.ventasTotales}`
      });
    } catch (err) {
      console.error('Error cerrando turno:', err);
    }
  },

  // ── ABRIR TURNO ────────────────────────────────────────────────────────────
  abrirTurno: async (datosApertura) => {
    const restauranteId = useAuthStore.getState().restauranteId;

    const turnoNuevo = {
      id: Date.now(),
      folio: `TUR-${Date.now().toString().slice(-5)}`,
      usuario_apertura: datosApertura.usuario,
      fecha_apertura: new Date().toISOString(),
      fondo_caja: datosApertura.fondoCaja || 0,
      estado: 'abierto',
      restaurante_id: restauranteId,
    };

    // Primero cerramos cualquier turno abierto huérfano (safety)
    set(state => ({
      turnos: [
        turnoNuevo,
        ...state.turnos.map(t =>
          t.estado === 'abierto' ? { ...t, estado: 'cerrado_forzado' } : t
        )
      ]
    }));

    try {
      const { localDB } = await import('./localDB');
      await localDB.turnos.put(turnoNuevo);
      if (navigator.onLine) {
        const { supabase } = await import('../api/supabase');
        await supabase.from('turnos').insert(turnoNuevo);
      }
      get().registrarAuditoria({
        id: Date.now(), fecha: new Date().toISOString(),
        usuario: datosApertura.usuario, accion: 'APERTURA_TURNO',
        modulo: 'CAJA', nivel: 'info',
        detalles: `Turno abierto. Fondo: $${datosApertura.fondoCaja || 0}`
      });
    } catch (err) {
      console.error('Error abriendo turno:', err);
    }
  },

  // Selector derivado — lo usan guards y componentes
  getTurnoActivo: () => {
    return get().turnos.find(t => t.estado === 'abierto') || null;
  },

  descontarStock: (itemsVendidos) => {
    const { productos } = get();
    let actualizados = [...productos];

    itemsVendidos.forEach(item => {
      const prodIdx = actualizados.findIndex(p => String(p.id) === String(item.id || item.id_producto));
      if (prodIdx !== -1) {
        const prod = actualizados[prodIdx];
        const cant = Number(item.cantidad) || 1;
        const nuevoStock = Math.max(0, Number(prod.stock) - cant);
        actualizados[prodIdx] = { ...prod, stock: nuevoStock };

        localDB.productos.put(actualizados[prodIdx]);
        if (navigator.onLine) {
          supabase.from('productos').update({ stock: nuevoStock }).eq('id', prod.id).then();
        }
      }
    });

    set({ productos: actualizados });
  },

  // ─── 6. HELPERS UI Y CRUD RÁPIDOS ────────────────────────────────────────

  // ✅ FIX #1: showToast ahora setea estado real con auto-dismiss
  showToast: (mensaje, tipo = 'info') => {
    set({ toast: { msg: mensaje, type: tipo } });
    // Auto-dismiss a los 3.5 segundos
    setTimeout(() => set({ toast: null }), 3500);
  },

  // ✅ FIX #5: toggleTemaGlobal requerido por PerfilScreen
  toggleTemaGlobal: () => {
    const { temaGlobal } = get();
    const nuevoTema = temaGlobal === 'dark' ? 'light' : 'dark';
    if (nuevoTema === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('theme', nuevoTema);
    set({ temaGlobal: nuevoTema });
  },

  // ✅ FIX #5: updateConfiguracion requerido por ZonasImpresionScreen y ConfiguracionScreen
  updateConfiguracion: (payload) => {
    const restauranteId = useAuthStore.getState().restauranteId;
    const data = { ...payload, restaurante_id: restauranteId };
    set({ configuracion: data });
    localDB.configuracion.put(data);
    if (navigator.onLine) {
      supabase.from('configuracion').upsert(data).then(({ error }) => {
        if (error) console.error('⚠️ Error guardando configuración:', error.message);
      });
    }
  },

  // ✅ Patrón correcto: filter + prepend (evita clones fantasma)
  upsertStaff: (empleado) => {
    set(state => ({
      staff: [empleado, ...state.staff.filter(s => s.id !== empleado.id)]
    }));
  },

  // ✅ Acción centralizada para clientes (evita useAppStore.setState directo en componentes)
  upsertCliente: (cliente) => {
    set(state => ({
      clientes: [cliente, ...state.clientes.filter(c => String(c.id) !== String(cliente.id))]
    }));
  },

  // ✅ Acción centralizada para proveedores
  upsertProveedor: (proveedor) => {
    set(state => ({
      proveedores: [proveedor, ...state.proveedores.filter(p => p.id !== proveedor.id)]
    }));
  },

  // ✅ Acción centralizada para roles/permisos
  upsertRolPermiso: (rol) => {
    set(state => ({
      roles_permisos: [rol, ...state.roles_permisos.filter(r => r.id !== rol.id)]
    }));
  },
}));