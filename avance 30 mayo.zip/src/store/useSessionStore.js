import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { useAppStore } from './useAppStore';

// ─── RUTAS PERMITIDAS POR ROL ─────────────────────────────────────────────────
export const RUTAS_POR_ROL = {
  Admin: '*', // acceso total
  Gerente: [
    'dashboard',
    'mesas',
    'pos',
    'kds',
    'propinas',
    'ingredientes',
    'compras',
    'recepcion',
    'mermas',
    'proveedores',
    'empleados',
    'asistencias',
    'nominas',
    'permisos',
    'clientes',
    'reportes',
    'facturas',
    'zonas-produccion',
    'auditoria',
    'perfil',
  ],
  Cajero: ['pos', 'mesas', 'facturas', 'perfil'],
  Mesero: ['mesas', 'pos', 'perfil'],
  Chef: ['kds', 'perfil'],
  Barista: ['kds', 'perfil'],
};

// Ruta de aterrizaje al entrar según rol
export const RUTA_INICIAL_POR_ROL = {
  Admin: '/dashboard',
  Gerente: '/dashboard',
  Cajero: '/pos',
  Mesero: '/mesas',
  Chef: '/kds',
  Barista: '/kds',
};

export const useSessionStore = create(
  persist(
    (set, get) => ({
      // ── ESTADO DE EMPLEADO (RBAC) ───────────────────────────────────────
      empleadoActivo: null,
      horaEntrada: null,

      // ── ESTADO DE TURNO DE CAJA ─────────────────────────────────────────
      turnoActivo: null,

      // ── ABRIR / CERRAR SESIÓN DE EMPLEADO (Checador) ────────────────────
      abrirSesionEmpleado: (empleado) => {
        set({
          empleadoActivo: empleado,
          horaEntrada: new Date().toISOString(),
        });
      },

      cerrarSesionEmpleado: () => {
        set({ empleadoActivo: null, horaEntrada: null });
      },

      // ── ABRIR / CERRAR TURNO DE CAJA (Dashboard) ────────────────────────
      abrirTurno: (turnoData) => {
        set({ turnoActivo: turnoData });
      },

      cerrarTurno: () => {
        set({ turnoActivo: null });
      },

      // ── GUARDIA: ¿puede el empleado acceder a esta ruta? ────────────────
      puedeAcceder: (ruta) => {
        const { empleadoActivo } = get();
        if (!empleadoActivo) return false;

        const rol = empleadoActivo.rol || 'Mesero';

        if (rol === 'Admin') return true;

        const rutaLimpia = ruta.replace(/^\//, '').split('/')[0] || 'dashboard';

        const permitidas = RUTAS_POR_ROL[rol] || RUTAS_POR_ROL['Mesero'];
        return permitidas.includes(rutaLimpia);
      },

      // ── GUARDIA: ¿hay turno de caja abierto? ────────────────────────────
      hayTurnoActivo: () => {
        const { empleadoActivo, turnoActivo } = get();
        if (!empleadoActivo) return false;

        const rol = empleadoActivo.rol || 'Mesero';

        // Admin y Gerente bypasean esta validación para ver reportes
        if (['Admin', 'Gerente'].includes(rol)) return true;

        // Validamos primero el turno local de la terminal.
        // Opcional: hacemos fallback a la base de datos si es terminal compartida.
        const turnosBD = useAppStore.getState().turnos || [];
        const hayTurnoEnBD = turnosBD.some((t) => t.estado === 'abierto');

        return turnoActivo !== null || hayTurnoEnBD;
      },

      // ── HELPER: ruta inicial según rol del empleado ──────────────────────
      getRutaInicial: () => {
        const { empleadoActivo } = get();
        if (!empleadoActivo) return '/checador';
        return RUTA_INICIAL_POR_ROL[empleadoActivo.rol] || '/mesas';
      },
    }),
    {
      name: 'session-empleado',
      partialize: (state) => ({
        // 🌟 IMPORTANTE: Persistir la triada operativa completa
        empleadoActivo: state.empleadoActivo,
        horaEntrada: state.horaEntrada,
        turnoActivo: state.turnoActivo,
      }),
    },
  ),
);
