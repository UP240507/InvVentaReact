import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { useAppStore } from './store/useAppStore';
import { useAuthStore } from './features/auth/useAuthStore';
import { useNetworkListener } from './hooks/useNetworkListener';

// 🌟 CONTENEDOR PRINCIPAL
import SidebarLayout from './components/SidebarLayout';

// 🌟 PANTALLAS
import LoginScreen from './features/auth/LoginScreen';
import PerfilScreen from './features/auth/PerfilScreen';
import DashboardScreen from './features/dashboard/DashboardScreen';
import MesasScreen from './features/operacion/MesasScreen';
import PosScreen from './features/pos/PosScreen';
import KdsScreen from './features/kds/KdsScreen';
import PropineroScreen from './features/operacion/PropineroScreen';
import RecetasScreen from './features/catalogos/RecetasScreen';
import ModificadoresScreen from './features/catalogos/ModificadoresScreen';
import IngredientesScreen from './features/catalogos/IngredientesScreen';
import ComprasScreen from './features/compras/ComprasScreen';
import RecepcionScreen from './features/compras/RecepcionScreen';
import MermasScreen from './features/inventario/MermasScreen';
import ProveedoresScreen from './features/inventario/ProveedoresScreen';
import EmpleadosScreen from './features/rh/EmpleadosScreen';
import RelojChecadorScreen from './features/rh/RelojChecadorScreen';
import NominasScreen from './features/rh/NominasScreen';
import PermisosScreen from './features/rh/PermisosScreen';
import ClientesScreen from './features/crm/ClientesScreen';
import ReportesScreen from './features/analisis/ReportesScreen';
import FacturasScreen from './features/analisis/FacturasScreen';
import ConfiguracionScreen from './features/ajustes/ConfiguracionScreen';
import AuditoriaScreen from './features/ajustes/AuditoriaScreen';
import ZonasImpresionScreen from './features/ajustes/ZonasImpresionScreen';

// 🛡️ GUARD: redirige a /login si no hay sesión activa
function ProtectedRoute() {
  const user = useAuthStore((state) => state.user);
  return user ? <Outlet /> : <Navigate to="/login" replace />;
}

export default function App() {
  useNetworkListener();

  const checkSession = useAuthStore((state) => state.checkSession);
  const authLoading  = useAuthStore((state) => state.isLoading);

  const fetchInitialData = useAppStore((state) => state.fetchInitialData);
  const dataLoading      = useAppStore((state) => state.isLoading);

  // 🌟 MOTOR DEL TEMA GLOBAL 🌟
  useEffect(() => {
    const isDark = localStorage.getItem('theme') === 'dark' || 
      (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches);
    
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  useEffect(() => { if(checkSession) checkSession(); }, [checkSession]);
  useEffect(() => { if(fetchInitialData) fetchInitialData(); }, [fetchInitialData]);

  if (authLoading || dataLoading) {
    return (
      <div className="h-screen w-screen bg-brand-nacar dark:bg-ui-obsidiana flex flex-col items-center justify-center text-ui-obsidiana dark:text-brand-nacar transition-colors duration-500">
        <div className="w-12 h-12 border-4 border-brand-arrecife border-t-transparent rounded-full animate-spin mb-4"></div>
        <h2 className="text-xl font-bold font-syne tracking-widest uppercase">Arrancando AZUL ERP...</h2>
      </div>
    );
  }

  return (
    // 🌟 FONDO GLOBAL DINÁMICO 🌟
    <div className="bg-brand-nacar dark:bg-ui-obsidiana text-ui-obsidiana dark:text-ui-text min-h-screen transition-colors duration-500 font-sans"> 
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginScreen />} />

          <Route element={<ProtectedRoute />}>
            <Route element={<SidebarLayout />}>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/dashboard" element={<DashboardScreen />} />
              <Route path="/perfil" element={<PerfilScreen />} />
              <Route path="/mesas" element={<MesasScreen />} />
              <Route path="/pos" element={<PosScreen />} />
              <Route path="/kds" element={<KdsScreen />} />
              <Route path="/propinas" element={<PropineroScreen />} />
              <Route path="/ingredientes" element={<IngredientesScreen />} />
              <Route path="/recetas" element={<RecetasScreen />} />
              <Route path="/modificadores" element={<ModificadoresScreen />} />
              <Route path="/compras" element={<ComprasScreen />} />
              <Route path="/recepcion" element={<RecepcionScreen />} />
              <Route path="/mermas" element={<MermasScreen />} />
              <Route path="/proveedores" element={<ProveedoresScreen />} />
              <Route path="/empleados" element={<EmpleadosScreen />} />
              <Route path="/asistencias" element={<RelojChecadorScreen />} />
              <Route path="/nominas" element={<NominasScreen />} />
              <Route path="/permisos" element={<PermisosScreen />} />
              <Route path="/clientes" element={<ClientesScreen />} />
              <Route path="/reportes" element={<ReportesScreen />} />
              <Route path="/facturas" element={<FacturasScreen />} />
              <Route path="/zonas-produccion" element={<ZonasImpresionScreen />} />
              <Route path="/auditoria" element={<AuditoriaScreen />} />
              <Route path="/configuracion" element={<ConfiguracionScreen />} />
              <Route path="/inventario" element={<Navigate to="/ingredientes" replace />} />
              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Route>
          </Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}