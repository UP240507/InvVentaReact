import { useState } from 'react';
import { useAuthStore } from './useAuthStore';
import { useNavigate } from 'react-router-dom';
import { Lock, Mail, WifiOff, ArrowRight, ShieldCheck } from 'lucide-react';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuthStore();
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      navigate('/dashboard');
    } catch (err) {
      alert(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-brand-bg dark:bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden">
      
      {/* ─── ISOTIPO DE FONDO (Marca de Agua) ─── */}
      <div className="absolute -bottom-20 -right-20 opacity-[0.03] dark:opacity-[0.05] pointer-events-none">
        <img src="./brand/Isotipo (1).png" alt="" className="w-[600px] h-[600px]" />
      </div>

      <div className="w-full max-w-md z-10">
        {/* LOGO PRINCIPAL */}
        <div className="flex flex-col items-center mb-10">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-brand shadow-xl mb-4">
             <img src="./brand/Logotipo.png" alt="InvVenta Logo" className="h-12 w-auto" />
          </div>
          <h2 className="text-2xl font-black text-brand-primary dark:text-ui-text tracking-tight">Bienvenido de nuevo</h2>
          <p className="text-slate-500 dark:text-slate-400 font-bold text-sm uppercase tracking-widest mt-2">AZUL Restaurante</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-2xl border border-slate-100 dark:border-slate-800">
          
          {/* INDICADOR OFFLINE */}
          {!navigator.onLine && (
            <div className="mb-6 flex items-center gap-3 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-2xl text-amber-700 dark:text-amber-400 text-xs font-black uppercase tracking-widest animate-pulse">
              <WifiOff className="w-4 h-4" /> Modo Offline Activado
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Correo Electrónico</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input 
                  type="email" required value={email} onChange={e => setEmail(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-brand-primary dark:focus:border-indigo-500 rounded-2xl font-bold text-ui-text dark:text-ui-text outline-none transition-all"
                  placeholder="admin@azul.com"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Contraseña</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input 
                  type="password" required value={password} onChange={e => setPassword(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-brand-primary dark:focus:border-indigo-500 rounded-2xl font-bold text-ui-text dark:text-ui-text outline-none transition-all"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button 
              disabled={loading}
              className="w-full bg-brand-primary hover:bg-brand-accent text-ui-text py-5 rounded-2xl font-black shadow-lg shadow-brand-primary/20 flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
            >
              {loading ? 'Validando...' : (
                <>
                  Entrar al Sistema <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </form>
        </div>

        <p className="text-center mt-8 text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center justify-center gap-2">
          <ShieldCheck className="w-3 h-3" /> Seguridad Encriptada por InvVenta
        </p>
      </div>
    </div>
  );
}