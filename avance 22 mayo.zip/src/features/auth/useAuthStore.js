import { create } from 'zustand';
import { supabase } from '../../api/supabase';

export const useAuthStore = create((set) => ({
  user: null,       // Datos de tu tabla 'usuarios' (rol, nombre, etc.)
  session: null,    // Token de Supabase
  isLoading: true,  // Estado de carga inicial
  error: null,

  // 1. Verificar si ya hay sesión al recargar la página
  checkSession: async () => {
    try {
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) throw sessionError;

      if (session) {
        // Extraemos el username del email (ej. cajero@tuapp.com -> cajero)
        const username = session.user.email.split('@')[0].toLowerCase().trim();
        
        // Buscamos su rol en tu tabla 'usuarios'
        const { data: userData } = await supabase
          .from('usuarios')
          .select('*')
          .ilike('username', username)
          .single();

        set({ session, user: userData || null, isLoading: false });
      } else {
        set({ session: null, user: null, isLoading: false });
      }
    } catch (error) {
      console.error("Error validando sesión:", error.message);
      set({ session: null, user: null, isLoading: false });
    }
  },

  // 2. Función de Login manual
  login: async (email, password) => {
    set({ isLoading: true, error: null });
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;

      const username = data.user.email.split('@')[0].toLowerCase().trim();
      const { data: userData } = await supabase
        .from('usuarios')
        .select('*')
        .ilike('username', username)
        .single();

      set({ session: data.session, user: userData, isLoading: false });
      return true;
    } catch (error) {
      set({ error: error.message, isLoading: false });
      return false;
    }
  },

  // 3. Cerrar sesión
  logout: async () => {
    set({ isLoading: true });
    await supabase.auth.signOut();
    set({ session: null, user: null, isLoading: false });
  }
}));