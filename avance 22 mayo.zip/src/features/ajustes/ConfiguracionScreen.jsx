import { useState } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { useSyncStore } from '../../store/useSyncStore';
import { Settings, Building2, Receipt, Percent, Tag, Plus, X, CheckCircle } from 'lucide-react';

const TABS = [
  { id: 'restaurante', label: 'Restaurante', icon: Building2 },
  { id: 'fiscal', label: 'Fiscal / IVA', icon: Percent },
  { id: 'categorias', label: 'Categorías', icon: Tag },
  { id: 'tickets', label: 'Tickets', icon: Receipt },
];

export default function ConfiguracionScreen() {
  const { configuracion } = useAppStore();
  const { enqueueAction } = useSyncStore();

  const conf = configuracion || {};
  const [tab, setTab] = useState('restaurante');
  
  // 🌟 Estado ampliado con opciones de ticket
  const [form, setForm] = useState({
    nombre_empresa:    conf.nombre_empresa || '',
    rfc:               conf.rfc || '',
    telefono:          conf.telefono || '',
    direccion:         conf.direccion || '',
    iva:               (conf.iva !== undefined ? conf.iva * 100 : 16),
    encabezado_ticket: conf.encabezado_ticket || '',
    mensaje_ticket:    conf.mensaje_ticket || '¡Gracias por su preferencia!',
    mostrar_propinas:  conf.mostrar_propinas ?? true, // Toggle para sugerencia de propina
  });
  
  const [categorias, setCategorias] = useState(conf.categorias || []);
  const [unidades, setUnidades] = useState(conf.unidades || []);
  const [nuevaCat, setNuevaCat] = useState('');
  const [nuevaUni, setNuevaUni] = useState('');
  const [toast, setToast] = useState(null);

  const showT = (msg) => { setToast(msg); setTimeout(() => setToast(null), 3000); };

  const guardar = (e) => {
    e.preventDefault();
    const nueva = {
      ...conf,
      ...form,
      iva: parseFloat(form.iva) / 100,
      categorias,
      unidades,
    };
    useAppStore.setState({ configuracion: nueva });
    enqueueAction('configuracion', 'upsert', nueva);
    showT('Configuración guardada exitosamente');
  };

  const agregarCat = () => {
    if (!nuevaCat.trim() || categorias.includes(nuevaCat.trim())) return;
    setCategorias([...categorias, nuevaCat.trim()]);
    setNuevaCat('');
  };

  const quitarCat = (c) => setCategorias(categorias.filter(x => x !== c));

  const agregarUni = () => {
    if (!nuevaUni.trim() || unidades.includes(nuevaUni.trim())) return;
    setUnidades([...unidades, nuevaUni.trim()]);
    setNuevaUni('');
  };

  const quitarUni = (u) => setUnidades(unidades.filter(x => x !== u));

  const Field = ({ label, field, type = 'text', placeholder }) => (
    <div>
      <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1.5">{label}</label>
      <input type={type} value={form[field] || ''} onChange={e => setForm({...form, [field]: e.target.value})}
        placeholder={placeholder}
        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-medium text-sm outline-none focus:ring-2 focus:ring-indigo-500 transition-all" />
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8 font-sans relative">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* CABECERA */}
        <div className="flex items-center gap-4">
          <div className="bg-slate-200 p-3.5 rounded-2xl"><Settings className="w-7 h-7 text-slate-700" /></div>
          <div>
            <h1 className="text-2xl font-black text-ui-text">Configuración Global</h1>
            <p className="text-slate-500 text-sm font-medium">Datos del restaurante, fiscal y diseño de tickets</p>
          </div>
        </div>

        {/* CONTENEDOR PRINCIPAL */}
        <div className="bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden flex flex-col md:flex-row min-h-[600px]">
          
          {/* SIDEBAR TABS */}
          <div className="w-full md:w-64 bg-slate-50 border-r border-slate-100 p-4 space-y-2 shrink-0">
            {TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`w-full flex items-center gap-3 px-4 py-3.5 text-sm font-bold rounded-xl transition-all ${tab === t.id ? 'bg-indigo-600 text-ui-text shadow-md' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50'}`}>
                <t.icon className="w-5 h-5" /> {t.label}
              </button>
            ))}
          </div>

          {/* ÁREA DE FORMULARIO */}
          <form onSubmit={guardar} className="flex-1 p-6 md:p-8 flex flex-col h-full">
            <div className="flex-1">
                {tab === 'restaurante' && (
                <div className="space-y-5 animate-in fade-in slide-in-from-right-4 duration-300">
                    <Field label="Nombre del restaurante *" field="nombre_empresa" placeholder="Mi Restaurante" />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <Field label="RFC (Opcional)" field="rfc" placeholder="XAXX010101000" />
                    <Field label="Teléfono" field="telefono" placeholder="(81) 1234-5678" />
                    </div>
                    <Field label="Dirección Física" field="direccion" placeholder="Calle, Número, Ciudad" />
                </div>
                )}

                {tab === 'fiscal' && (
                <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                    <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 text-sm text-amber-800 font-bold flex items-start gap-3">
                        <span className="text-xl">⚠️</span> 
                        <p>Cambiar el IVA afecta todos los cálculos de ventas nuevas. Las ventas históricas conservan el impuesto con el que fueron cerradas.</p>
                    </div>
                    <div>
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-2">Tasa de Impuesto (IVA %)</label>
                    <div className="flex items-center gap-4">
                        <input type="number" min="0" max="100" step="0.01" value={form.iva}
                        onChange={e => setForm({...form, iva: e.target.value})}
                        className="w-32 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-black text-xl text-center outline-none focus:ring-2 focus:ring-indigo-500" />
                        <span className="font-black text-slate-600 text-2xl">%</span>
                        <div className="flex gap-2 ml-2">
                        {[0, 8, 16].map(v => (
                            <button key={v} type="button" onClick={() => setForm({...form, iva: v})}
                            className={`px-4 py-2 rounded-xl text-sm font-black transition-all ${Number(form.iva) === v ? 'bg-indigo-600 text-ui-text shadow-md' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
                            {v}%
                            </button>
                        ))}
                        </div>
                    </div>
                    <p className="text-xs text-slate-400 mt-3 font-bold">Cobrarás ${(100 * (1 + Number(form.iva)/100)).toLocaleString('es-MX', {minimumFractionDigits:2})} por cada $100.00 de base.</p>
                    </div>
                </div>
                )}

                {tab === 'categorias' && (
                <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
                    <div>
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-3">Categorías del Menú POS</label>
                        <div className="flex gap-3 mb-4">
                            <input value={nuevaCat} onChange={e => setNuevaCat(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), agregarCat())}
                            placeholder="Ej. Bebidas, Postres..." className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-medium text-sm outline-none focus:ring-2 focus:ring-indigo-500" />
                            <button type="button" onClick={agregarCat} className="px-5 py-3 bg-indigo-600 text-ui-text rounded-xl font-black text-sm hover:bg-indigo-700 transition-colors shadow-md"><Plus className="w-5 h-5" /></button>
                        </div>
                        <div className="flex flex-wrap gap-2">
                            {categorias.map(c => (
                            <span key={c} className="bg-slate-100 text-slate-700 font-bold text-sm px-4 py-2 rounded-xl flex items-center gap-2 border border-slate-200">
                                {c} <button type="button" onClick={() => quitarCat(c)} className="text-slate-400 hover:text-red-500 transition-colors"><X className="w-4 h-4" /></button>
                            </span>
                            ))}
                        </div>
                    </div>
                    
                    <div className="border-t border-slate-100 pt-8">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-3">Unidades de Medida (Inventario)</label>
                        <div className="flex gap-3 mb-4">
                            <input value={nuevaUni} onChange={e => setNuevaUni(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), agregarUni())}
                            placeholder="Ej. Kgs, Lts, Pzas..." className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-medium text-sm outline-none focus:ring-2 focus:ring-indigo-500" />
                            <button type="button" onClick={agregarUni} className="px-5 py-3 bg-indigo-600 text-ui-text rounded-xl font-black text-sm hover:bg-indigo-700 transition-colors shadow-md"><Plus className="w-5 h-5" /></button>
                        </div>
                        <div className="flex flex-wrap gap-2">
                            {unidades.map(u => (
                            <span key={u} className="bg-slate-100 text-slate-700 font-bold text-sm px-4 py-2 rounded-xl flex items-center gap-2 border border-slate-200">
                                {u} <button type="button" onClick={() => quitarUni(u)} className="text-slate-400 hover:text-red-500 transition-colors"><X className="w-4 h-4" /></button>
                            </span>
                            ))}
                        </div>
                    </div>
                </div>
                )}

                {tab === 'tickets' && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-in fade-in slide-in-from-right-4 duration-300">
                    {/* Campos de Edición */}
                    <div className="space-y-5">
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1.5">Encabezado / Subtítulo</label>
                            <textarea value={form.encabezado_ticket} onChange={e => setForm({...form, encabezado_ticket: e.target.value})} rows={2}
                                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-medium text-sm outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                                placeholder="Ej. Sucursal Centro&#10;Síguenos en IG @restaurante" />
                        </div>
                        
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1.5">Pie de Ticket / Cortesía</label>
                            <textarea value={form.mensaje_ticket} onChange={e => setForm({...form, mensaje_ticket: e.target.value})} rows={2}
                                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-medium text-sm outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                                placeholder="¡Gracias por su preferencia!" />
                        </div>

                        <label className="flex items-center gap-3 cursor-pointer p-4 bg-slate-50 border border-slate-200 rounded-xl">
                            <input type="checkbox" checked={form.mostrar_propinas} onChange={e => setForm({...form, mostrar_propinas: e.target.checked})} className="w-5 h-5 accent-indigo-600" />
                            <span className="text-sm font-bold text-slate-700">Imprimir sugerencia de propina (10%, 15%, 20%)</span>
                        </label>
                    </div>

                    {/* Vista Previa del Ticket */}
                    <div className="bg-slate-100 rounded-2xl p-6 border-2 border-dashed border-slate-300 flex justify-center items-start">
                        <div className="bg-white p-5 w-full max-w-[280px] shadow-sm font-mono text-[11px] text-ui-text space-y-1 text-center border-l-4 border-slate-200">
                            <p className="font-black text-sm uppercase">{form.nombre_empresa || 'MI RESTAURANTE'}</p>
                            {form.encabezado_ticket && <p className="whitespace-pre-wrap">{form.encabezado_ticket}</p>}
                            {form.rfc && <p>RFC: {form.rfc}</p>}
                            {form.direccion && <p className="truncate">{form.direccion}</p>}
                            <p className="border-t border-dashed border-slate-400 pt-1 mt-2">------------------------</p>
                            <div className="text-left">
                                <p>Mesa: 05 | Ticket: #0012</p>
                                <p>Mesero: Christopher</p>
                            </div>
                            <p className="border-t border-dashed border-slate-400 pt-1 mt-1">------------------------</p>
                            <div className="flex justify-between"><p>1x Flat White</p><p>$55.00</p></div>
                            <div className="flex justify-between"><p>1x Chilaquiles</p><p>$110.00</p></div>
                            <p className="border-t border-dashed border-slate-400 pt-1 mt-2">------------------------</p>
                            <div className="flex justify-between font-black text-sm"><p>TOTAL:</p><p>$165.00</p></div>
                            
                            {form.mostrar_propinas && (
                                <div className="text-left mt-3 pt-2 border-t border-slate-200">
                                    <p className="font-bold text-center mb-1">Propina Sugerida:</p>
                                    <div className="flex justify-between text-[10px]"><p>10% Excelente</p><p>$16.50</p></div>
                                    <div className="flex justify-between text-[10px]"><p>15% Extraordinario</p><p>$24.75</p></div>
                                </div>
                            )}

                            <p className="border-t border-dashed border-slate-400 pt-3 mt-3 text-slate-500 italic whitespace-pre-wrap">{form.mensaje_ticket}</p>
                        </div>
                    </div>
                </div>
                )}
            </div>

            {/* BOTÓN DE GUARDADO FLOTANTE INFERIOR */}
            <div className="mt-8 pt-6 border-t border-slate-100 flex justify-end shrink-0">
              <button type="submit"
                className="bg-slate-900 hover:bg-black text-ui-text font-black px-8 py-4 rounded-xl shadow-lg transition-all active:scale-95 flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-emerald-400" /> Guardar Configuración
              </button>
            </div>
          </form>
        </div>
      </div>

      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-brand-cesped text-ui-text px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 animate-in slide-in-from-bottom-4">
          <CheckCircle className="w-5 h-5" />
          <p className="font-black text-sm">{toast}</p>
        </div>
      )}
    </div>
  );
}