import { useState, useMemo } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { 
  LineChart, DollarSign, TrendingUp, TrendingDown, 
  ShoppingBag, CreditCard, PieChart, Calendar, 
  Activity, Users, FileText, UtensilsCrossed,
  Store, Receipt, Printer, Coins, Package, AlertTriangle,
  BarChart2, ShieldAlert
} from 'lucide-react';

export default function ReportesScreen() {
  const { ventas, ordenesCompra, nominas, turnos, movimientos, productos, recetas } = useAppStore();

  const [tabActivo, setTabActivo] = useState('financiero');
  
  const hoy = new Date();
  const primerDiaMes = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
  const [fechaInicio, setFechaInicio] = useState(primerDiaMes.toISOString().split('T')[0]);
  const [fechaFin, setFechaFin] = useState(hoy.toISOString().split('T')[0]);
  const [filtroMesero, setFiltroMesero] = useState('');
  const [filtroTurno, setFiltroTurno] = useState('');

  // ─── HELPERS ─────────────────────────────────────────────────────────────
  const fmtCant = (cant) => parseFloat(Number(cant).toFixed(2));
  const formatCurrency = (monto) => `$${Number(monto || 0).toLocaleString('es-MX', {minimumFractionDigits:2})}`;
  
  const calcularCostoReceta = (ingredientes = []) => {
    return ingredientes.reduce((acc, ing) => {
      const p = productos.find(x => String(x.id) === String(ing.id_producto));
      if (!p) return acc;
      const merma = Math.round(Number(ing.merma || 0) * 100) / 100;
      const rendimiento = 1 - (merma / 100);
      return acc + (rendimiento > 0 ? (Number(p.precio) / rendimiento) * Number(ing.cantidad) : 0);
    }, 0);
  };

  // ─── MOTOR DE CÁLCULO (MEMOIZADO) ────────────────────────────────────────
  const data = useMemo(() => {
    const inicio = new Date(fechaInicio + 'T00:00:00');
    const fin = new Date(fechaFin + 'T23:59:59');

    // FILTROS BASE
    const vPeriodo = (ventas || []).filter(v => {
      const f = new Date(v.fecha || v.created_at); return f >= inicio && f <= fin && v.estado !== 'Cancelada';
    });
    const cPeriodo = (ordenesCompra || []).filter(c => {
      const f = new Date(c.fecha || c.created_at); return f >= inicio && f <= fin && c.estado === 'Completada';
    });
    const nPeriodo = (nominas || []).filter(n => {
      const f = new Date(n.fecha_fin || n.created_at); return f >= inicio && f <= fin;
    });
    const movPeriodo = (movimientos || []).filter(m => {
      const f = new Date(m.fecha); return f >= inicio && f <= fin;
    });

    // 1. FINANCIERO
    const tIngresos = vPeriodo.reduce((acc, v) => acc + Number(v.total || 0), 0);
    const tEfectivo = vPeriodo.reduce((acc, v) => acc + (v.metodo_pago==='efectivo'?v.total:v.metodo_pago==='mixto'?(v.efectivo||0):0), 0);
    const tTarjeta = vPeriodo.reduce((acc, v) => acc + (v.metodo_pago==='tarjeta'?v.total:v.metodo_pago==='mixto'?(v.tarjeta||0):0), 0);
    const tPropinas = vPeriodo.reduce((acc, v) => acc + Number(v.propina || 0), 0);
    const tInsumos = cPeriodo.reduce((acc, c) => acc + Number(c.total || 0), 0);
    const tNominas = nPeriodo.reduce((acc, n) => acc + Number(n.gran_total || 0), 0);
    const tEgresos = tInsumos + tNominas;
    const utilNeta = tIngresos - tEgresos;

    // 2. RENDIMIENTO MESEROS Y PROPINAS
    const porMesero = {};
    vPeriodo.forEach(v => {
        const user = v.usuario || 'Sistema';
        if (!porMesero[user]) porMesero[user] = { total:0, propinas:0, tickets:0 };
        porMesero[user].total += v.total || 0;
        porMesero[user].propinas += v.propina || 0;
        porMesero[user].tickets += 1;
    });
    const meserosRank = Object.entries(porMesero).map(([nombre, d]) => ({nombre, ...d})).sort((a,b) => b.total - a.total);

    // 3. RENTABILIDAD Y ABC (PARETO)
    const analisisMenu = (recetas || []).map(r => {
        const costo = calcularCostoReceta(r.ingredientes || []);
        const precio = Number(r.precio_venta) || 0;
        const ganancia = precio - costo;
        const margen = precio > 0 ? (ganancia / precio) * 100 : 0;
        
        let uds = 0; let ingresosGenerados = 0;
        vPeriodo.forEach(v => (v.items||[]).forEach(i => { 
            if (i.nombre === r.nombre) { uds += i.cantidad; ingresosGenerados += (i.cantidad * precio); } 
        }));
        
        return { nombre: r.nombre, categoria: r.categoria, costo, precio, ganancia, margen, uds, ingresosGenerados };
    }).sort((a,b) => b.ingresosGenerados - a.ingresosGenerados);

    let ac = 0;
    const abcData = analisisMenu.filter(m => m.uds > 0).map(m => {
        ac += m.ingresosGenerados;
        const pct = tIngresos > 0 ? (ac / tIngresos) * 100 : 0;
        const cls = pct <= 80 ? 'A' : pct <= 95 ? 'B' : 'C';
        return { ...m, pct, cls };
    });

    // 4. INVENTARIO (VALORIZACIÓN Y MERMAS)
    const valorizacionTotal = (productos || []).reduce((acc, p) => acc + (Number(p.stock) * Number(p.precio)), 0);
    const mermas = movPeriodo.filter(m => m.tipo === 'Merma').map(m => {
        const p = productos.find(x => String(x.id) === String(m.producto_id));
        return { ...m, producto: p?.nombre || 'Desc.', perdida: Math.abs(m.cantidad) * Number(p?.precio || 0) };
    });
    const totalPerdidaMermas = mermas.reduce((acc, m) => acc + m.perdida, 0);

    return {
        vPeriodo, tIngresos, tEfectivo, tTarjeta, tPropinas, tInsumos, tNominas, tEgresos, utilNeta,
        meserosRank, abcData, analisisMenu, valorizacionTotal, mermas, totalPerdidaMermas
    };
  }, [ventas, ordenesCompra, nominas, movimientos, productos, recetas, fechaInicio, fechaFin]);

  const turnosPeriodo = useMemo(() => {
      const inicio = new Date(fechaInicio + 'T00:00:00');
      const fin = new Date(fechaFin + 'T23:59:59');
      return (turnos || []).filter(t => new Date(t.fecha_apertura) >= inicio && new Date(t.fecha_apertura) <= fin);
  }, [turnos, fechaInicio, fechaFin]);

  // ─── FUNCIONES DE IMPRESIÓN (PORTADAS DE VANILLA JS) ─────────────────────
  const imprimirTicketCierre = (turnoId) => {
    const t = turnos.find(x => String(x.id) === String(turnoId));
    if(!t) return;
    const win = window.open('','_blank','width=320,height=600');
    win.document.write(`
        <html><head><style>body{font-family:monospace;font-size:12px;text-align:center}</style></head>
        <body>
            <h2>AUDITORÍA DE TURNO #${t.id}</h2>
            <p>Cajero: ${t.usuario}</p>
            <hr/>
            <p>Fondo Inicial: $${t.fondo_inicial}</p>
            <h3>CUADRE: $${t.diferencia}</h3>
        </body></html>
    `);
    win.document.close(); setTimeout(()=>{win.print();win.close();},500);
  };

  const imprimirValePropina = (mesero, monto) => {
    const win = window.open('','_blank','width=320,height=400');
    win.document.write(`
        <html><head><style>body{font-family:monospace;font-size:12px;text-align:center;padding:20px}</style></head>
        <body>
            <h2>VALE DE PROPINAS</h2>
            <br/><br/>
            <h1>$${monto.toFixed(2)}</h1>
            <br/>
            <p>Periodo: ${fechaInicio} al ${fechaFin}</p>
            <hr style="margin-top:50px"/>
            <p>Firma: ${mesero.toUpperCase()}</p>
        </body></html>
    `);
    win.document.close(); setTimeout(()=>{win.print();win.close();},500);
  };

  // ─── COMPONENTES UI ────────────────────────────────────────────────────────
  const KPI = ({ titulo, valor, icono: Icono, color, subtitulo }) => (
    <div className="bg-white p-6 rounded-[2rem] border-2 border-slate-50 shadow-sm flex items-start gap-4 transition-all hover:shadow-lg">
      <div className={`p-4 rounded-2xl shadow-inner ${color}`}><Icono className="w-6 h-6" /></div>
      <div>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{titulo}</p>
        <p className="text-2xl font-black text-ui-text tracking-tight">{valor}</p>
        {subtitulo && <p className="text-xs font-bold text-slate-400 mt-1">{subtitulo}</p>}
      </div>
    </div>
  );

  return (
    <div className="p-8 max-w-7xl mx-auto flex flex-col h-full animate-in fade-in duration-500">
      
      {/* HEADER Y FILTRO DE FECHAS */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-xl shadow-slate-200/50 mb-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-12 bg-blue-50 rounded-full -mr-12 -mt-12 opacity-50" />
        <div className="flex items-center gap-6 relative z-10">
          <div className="bg-blue-600 p-4 rounded-3xl shadow-lg shadow-blue-600/40"><LineChart className="w-8 h-8 text-ui-text" /></div>
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">Centro de Reportes</h1>
            <p className="text-slate-500 font-bold mt-1">Inteligencia de Negocio y Auditoría</p>
          </div>
        </div>

        <div className="flex items-center bg-slate-50 border-2 border-slate-100 p-2 rounded-2xl relative z-10 shadow-inner w-full lg:w-auto">
           <div className="px-4 border-r border-slate-200">
              <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Desde</label>
              <input type="date" value={fechaInicio} onChange={e => setFechaInicio(e.target.value)} className="bg-transparent font-black text-slate-700 outline-none w-32" />
           </div>
           <div className="px-4">
              <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Hasta</label>
              <input type="date" value={fechaFin} onChange={e => setFechaFin(e.target.value)} className="bg-transparent font-black text-slate-700 outline-none w-32" />
           </div>
        </div>
      </div>

      {/* MENÚ DE MÓDULOS (TABS) */}
      <div className="flex gap-2 overflow-x-auto pb-4 custom-scrollbar mb-4">
        {[
            { id: 'financiero', label: 'Dashboard Financiero', icon: Activity },
            { id: 'operacion', label: 'Operación y Cajas', icon: Store },
            { id: 'menu', label: 'Rentabilidad (ABC)', icon: PieChart },
            { id: 'almacen', label: 'Control de Almacén', icon: Package }
        ].map(t => (
            <button key={t.id} onClick={() => setTabActivo(t.id)} className={`px-6 py-3 rounded-2xl text-sm font-black transition-all flex items-center gap-2 whitespace-nowrap ${tabActivo === t.id ? 'bg-slate-900 text-ui-text shadow-lg' : 'bg-white text-slate-500 border-2 border-slate-100 hover:border-slate-300'}`}>
                <t.icon className="w-4 h-4" /> {t.label}
            </button>
        ))}
      </div>

      {/* ─── CONTENIDO DINÁMICO ─────────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 pb-10 space-y-8 animate-in slide-in-from-bottom-4">
        
        {/* MÓDULO 1: FINANCIERO */}
        {tabActivo === 'financiero' && (
            <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <KPI titulo="Ventas Totales" valor={formatCurrency(data.tIngresos)} icono={DollarSign} color="bg-blue-50 text-blue-600" subtitulo={`${data.vPeriodo.length} tickets`} />
                    <KPI titulo="Ticket Promedio" valor={formatCurrency(data.vPeriodo.length ? data.tIngresos / data.vPeriodo.length : 0)} icono={CreditCard} color="bg-indigo-50 text-indigo-600" />
                    <KPI titulo="Gastos Operativos" valor={formatCurrency(data.tEgresos)} icono={TrendingDown} color="bg-rose-50 text-rose-500" subtitulo="Insumos + Nómina" />
                    <KPI titulo="Utilidad Real" valor={formatCurrency(data.utilNeta)} icono={TrendingUp} color="bg-emerald-50 text-emerald-600" subtitulo={`Margen: ${data.tIngresos ? ((data.utilNeta/data.tIngresos)*100).toFixed(1) : 0}%`} />
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="bg-white p-8 rounded-[2rem] border-2 border-slate-50 shadow-sm lg:col-span-1 flex flex-col">
                        <h3 className="text-sm font-black text-ui-text uppercase tracking-widest mb-6 flex items-center gap-2"><PieChart className="w-5 h-5 text-slate-400" /> Distribución de Ingresos</h3>
                        <div className="space-y-6">
                            <div>
                                <div className="flex justify-between items-end mb-2"><span className="text-xs font-black text-slate-500">En Efectivo</span><span className="text-lg font-black text-ui-text">{formatCurrency(data.tEfectivo)}</span></div>
                                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden"><div className="bg-emerald-400 h-full rounded-full" style={{ width: `${data.tIngresos ? (data.tEfectivo / data.tIngresos) * 100 : 0}%` }} /></div>
                            </div>
                            <div>
                                <div className="flex justify-between items-end mb-2"><span className="text-xs font-black text-slate-500">En Tarjeta</span><span className="text-lg font-black text-ui-text">{formatCurrency(data.tTarjeta)}</span></div>
                                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden"><div className="bg-blue-400 h-full rounded-full" style={{ width: `${data.tIngresos ? (data.tTarjeta / data.tIngresos) * 100 : 0}%` }} /></div>
                            </div>
                        </div>
                    </div>
                    <div className="bg-white p-8 rounded-[2rem] border-2 border-slate-50 shadow-sm lg:col-span-2">
                        <h3 className="text-sm font-black text-ui-text uppercase tracking-widest mb-6 flex items-center gap-2"><UtensilsCrossed className="w-5 h-5 text-amber-500" /> Top Platillos (Ingresos)</h3>
                        <div className="space-y-4">
                            {data.abcData.slice(0,5).map((p, idx) => (
                                <div key={p.nombre} className="flex items-center gap-4">
                                    <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 font-black flex items-center justify-center shrink-0">{idx + 1}</div>
                                    <div className="flex-1">
                                        <div className="flex justify-between items-end mb-1">
                                            <p className="font-black text-slate-700">{p.nombre}</p>
                                            <p className="font-bold text-xs text-slate-400">{p.uds} uds. <span className="text-emerald-500 font-black ml-2">{formatCurrency(p.ingresosGenerados)}</span></p>
                                        </div>
                                        <div className="w-full h-2 bg-slate-50 rounded-full"><div className="h-full bg-amber-400 rounded-full" style={{ width: `${(p.ingresosGenerados / data.abcData[0].ingresosGenerados) * 100}%` }} /></div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </>
        )}

        {/* MÓDULO 2: OPERACIÓN Y CAJAS */}
        {tabActivo === 'operacion' && (
            <div className="space-y-8">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {/* Auditoría de Turnos */}
                    <div className="bg-white p-8 rounded-[2rem] border-2 border-slate-50 shadow-sm">
                        <h3 className="text-sm font-black text-ui-text uppercase tracking-widest mb-6 flex items-center gap-2"><ShieldAlert className="w-5 h-5 text-indigo-500" /> Auditoría de Turnos</h3>
                        <div className="space-y-4">
                            {turnosPeriodo.map(t => (
                                <div key={t.id} className="p-4 border-2 border-slate-100 rounded-2xl flex justify-between items-center group">
                                    <div>
                                        <p className="font-black text-ui-text">{t.usuario} <span className={`text-[10px] px-2 py-0.5 rounded-md text-ui-text ${t.estado==='abierto'?'bg-brand-cesped':'bg-slate-400'}`}>{t.estado}</span></p>
                                        <p className="text-xs font-bold text-slate-500">{new Date(t.fecha_apertura).toLocaleDateString()} | Faltante/Sobrante: <span className={t.diferencia === 0 ? 'text-emerald-500' : 'text-rose-500'}>{formatCurrency(t.diferencia)}</span></p>
                                    </div>
                                    <button onClick={() => imprimirTicketCierre(t.id)} className="p-2 bg-slate-100 text-slate-500 hover:bg-slate-800 hover:text-ui-text rounded-xl transition-colors"><Printer className="w-4 h-4"/></button>
                                </div>
                            ))}
                        </div>
                    </div>
                    {/* Rendimiento Meseros & Propinas */}
                    <div className="bg-white p-8 rounded-[2rem] border-2 border-slate-50 shadow-sm">
                        <h3 className="text-sm font-black text-ui-text uppercase tracking-widest mb-6 flex items-center gap-2"><Coins className="w-5 h-5 text-orange-500" /> Propinas y Rendimiento</h3>
                        <div className="space-y-4">
                            {data.meserosRank.map(m => (
                                <div key={m.nombre} className="flex justify-between items-center p-4 border border-slate-100 rounded-2xl bg-orange-50/30">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-full bg-orange-100 text-orange-600 font-black flex items-center justify-center">{m.nombre[0].toUpperCase()}</div>
                                        <div><p className="font-black text-ui-text">{m.nombre}</p><p className="text-xs font-bold text-slate-500">Vendió {formatCurrency(m.total)}</p></div>
                                    </div>
                                    <div className="flex items-center gap-4">
                                        <div className="text-right"><p className="text-[10px] font-black text-orange-400 uppercase">Propinas</p><p className="font-black text-orange-600 text-lg">{formatCurrency(m.propinas)}</p></div>
                                        {m.propinas > 0 && <button onClick={() => imprimirValePropina(m.nombre, m.propinas)} className="p-2 bg-orange-500 text-ui-text hover:bg-orange-600 rounded-xl"><Printer className="w-4 h-4"/></button>}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* MÓDULO 3: RENTABILIDAD Y MENU */}
        {tabActivo === 'menu' && (
            <div className="space-y-8">
                <div className="grid grid-cols-3 gap-6 mb-6">
                    <div className="bg-emerald-50 border-2 border-emerald-100 p-6 rounded-[2rem] text-center"><h3 className="text-4xl font-black text-emerald-600">A</h3><p className="text-xs font-black text-emerald-700 uppercase tracking-widest mt-1">Vitales (80% Ingresos)</p></div>
                    <div className="bg-amber-50 border-2 border-amber-100 p-6 rounded-[2rem] text-center"><h3 className="text-4xl font-black text-amber-500">B</h3><p className="text-xs font-black text-amber-600 uppercase tracking-widest mt-1">Regulares (15%)</p></div>
                    <div className="bg-rose-50 border-2 border-rose-100 p-6 rounded-[2rem] text-center"><h3 className="text-4xl font-black text-rose-500">C</h3><p className="text-xs font-black text-rose-600 uppercase tracking-widest mt-1">Baja Rotación (5%)</p></div>
                </div>
                <div className="bg-white border-2 border-slate-50 shadow-sm rounded-[2rem] overflow-hidden">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-slate-50 border-b border-slate-100 text-xs uppercase tracking-widest text-slate-400">
                            <tr><th className="p-5">Platillo</th><th className="p-5 text-center">Clase</th><th className="p-5 text-center">Uds</th><th className="p-5 text-right">Costo / Precio</th><th className="p-5 text-right">Margen</th><th className="p-5 text-right">Total Generado</th></tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                            {data.abcData.map(p => (
                                <tr key={p.nombre} className="hover:bg-slate-50/50">
                                    <td className="p-5 font-black text-ui-text">{p.nombre}</td>
                                    <td className="p-5 text-center"><span className={`px-3 py-1 rounded-lg font-black text-xs ${p.cls==='A'?'bg-emerald-100 text-emerald-700':p.cls==='B'?'bg-amber-100 text-amber-700':'bg-rose-100 text-rose-700'}`}>{p.cls}</span></td>
                                    <td className="p-5 text-center font-bold text-slate-500">{p.uds}</td>
                                    <td className="p-5 text-right font-bold"><span className="text-rose-500">{formatCurrency(p.costo)}</span> <span className="text-slate-300">/</span> <span className="text-emerald-500">{formatCurrency(p.precio)}</span></td>
                                    <td className="p-5 text-right font-black"><span className={p.margen < 30 ? 'text-amber-500' : 'text-emerald-500'}>{p.margen.toFixed(1)}%</span></td>
                                    <td className="p-5 text-right font-black text-slate-900">{formatCurrency(p.ingresosGenerados)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        )}

        {/* MÓDULO 4: ALMACÉN */}
        {tabActivo === 'almacen' && (
            <div className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="bg-gradient-to-br from-indigo-500 to-blue-600 p-8 rounded-[2rem] shadow-xl text-ui-text">
                        <p className="text-xs font-black text-blue-200 uppercase tracking-widest flex items-center gap-2"><DollarSign className="w-4 h-4"/> Valorización de Inventario</p>
                        <h3 className="text-5xl font-black mt-2">{formatCurrency(data.valorizacionTotal)}</h3>
                        <p className="text-sm font-bold text-blue-100 mt-2">Capital congelado en almacén actual.</p>
                    </div>
                    <div className="bg-white p-8 rounded-[2rem] border-2 border-rose-100 shadow-sm relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-8 bg-rose-50 rounded-bl-full"><AlertTriangle className="w-8 h-8 text-rose-500"/></div>
                        <p className="text-xs font-black text-rose-400 uppercase tracking-widest flex items-center gap-2 mb-2">Pérdida por Mermas</p>
                        <h3 className="text-4xl font-black text-rose-600">{formatCurrency(data.totalPerdidaMermas)}</h3>
                        <p className="text-sm font-bold text-slate-500 mt-2">En el periodo seleccionado.</p>
                    </div>
                </div>
                <div className="bg-white border-2 border-slate-50 shadow-sm rounded-[2rem] overflow-hidden">
                    <div className="p-5 bg-slate-50 border-b border-slate-100"><h4 className="font-black text-slate-700 flex items-center gap-2"><TrendingDown className="w-4 h-4"/> Detalle de Mermas</h4></div>
                    <table className="w-full text-left text-sm">
                        <thead className="bg-white border-b border-slate-100 text-xs uppercase tracking-widest text-slate-400">
                            <tr><th className="p-4">Fecha</th><th className="p-4">Insumo</th><th className="p-4 text-center">Cant</th><th className="p-4">Motivo</th><th className="p-4 text-right">Pérdida Económica</th></tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                            {data.mermas.map((m, i) => (
                                <tr key={i} className="hover:bg-rose-50/30">
                                    <td className="p-4 font-mono text-xs text-slate-500">{new Date(m.fecha).toLocaleDateString()}</td>
                                    <td className="p-4 font-bold text-slate-700">{m.producto}</td>
                                    <td className="p-4 text-center font-black text-rose-500">{Math.abs(m.cantidad)}</td>
                                    <td className="p-4 text-xs italic text-slate-500">{m.referencia}</td>
                                    <td className="p-4 text-right font-black text-ui-text">{formatCurrency(m.perdida)}</td>
                                </tr>
                            ))}
                            {data.mermas.length === 0 && <tr><td colSpan="5" className="p-8 text-center text-slate-400 font-bold">No hay mermas en este periodo.</td></tr>}
                        </tbody>
                    </table>
                </div>
            </div>
        )}

      </div>
    </div>
  );
}