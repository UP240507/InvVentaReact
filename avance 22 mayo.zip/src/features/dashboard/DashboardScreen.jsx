import { useMemo } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { TrendingUp, Users, ChefHat, AlertTriangle, Receipt, Activity, PackageOpen, CheckCircle } from 'lucide-react';

export default function DashboardScreen() {
  const { ventas, comandas_activas, productos, staff, mesas } = useAppStore();

  const metricas = useMemo(() => {
    const hoyStr = new Date().toISOString().split('T')[0];
    const ventasHoy = (ventas || []).filter(v => v.fecha?.startsWith(hoyStr));
    const ingresosHoy = ventasHoy.reduce((acc, v) => acc + (Number(v.total) || 0), 0);
    const stockCritico = (productos || []).filter(p => Number(p.stock) <= (Number(p.min) || 0));
    const mesasOcupadas = (mesas || []).filter(m => m.estado === 'ocupada').length;
    const staffActivo = (staff || []).filter(s => s.activo !== false).length;

    return {
      ingresosHoy, ticketsHoy: ventasHoy.length, stockCritico, mesasOcupadas,
      staffActivo, comandasEnCocina: comandas_activas?.length || 0,
      ultimasVentas: ventasHoy.slice(0, 5).sort((a, b) => new Date(b.fecha) - new Date(a.fecha))
    };
  }, [ventas, comandas_activas, productos, staff, mesas]);

  const WidgetCard = ({ titulo, valor, subtitulo, icono: Icono, accentColor, iconColor }) => (
    <div className="bg-white dark:bg-ui-humo p-6 rounded-brand border-2 border-slate-100 dark:border-ui-border shadow-sm hover:shadow-lg transition-all hover:-translate-y-1 group">
      <div className="flex justify-between items-start mb-4">
        <div className={`p-3 rounded-2xl ${accentColor} transition-transform group-hover:scale-110 border border-white/50 dark:border-white/5`}>
          <Icono className={`w-6 h-6 ${iconColor}`} />
        </div>
      </div>
      <div>
        <p className="text-4xl font-black text-slate-900 dark:text-brand-nacar font-syne tabular-nums leading-none mb-2">{valor}</p>
        <p className="text-sm font-bold text-slate-500 dark:text-ui-muted">{titulo}</p>
        {subtitulo && <p className="text-[10px] font-black text-brand-amatista uppercase tracking-widest mt-2">{subtitulo}</p>}
      </div>
    </div>
  );

  return (
    <div className="p-6 md:p-10 max-w-7xl mx-auto h-full animate-in fade-in duration-500 overflow-y-auto custom-scrollbar text-slate-800 dark:text-ui-text transition-colors">
      
      <div className="mb-10">
        <h1 className="text-3xl font-black font-syne text-slate-900 dark:text-brand-nacar flex items-center gap-3 tracking-tight">
          <div className="bg-brand-arrecife/10 p-2 rounded-xl">
            <Activity className="w-8 h-8 text-brand-arrecife" />
          </div>
          Centro de Control
        </h1>
        <p className="text-xs font-black text-slate-500 dark:text-ui-muted uppercase tracking-widest mt-2">
          Métricas de operación en tiempo real
        </p>
      </div>

      {/* GRID DE WIDGETS */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-10">
        <WidgetCard 
          titulo="Ingresos del Día" valor={`$${metricas.ingresosHoy.toLocaleString('es-MX', {minimumFractionDigits: 2})}`} 
          subtitulo={`${metricas.ticketsHoy} tickets cobrados`} icono={TrendingUp} 
          accentColor="bg-emerald-50 dark:bg-brand-cesped/10" iconColor="text-emerald-600 dark:text-brand-cesped"
        />
        <WidgetCard 
          titulo="Comandas Activas" valor={metricas.comandasEnCocina} 
          subtitulo="En preparación (KDS)" icono={ChefHat} 
          accentColor="bg-rose-50 dark:bg-brand-arrecife/10" iconColor="text-rose-600 dark:text-brand-arrecife"
        />
        <WidgetCard 
          titulo="Mesas Ocupadas" valor={metricas.mesasOcupadas} 
          subtitulo={`De ${mesas?.length || 0} disponibles`} icono={Users} 
          accentColor="bg-indigo-50 dark:bg-brand-amatista/10" iconColor="text-indigo-600 dark:text-brand-amatista"
        />
        <WidgetCard 
          titulo="Alertas de Stock" valor={metricas.stockCritico.length} 
          subtitulo="Insumos por agotarse" icono={AlertTriangle} 
          accentColor="bg-amber-50 dark:bg-brand-ambar/10" iconColor="text-amber-600 dark:text-brand-ambar"
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-10">
        
        {/* TABLA: ÚLTIMAS VENTAS */}
        <div className="xl:col-span-2 bg-white dark:bg-ui-humo p-6 md:p-8 rounded-brand border-2 border-slate-100 dark:border-ui-border shadow-sm transition-colors">
          <h2 className="text-xl font-black font-syne text-slate-900 dark:text-brand-nacar flex items-center gap-3 mb-8">
            <Receipt className="w-5 h-5 text-brand-amatista" /> Movimientos de Caja
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-[10px] font-black text-slate-400 dark:text-ui-muted uppercase tracking-widest border-b-2 border-slate-100 dark:border-ui-border">
                <tr><th className="pb-4 pl-4">Folio</th><th className="pb-4">Hora</th><th className="pb-4">Método</th><th className="pb-4 text-right pr-4">Total</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-ui-border">
                {metricas.ultimasVentas.length === 0 ? (
                  <tr><td colSpan="4" className="py-10 text-center text-slate-400 dark:text-ui-muted font-bold">Aún no hay ventas registradas hoy.</td></tr>
                ) : (
                  metricas.ultimasVentas.map(venta => (
                    <tr key={venta.id} className="hover:bg-slate-50 dark:hover:bg-ui-obsidiana/50 transition-colors">
                      <td className="py-4 pl-4 font-black text-slate-900 dark:text-brand-nacar">{venta.folio}</td>
                      <td className="py-4 font-bold text-slate-500 dark:text-ui-muted">{new Date(venta.fecha).toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' })}</td>
                      <td className="py-4">
                        <span className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border ${
                          venta.metodo_pago === 'efectivo' ? 'bg-emerald-50 border-emerald-200 text-emerald-600 dark:bg-brand-cesped/10 dark:text-brand-cesped dark:border-brand-cesped/20' : 'bg-indigo-50 border-indigo-200 text-indigo-600 dark:bg-brand-amatista/10 dark:text-brand-amatista dark:border-brand-amatista/20'
                        }`}>{venta.metodo_pago}</span>
                      </td>
                      <td className="py-4 pr-4 text-right font-black text-emerald-600 dark:text-brand-cesped text-lg">
                        ${Number(venta.total).toLocaleString('es-MX', {minimumFractionDigits: 2})}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* PANEL: ALERTAS DE STOCK */}
        <div className="bg-amber-50 dark:bg-brand-ambar/5 p-6 md:p-8 rounded-brand border-2 border-amber-200 dark:border-brand-ambar/20 shadow-sm transition-colors">
          <h2 className="text-xl font-black font-syne text-amber-700 dark:text-brand-ambar flex items-center gap-3 mb-8">
            <PackageOpen className="w-5 h-5" /> Requieren Resurtido
          </h2>
          <div className="space-y-3">
            {metricas.stockCritico.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-emerald-100 dark:bg-brand-cesped/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-200 dark:border-brand-cesped/20">
                  <CheckCircle className="w-8 h-8 text-emerald-500 dark:text-brand-cesped" />
                </div>
                <p className="font-black font-syne text-emerald-600 dark:text-brand-cesped text-lg">Inventario sano</p>
                <p className="font-bold text-xs text-slate-500 dark:text-ui-muted uppercase tracking-widest mt-2">Todo en orden</p>
              </div>
            ) : (
              metricas.stockCritico.map(prod => (
                <div key={prod.id} className="bg-white dark:bg-ui-obsidiana p-4 rounded-2xl flex justify-between items-center border border-amber-200 dark:border-ui-border shadow-sm">
                  <div>
                    <p className="font-black text-slate-800 dark:text-brand-nacar text-sm line-clamp-1 leading-tight">{prod.nombre}</p>
                    <p className="text-[10px] font-bold text-slate-400 dark:text-ui-muted uppercase tracking-widest mt-1">{prod.categoria}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-black text-amber-600 dark:text-brand-ambar font-syne leading-none">{prod.stock}</p>
                    <p className="text-[9px] font-black text-rose-500 dark:text-brand-arrecife uppercase tracking-widest mt-1.5">Restantes</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>
    </div>
  );
}