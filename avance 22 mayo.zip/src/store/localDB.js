import Dexie from 'dexie';

export const localDB = new Dexie('invVentaDB');

// Mantenemos las 4 versiones exactas de tu Vanilla JS para no perder datos en producción
localDB.version(1).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, fecha'
});

localDB.version(2).stores({
    // ... agrega proveedores
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, fecha'
});

localDB.version(3).stores({
    // ... mejora sync_queue
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt'
});

localDB.version(4).stores({
    // ... agrega facturas y dead-letter para la cola
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    // indexamos createdAt y nextAttemptAt e intentos para consultas
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt'
});

localDB.version(5).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id' // <-- NUEVA TABLA AGREGADA AQUÍ
});

localDB.version(6).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id' // <-- NUEVA TABLA AGREGADA AQUÍ
});

localDB.version(7).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id', nominas: 'id' // <-- NUEVA TABLA AGREGADA AQUÍ
});
localDB.version(8).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id', nominas: 'id', roles_permisos: 'rol' // <-- NUEVA TABLA AGREGADA AQUÍ
});
localDB.version(9).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id', nominas: 'id', roles_permisos: 'rol', clientes: 'id' // <-- NUEVA TABLA AGREGADA AQUÍ
});
localDB.version(10).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id', nominas: 'id', roles_permisos: 'rol', clientes: 'id',
    auditoria: 'id' // <-- NUEVA TABLA AGREGADA AQUÍ
});
localDB.version(11).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id', nominas: 'id', roles_permisos: 'rol', clientes: 'id',
    auditoria: 'id', asistencias: 'id' // <-- NUEVA TABLA AGREGADA AQUÍ
});
localDB.version(12).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id', nominas: 'id', roles_permisos: 'rol', clientes: 'id',
    auditoria: 'id', asistencias: 'id', comandas:'id' // <-- NUEVA TABLA AGREGADA AQUÍ
});
