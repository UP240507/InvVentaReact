import { create } from 'zustand';
import { supabase } from '../api/supabase';
import { localDB } from './localDB';

export const useAppStore = create((set, get) => ({
  // ─── 1. ESTADO GLOBAL (RAM) ──────────────────────────────────────────────
  configuracion: null,
  productos: [],
  recetas: [],
  mesas: [],
  ventas: [],
  proveedores: [],
  usuarios: [],
  movimientos: [],
  turnos: [],
  ordenesCompra: [],
  facturas: [],
  modificadores: [],
  staff: [],
  nominas: [],
  roles_permisos: [],
  clientes: [],
  auditoria: [],
  asistencias: [],
  comandas_activas: [],

  // ─── 2. CARGA INICIAL (ONLINE / OFFLINE HYBRID) ────────────────────────
  fetchInitialData: async () => {
    try {
      if (navigator.onLine) {
        console.log('🌐 [Network] Sincronizando con Supabase...');
        
        // Carga paralela masiva para reducir el TTI (Time to Interactive)
        const [
          { data: confData }, { data: prodData }, { data: recData },
          { data: mesasData }, { data: ventasData }, { data: provData },
          { data: usersData }, { data: movData }, { data: turnosData },
          { data: ocData }, { data: factData }, { data: modifData },
          { data: staffData }, { data: nominasData }, { data: rolesData },
          { data: clientesData }, { data: auditoriaData }, { data: asistenciasData },
          { data: comandasData }
        ] = await Promise.all([
          supabase.from('configuracion').select('*').single(),
          supabase.from('productos').select('*').eq('activo', true),
          supabase.from('recetas').select('*').eq('activo', true),
          supabase.from('mesas').select('*'),
          supabase.from('ventas').select('*').order('fecha', { ascending: false }).limit(500),
          supabase.from('proveedores').select('*').eq('activo', true),
          supabase.from('usuarios').select('*'),
          supabase.from('movimientos').select('*').order('fecha', { ascending: false }).limit(500),
          supabase.from('turnos').select('*').order('fecha_apertura', { ascending: false }),
          supabase.from('ordenes_compra').select('*'),
          supabase.from('facturas').select('*'),
          supabase.from('modificadores').select('*'),
          supabase.from('staff').select('*'),
          supabase.from('nominas').select('*'),
          supabase.from('roles_permisos').select('*'),
          supabase.from('clientes').select('*'),
          supabase.from('auditoria').select('*').order('fecha', { ascending: false }).limit(200),
          supabase.from('asistencias').select('*').order('fecha_hora', { ascending: false }),
          supabase.from('comandas').select('*').neq('estado', 'completada').order('fecha_hora', { ascending: true })
        ]);

        const payload = {
          configuracion: confData || null, productos: prodData || [], recetas: recData || [],
          mesas: mesasData || [], ventas: ventasData || [], proveedores: provData || [],
          usuarios: usersData || [], movimientos: movData || [], turnos: turnosData || [],
          ordenesCompra: ocData || [], facturas: factData || [], modificadores: modifData || [],
          staff: staffData || [], nominas: nominasData || [], roles_permisos: rolesData || [],
          clientes: clientesData || [], auditoria: auditoriaData || [], asistencias: asistenciasData || [],
          comandas_activas: comandasData || []
        };

        set(payload);

        // 🌟 Backup Silencioso Blindado en Dexie (Modo Offline)
        const safe = (arr) => arr || [];
        await localDB.transaction('rw', 
          localDB.configuracion, localDB.productos, localDB.recetas, localDB.mesas,
          localDB.ventas, localDB.proveedores, localDB.usuarios, localDB.movimientos,
          localDB.turnos, localDB.ordenes_compra, localDB.facturas, localDB.modificadores,
          localDB.staff, localDB.nominas, localDB.roles_permisos, localDB.clientes, 
          localDB.auditoria, localDB.asistencias, localDB.comandas,
          async () => {
            if (confData) await localDB.configuracion.put(confData);
            await localDB.productos.bulkPut(safe(prodData));
            await localDB.recetas.bulkPut(safe(recData));
            await localDB.mesas.bulkPut(safe(mesasData));
            await localDB.ventas.bulkPut(safe(ventasData));
            await localDB.proveedores.bulkPut(safe(provData));
            await localDB.usuarios.bulkPut(safe(usersData));
            await localDB.movimientos.bulkPut(safe(movData));
            await localDB.turnos.bulkPut(safe(turnosData));
            await localDB.ordenes_compra.bulkPut(safe(ocData));
            await localDB.facturas.bulkPut(safe(factData));
            await localDB.modificadores.bulkPut(safe(modifData));
            await localDB.staff.bulkPut(safe(staffData));
            await localDB.nominas.bulkPut(safe(nominasData));
            await localDB.roles_permisos.bulkPut(safe(rolesData));
            await localDB.clientes.bulkPut(safe(clientesData));
            await localDB.auditoria.bulkPut(safe(auditoriaData));
            await localDB.asistencias.bulkPut(safe(asistenciasData));
            await localDB.comandas.bulkPut(safe(comandasData));
          }
        );

      } else {
        console.log('⚠️ [Network] Modo Offline: Rescatando estado desde Dexie...');
        set({
          configuracion: await localDB.configuracion.toCollection().first() || null,
          productos: await localDB.productos.toArray(),
          recetas: await localDB.recetas.toArray(),
          mesas: await localDB.mesas.toArray(),
          ventas: await localDB.ventas.toArray(),
          proveedores: await localDB.proveedores.toArray(),
          usuarios: await localDB.usuarios.toArray(),
          movimientos: await localDB.movimientos.toArray(),
          turnos: await localDB.turnos.toArray(),
          ordenesCompra: await localDB.ordenes_compra.toArray(),
          facturas: await localDB.facturas.toArray(),
          modificadores: await localDB.modificadores.toArray(),
          staff: await localDB.staff.toArray(),
          nominas: await localDB.nominas.toArray(),
          roles_permisos: await localDB.roles_permisos.toArray(),
          clientes: await localDB.clientes.toArray(),
          auditoria: await localDB.auditoria.toArray(),
          asistencias: await localDB.asistencias.toArray(),
          comandas_activas: await localDB.comandas.toArray()
        });
      }
    } catch (error) {
      console.error('❌ [Store] Falla crítica cargando datos:', error);
    }
  },

  // ─── 3. MOTORES KDS (REALTIME) ───────────────────────────────────────────
  iniciarSuscripcionKDS: () => {
    console.log('📡 [KDS] Túnel WebSocket abierto...');
    const suscripcion = supabase
      .channel('kds-channel')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'comandas' }, (payload) => {
        const comanda = payload.new;
        if (payload.eventType === 'INSERT') {
          set(state => {
            if (state.comandas_activas.find(c => c.id === comanda.id)) return state;
            return { comandas_activas: [...state.comandas_activas, comanda] };
          });
        }
        if (payload.eventType === 'UPDATE') {
          set(state => ({
            comandas_activas: state.comandas_activas.map(c => c.id === comanda.id ? comanda : c)
          }));
        }
        if (payload.eventType === 'DELETE') {
          set(state => ({
            comandas_activas: state.comandas_activas.filter(c => c.id !== payload.old.id)
          }));
        }
      })
      .subscribe();
    return suscripcion;
  },

  registrarComandaKDS: (nuevaComanda) => {
    // UI Optimista: Muestra la orden en el KDS antes de que el servidor responda
    set(state => ({ comandas_activas: [...state.comandas_activas, nuevaComanda] }));
  },

  // ─── 4. SEGURIDAD Y AUDITORÍA ────────────────────────────────────────────
  registrarAuditoria: async (logInfo) => {
    const logCompleto = {
      id: logInfo.id || Date.now(),
      fecha: logInfo.fecha || new Date().toISOString(),
      usuario: logInfo.usuario || 'Sistema',
      accion: logInfo.accion || 'ACCIÓN_DESCONOCIDA',
      modulo: logInfo.modulo || 'GENERAL',
      detalles: logInfo.detalles || '',
      nivel: logInfo.nivel || 'info'
    };

    set(state => ({ auditoria: [logCompleto, ...(state.auditoria || [])] }));

    try {
      await localDB.auditoria.put(logCompleto);
      if (navigator.onLine) {
        const { id, ...logParaSupabase } = logCompleto;
        supabase.from('auditoria').insert(logParaSupabase).then(({ error }) => {
          if (error) console.error('⚠️ Error subiendo auditoría:', error.message);
        });
      }
    } catch (err) {
      console.error('⚠️ Error guardando auditoría:', err);
    }
  },

  // ─── 5. LÓGICA DE NEGOCIO Y FINANZAS ─────────────────────────────────────
  getIva: () => {
    return get().configuracion?.iva || 0.16;
  },

  cerrarTurno: async (datosCierre) => {
    const turnoCerrado = {
      folio: `TUR-${Date.now().toString().slice(-5)}`,
      usuario_cierre: datosCierre.usuario,
      fecha_cierre: new Date().toISOString(),
      ventas_totales: datosCierre.ventasTotales,
      propinas_totales: datosCierre.propinasTotales,
      distribucion: datosCierre.distribucion,
      estado: 'cerrado'
    };

    set(state => ({ turnos: [turnoCerrado, ...(state.turnos || [])] }));

    try {
      if (navigator.onLine) {
        await supabase.from('turnos').insert(turnoCerrado);
      } else {
        await localDB.turnos.put({ ...turnoCerrado, id: Date.now() });
      }
      get().registrarAuditoria({
        id: Date.now(), fecha: new Date().toISOString(), usuario: datosCierre.usuario,
        accion: 'CIERRE_TURNO', modulo: 'FINANZAS', nivel: 'warning',
        detalles: `Turno cerrado. Ventas: $${datosCierre.ventasTotales}`
      });
    } catch (err) {
      console.error('Error cerrando turno:', err);
    }
  },

  descontarStock: (itemsVendidos) => {
    const { productos } = get();
    let actualizados = [...productos];
    
    itemsVendidos.forEach(item => {
        const prodIdx = actualizados.findIndex(p => String(p.id) === String(item.id || item.id_producto));
        if (prodIdx !== -1) {
            const prod = actualizados[prodIdx];
            const cant = Number(item.cantidad) || 1;
            const nuevoStock = Math.max(0, Number(prod.stock) - cant);
            actualizados[prodIdx] = { ...prod, stock: nuevoStock };
            
            // Background Sync Fire & Forget
            localDB.productos.put(actualizados[prodIdx]);
            if (navigator.onLine) {
                supabase.from('productos').update({ stock: nuevoStock }).eq('id', prod.id).then();
            }
        }
    });
    
    set({ productos: actualizados });
  },

  // ─── 6. HELPERS UI Y CRUD RÁPIDOS ────────────────────────────────────────
  upsertStaff: (empleado) => {
    set(state => {
      const existe = state.staff.find(s => s.id === empleado.id);
      if (existe) return { staff: state.staff.map(s => s.id === empleado.id ? empleado : s) };
      return { staff: [...state.staff, empleado] };
    });
  },

  showToast: (mensaje, tipo = 'info') => {
    // Si usas react-hot-toast/sonner en el futuro, dispáralo desde aquí.
    // Por ahora usamos console y alert preventivo.
    console.log(`[TOAST ${tipo.toUpperCase()}]: ${mensaje}`);
    // alert(mensaje); // Actívalo si prefieres alertas nativas mientras integras un toast
  }

}));