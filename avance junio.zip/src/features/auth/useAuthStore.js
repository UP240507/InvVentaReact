import { create } from 'zustand';
import { supabase } from '../../api/supabase';

export const useAuthStore = create((set, get) => ({
  user: null,           // Fila completa de tabla 'usuarios' (rol, nombre, restaurante_id, etc.)
  session: null,        // Token de Supabase Auth
  restauranteId: null,  // ✅ NUEVO: acceso directo sin tener que hacer get().user?.restaurante_id
  suscripcion: null,    // ✅ NUEVO: estado de suscripción del tenant
  isLoading: true,
  error: null,

  // ── 1. Verificar sesión al recargar ─────────────────────────────────────
  checkSession: async () => {
    try {
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) throw sessionError;

      if (session) {
        await get()._loadUserContext(session);
      } else {
        set({ session: null, user: null, restauranteId: null, suscripcion: null, isLoading: false });
      }
    } catch (error) {
      console.error('❌ [Auth] Error validando sesión:', error.message);
      set({ session: null, user: null, restauranteId: null, suscripcion: null, isLoading: false });
    }
  },

  // ── 2. Login ─────────────────────────────────────────────────────────────
  login: async (email, password) => {
    set({ isLoading: true, error: null });
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      await get()._loadUserContext(data.session);
      return true;
    } catch (error) {
      set({ error: error.message, isLoading: false });
      return false;
    }
  },

  // ── 3. Logout ────────────────────────────────────────────────────────────
  logout: async () => {
    set({ isLoading: true });
    await supabase.auth.signOut();
    set({ session: null, user: null, restauranteId: null, suscripcion: null, isLoading: false });
  },

  // ── 4. HELPER PRIVADO: carga usuario + restaurante_id + suscripcion ──────
  // Se llama desde checkSession y login para no duplicar lógica.
  _loadUserContext: async (session) => {
    try {
      const username = session.user.email.split('@')[0].toLowerCase().trim();

      // Busca el usuario en la tabla 'usuarios' (incluye restaurante_id y rol)
      const { data: userData, error: userError } = await supabase
        .from('usuarios')
        .select('*')
        .ilike('username', username)
        .single();

      if (userError || !userData) throw new Error('Usuario no encontrado en el sistema.');

      const restauranteId = userData.restaurante_id;

      // Verifica suscripción activa y vigente
      const hoy = new Date().toISOString().split('T')[0];
      const { data: susData } = await supabase
        .from('suscripciones')
        .select('*')
        .eq('restaurante_id', restauranteId)
        .eq('estado', 'activo')
        .gte('fecha_vencimiento', hoy)
        .single();

      // ⚠️ Si no hay suscripción vigente, el sistema entra en modo lectura.
      // Los componentes leen useAuthStore().suscripcion para deshabilitar
      // acciones de escritura (no bloquea el login, solo limita operaciones).
      if (!susData) {
        console.warn('⚠️ [Auth] Sin suscripción activa. Modo lectura.');
      }

      // Seteamos el contexto pero mantenemos isLoading:true
      set({
        session,
        user: userData,
        restauranteId,
        suscripcion: susData || null,
        error: null,
        isLoading: true, // ✅ Se mantiene true hasta que fetchInitialData termine
      });

      // Importación dinámica para romper la dependencia circular
      // useAppStore → useAuthStore → useAppStore causaría un ciclo en el módulo
      const { useAppStore } = await import('../../store/useAppStore');
      await useAppStore.getState().fetchInitialData();

      // Solo hasta aquí bajamos el spinner global
      set({ isLoading: false });

    } catch (error) {
      console.error('❌ [Auth] Error cargando contexto de usuario:', error.message);
      // Si falla la carga del contexto, cerramos sesión para no dejar estado inválido
      await supabase.auth.signOut();
      set({
        session: null, user: null, restauranteId: null,
        suscripcion: null, isLoading: false,
        error: error.message
      });
    }
  },

  // ── 5. HELPER: el usuario tiene suscripción activa? ──────────────────────
  puedeOperar: () => {
    return get().suscripcion !== null;
  },
}));