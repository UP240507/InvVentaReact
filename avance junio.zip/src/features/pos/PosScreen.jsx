import { useState, useEffect, useMemo } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useAppStore } from '../../store/useAppStore';
import { useSyncStore } from '../../store/useSyncStore';
import { useAuthStore } from '../auth/useAuthStore';
import { ShoppingCart, ChefHat, CreditCard, ArrowLeft, Trash2, Plus, Minus, Utensils, ReceiptText, BellRing, Users } from 'lucide-react';
import ModalCobro from '../operacion/components/ModalCobro';
import TicketImpresion from './components/TicketImpresion';

// ─── HELPERS DE SANITIZACIÓN Y MATEMÁTICA ──────────────────────────────────
const safeNumber = (val, fallback = 0) => {
  if (val === null || val === undefined || val === '') return fallback;
  const n = Number(val);
  return isNaN(n) ? fallback : n;
};

const safePriceString = (val) => {
  if (val === null || val === undefined || val === '') return 0;
  if (typeof val === 'string') { val = val.replace(',', '.'); }
  const n = Number(val);
  return isNaN(n) ? 0 : n;
};

const getPrecio = (item) => {
  const posibles = ['precio', 'precio_venta', 'precioVenta', 'costo', 'price', 'valor'];
  for (const campo of posibles) {
    if (item?.[campo] !== undefined && item?.[campo] !== null) return safePriceString(item[campo]);
  }
  return 0;
};

const round2 = (num) => Math.round((Number(num) || 0) * 100) / 100;

// ─── COMPONENTE PRINCIPAL ──────────────────────────────────────────────────
export default function PosScreen() {
  const { 
    recetas, mesas, getIva, descontarStock, showToast, 
    configuracion, registrarComandaKDS, registrarAuditoria 
  } = useAppStore();
  
  const { enqueueAction } = useSyncStore();
  const { user } = useAuthStore();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const mesaId = searchParams.get('mesa');
  const mesaActual = useMemo(() => (mesas || []).find(m => String(m.id) === String(mesaId)), [mesas, mesaId]);
  const isMesa = Boolean(mesaActual);

  const [carrito, setCarrito] = useState([]);
  const [categoriaActiva, setCategoriaActiva] = useState('Todas');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showModalCobro, setShowModalCobro] = useState(false);
  const [ticketGenerado, setTicketGenerado] = useState(null);

  useEffect(() => {
    if (isMesa && mesaActual?.orden_actual?.items) {
      const itemsSanitizados = mesaActual.orden_actual.items.map(item => ({
        ...item,
        precio: safePriceString(item?.precio),
        cantidad: safeNumber(item?.cantidad, 1),
        cantidad_enviada: safeNumber(item?.cantidad_enviada, 0)
      }));
      setCarrito(itemsSanitizados);
    } else {
      setCarrito([]); 
    }
  }, [mesaId, isMesa, mesaActual]);

  const menuList = recetas || []; 
  const categoriasUnicas = ['Todas', ...new Set(menuList.map(p => p.categoria || 'Sin Categoría'))];
  const productosFiltrados = menuList.filter(p => categoriaActiva === 'Todas' || p.categoria === categoriaActiva);

  const ivaRaw = safeNumber(getIva?.(), 0.16); 
  const factorIva = 1 + ivaRaw; 

  const subtotal = round2(carrito.reduce((acc, item) => {
    return acc + (getPrecio(item) * safeNumber(item?.cantidad, 0));
  }, 0));

  const totalIva = round2(subtotal * (ivaRaw * 1));
  const granTotal = round2(subtotal + totalIva);

  // ─── ACCIONES DEL CARRITO ────────────────────────────────────────────────
  const handleCambiarComensales = (delta) => {
    if (!isMesa) return;
    const actuales = safeNumber(mesaActual.comensales_reales, 1);
    const nuevos = Math.max(1, actuales + delta); 
    if (nuevos === actuales) return;

    const mesaActualizada = { ...mesaActual, comensales_reales: nuevos };
    enqueueAction('mesas', 'upsert', mesaActualizada);
    useAppStore.setState(prev => ({ mesas: prev.mesas.map(m => m.id === mesaActual.id ? mesaActualizada : m) }));
  };

  const agregarAlCarrito = (producto) => {
    const productoSanitizado = { ...producto, precio: getPrecio(producto), cantidad_enviada: 0 };
    setCarrito(prev => {
      const existe = prev.find(item => item.id === productoSanitizado.id);
      if (existe) {
        return prev.map(item => item.id === productoSanitizado.id ? { ...item, cantidad: safeNumber(item.cantidad, 0) + 1 } : item);
      }
      return [...prev, { ...productoSanitizado, cantidad: 1 }];
    });
  };

  const modificarCantidad = (id, delta) => {
    setCarrito(prev => prev.map(item => {
      if (item.id === id) {
        const nuevaCantidad = safeNumber(item.cantidad, 0) + delta;
        if (nuevaCantidad < (item.cantidad_enviada || 0)) {
          showToast(`Ya hay ${item.cantidad_enviada} en preparación. Cancélalo con perfil de Gerente.`, 'error');
          return item;
        }
        return nuevaCantidad > 0 ? { ...item, cantidad: nuevaCantidad } : item;
      }
      return item;
    }));
  };

  const removerDelCarrito = (id) => {
    const itemEnCarrito = carrito.find(i => i.id === id);
    if (itemEnCarrito && (itemEnCarrito.cantidad_enviada || 0) > 0) {
      showToast('No puedes eliminar un platillo que ya está en la cocina.', 'error');
      return;
    }
    setCarrito(prev => prev.filter(item => item.id !== id));
  };

  // ─── COMANDAS Y PAGOS ────────────────────────────────────────────────────
  const handleGuardarEnMesa = () => {
    if (!isMesa || carrito.length === 0) return;
    
    const itemsParaCocina = carrito
      .filter(item => item.cantidad > (item.cantidad_enviada || 0))
      .map(item => ({ 
          ...item, 
          cantidad: item.cantidad - (item.cantidad_enviada || 0),
          destino: configuracion?.enrutamiento?.[item.categoria] || 'Cocina',
          estado: 'pendiente'
      }));

    if (itemsParaCocina.length > 0) {
      const nuevaComanda = {
        id: `CMD-${Date.now()}`, 
        folio: `CMD-${Date.now().toString().slice(-5)}`,
        mesa: mesaActual.nombre,
        mesero: user?.nombre ?? 'Sistema', 
        fecha_hora: new Date().toISOString(),
        items: itemsParaCocina,
        estado: 'preparando'
      };
      
      enqueueAction('comandas', 'insert', nuevaComanda);
      registrarComandaKDS(nuevaComanda);
    }

    const carritoMarcado = carrito.map(item => ({ ...item, cantidad_enviada: item.cantidad }));
    const mesaActualizada = {
      ...mesaActual,
      estado: 'ocupada',
      orden_actual: { items: carritoMarcado, subtotal, total: granTotal }
    };

    enqueueAction('mesas', 'upsert', mesaActualizada);
    useAppStore.setState(prev => ({ mesas: prev.mesas.map(m => m.id === mesaActual.id ? mesaActualizada : m) }));
    showToast('Comanda enviada a producción', 'success');
    navigate('/mesas');
  };

  const handlePedirCuenta = () => {
    if (!isMesa || carrito.length === 0) return;

    const mesaActualizada = { ...mesaActual, estado: 'por_cobrar', orden_actual: { items: carrito, subtotal, total: granTotal } };
    enqueueAction('mesas', 'upsert', mesaActualizada);
    useAppStore.setState(prev => ({ mesas: prev.mesas.map(m => m.id === mesaActual.id ? mesaActualizada : m) }));
    
    showToast('Cuenta solicitada. Notificando a caja...', 'info');
    setTimeout(() => { navigate('/mesas'); }, 1500);
  };

  const handleProcesarVenta = async (datosPago) => {
    setIsProcessing(true);
    const isParcial = datosPago?.isCobroParcial;
    let itemsTicket = carrito;
    let carritoRestante = [];

    if (isParcial) {
      itemsTicket = [];
      carrito.forEach(item => {
        const cantPagada = datosPago.seleccion[item.id] || 0;
        if (cantPagada > 0) itemsTicket.push({ ...item, cantidad: cantPagada });
        
        const cantRestante = safeNumber(item.cantidad, 0) - cantPagada;
        if (cantRestante > 0) {
          carritoRestante.push({ 
            ...item, 
            cantidad: cantRestante,
            cantidad_enviada: Math.max(0, safeNumber(item.cantidad_enviada, 0) - cantPagada)
          });
        }
      });
    }

    const granTotalTicket = round2(safeNumber(datosPago?.totalConPropina, granTotal));
    const subtotalTicket = round2(granTotalTicket / factorIva);
    const ivaTicket = round2(granTotalTicket - subtotalTicket);
    
    const pagosDetalle = datosPago?.pagosDetalle || [];
    const montoEfectivo = round2(pagosDetalle.filter(p => p.metodo.toLowerCase() === 'efectivo').reduce((acc, p) => acc + safeNumber(p.monto), 0));
    const montoTarjeta = round2(pagosDetalle.filter(p => p.metodo.toLowerCase() === 'tarjeta').reduce((acc, p) => acc + safeNumber(p.monto), 0));

    const nuevaVentaBD = {
      id: Date.now(), 
      folio: `POS-${Date.now().toString().slice(-5)}`,
      items: itemsTicket, 
      subtotal: subtotalTicket,
      descuento: 0,
      total: granTotalTicket,
      metodo_pago: pagosDetalle.length > 1 ? 'mixto' : (pagosDetalle[0]?.metodo?.toLowerCase() || 'efectivo'),
      efectivo: montoEfectivo,
      tarjeta: montoTarjeta,
      usuario: user?.nombre ?? 'Sistema', 
      fecha: new Date().toISOString(),
      propina: safeNumber(datosPago?.propina, 0),
      mesa: isMesa ? Number(mesaActual.id) : null
    };

    const ventaVisual = {
      ...nuevaVentaBD,
      iva: ivaTicket,
      cambio_entregado: safeNumber(datosPago?.cambio, 0),
      mesa_nombre: isMesa ? mesaActual.nombre : 'Directa',
      _quedaGente: isParcial && carritoRestante.length > 0
    };

    enqueueAction('ventas', 'insert', nuevaVentaBD);
    useAppStore.setState(prev => ({ ventas: [...(prev.ventas || []), nuevaVentaBD] }));
    descontarStock(itemsTicket);
    
    registrarAuditoria({
      id: Date.now(), fecha: new Date().toISOString(), usuario: user?.nombre || 'Sistema',
      accion: 'COBRO_TICKET', modulo: 'POS', nivel: 'info',
      detalles: `Folio ${nuevaVentaBD.folio} cobrado. Total: $${granTotalTicket}`
    });

    if (isMesa) {
      if (ventaVisual._quedaGente) {
        const mesaActualizada = { 
          ...mesaActual, estado: 'ocupada', 
          orden_actual: {
            items: carritoRestante,
            total: round2(carritoRestante.reduce((acc, it) => acc + (getPrecio(it) * safeNumber(it.cantidad, 0)) * factorIva, 0))
          } 
        };
        enqueueAction('mesas', 'upsert', mesaActualizada);
        useAppStore.setState(prev => ({ mesas: prev.mesas.map(m => m.id === mesaActual.id ? mesaActualizada : m) }));
        setCarrito(carritoRestante);
      } else {
        const mesaLiberada = { ...mesaActual, estado: 'libre', comensales_reales: 0, orden_actual: null };
        enqueueAction('mesas', 'upsert', mesaLiberada);
        useAppStore.setState(prev => ({ mesas: prev.mesas.map(m => m.id === mesaActual.id ? mesaLiberada : m) }));
        setCarrito([]);
      }
    } else {
      setCarrito([]);
    }

    setShowModalCobro(false);
    setIsProcessing(false);
    setTicketGenerado(ventaVisual);
  };

  const handleCerrarTicket = () => {
    const quedaGente = ticketGenerado?._quedaGente;
    setTicketGenerado(null);
    if (quedaGente) showToast('Ticket individual cobrado. La mesa sigue abierta para el resto.', 'success');
    else if (isMesa) navigate('/mesas');
    else showToast('¡Venta de mostrador cerrada!', 'success');
  };

  return (
    <div className="h-screen flex flex-col lg:flex-row bg-slate-50 dark:bg-ui-obsidiana font-sans overflow-hidden text-slate-800 dark:text-ui-text transition-colors duration-500">
      
      {/* ─── PANEL IZQUIERDO: MENÚ DE PRODUCTOS ─── */}
      <div className="flex-1 flex flex-col h-[50vh] lg:h-screen border-r border-slate-200 dark:border-ui-border bg-slate-50 dark:bg-ui-obsidiana transition-colors duration-500">
        
        {/* Header Menú */}
        <div className="bg-white dark:bg-ui-humo p-5 border-b border-slate-200 dark:border-ui-border flex items-center justify-between shadow-sm z-10 transition-colors duration-500">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-100 dark:hover:bg-ui-border rounded-xl text-slate-500 dark:text-ui-muted hover:text-slate-800 dark:hover:text-brand-nacar transition-colors">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-xl font-black font-syne text-slate-900 dark:text-brand-nacar">Catálogo de Venta</h1>
              <p className="text-xs font-bold text-slate-500 dark:text-ui-muted uppercase tracking-widest">{productosFiltrados.length} listos</p>
            </div>
          </div>
        </div>

        {/* Categorías */}
        <div className="bg-white dark:bg-ui-humo px-4 py-3 border-b border-slate-200 dark:border-ui-border flex gap-3 overflow-x-auto custom-scrollbar shrink-0 transition-colors duration-500">
          {categoriasUnicas.map(cat => (
            <button key={cat} onClick={() => setCategoriaActiva(cat)}
              className={`px-5 py-2.5 rounded-xl font-black text-sm whitespace-nowrap transition-all border ${
                categoriaActiva === cat 
                ? 'bg-brand-arrecife text-white dark:text-brand-nacar shadow-lg shadow-brand-arrecife/30 border-brand-arrecife' 
                : 'bg-slate-50 dark:bg-ui-obsidiana text-slate-500 dark:text-ui-muted border-transparent hover:border-slate-200 dark:hover:border-ui-border hover:text-slate-800 dark:hover:text-brand-nacar'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid de Productos */}
        <div className="flex-1 overflow-y-auto p-5 custom-scrollbar bg-slate-50 dark:bg-ui-obsidiana transition-colors duration-500">
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-4">
            {productosFiltrados.map(prod => (
              <button key={prod.id} onClick={() => agregarAlCarrito(prod)}
                className="bg-white dark:bg-ui-humo border-2 border-slate-100 dark:border-ui-border p-5 rounded-brand flex flex-col items-center justify-center text-center gap-3 hover:border-brand-amatista dark:hover:border-brand-amatista hover:shadow-lg hover:-translate-y-1 transition-all group"
              >
                <div className="w-16 h-16 bg-slate-50 dark:bg-ui-obsidiana rounded-full flex items-center justify-center group-hover:bg-brand-amatista/10 dark:group-hover:bg-brand-amatista/20 transition-colors">
                  <Utensils className="w-6 h-6 text-slate-400 dark:text-ui-muted group-hover:text-brand-amatista transition-colors" />
                </div>
                <div>
                  <p className="font-black text-slate-800 dark:text-brand-nacar text-sm leading-tight line-clamp-2">{prod.nombre}</p>
                  <p className="text-emerald-600 dark:text-brand-cesped font-black mt-2 text-lg">${getPrecio(prod).toLocaleString('es-MX', {minimumFractionDigits: 2})}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ─── PANEL DERECHO: TICKET / CARRITO ─── */}
      <div className="w-full lg:w-[400px] xl:w-[450px] flex flex-col h-[50vh] lg:h-screen bg-white dark:bg-ui-humo shadow-2xl z-20 border-l border-slate-200 dark:border-ui-border transition-colors duration-500">
        
        {/* Header de la Mesa/Ticket */}
        <div className={`p-6 flex items-center justify-between border-b border-slate-200 dark:border-ui-border transition-colors duration-500 ${isMesa ? 'bg-brand-arrecife/5 dark:bg-brand-arrecife/10' : 'bg-slate-50 dark:bg-ui-obsidiana'}`}>
          <div className="flex items-center gap-3 text-slate-800 dark:text-brand-nacar">
            {isMesa ? <ChefHat className={`w-7 h-7 ${isMesa ? 'text-brand-arrecife' : 'text-indigo-500 dark:text-brand-amatista'}`} /> : <ShoppingCart className="w-7 h-7 text-indigo-500 dark:text-brand-amatista" />}
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-ui-muted mb-0.5">{isMesa ? 'Comanda para' : 'Venta Rápida'}</p>
              <h2 className="text-xl font-black font-syne tracking-tight leading-none">
                {isMesa ? mesaActual.nombre : 'Mostrador'}
              </h2>
            </div>
          </div>
          
          {isMesa && (
            <div className="flex items-center gap-2 bg-white dark:bg-ui-obsidiana px-3 py-1.5 rounded-xl border border-slate-200 dark:border-ui-border">
              <Users className="w-4 h-4 text-slate-400 dark:text-ui-muted" />
              <button onClick={() => handleCambiarComensales(-1)} className="w-6 h-6 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-ui-border rounded-lg text-lg font-black leading-none active:scale-95 text-slate-700 dark:text-brand-nacar">-</button>
              <span className="font-black text-sm w-4 text-center text-brand-arrecife">{safeNumber(mesaActual?.comensales_reales, 1)}</span>
              <button onClick={() => handleCambiarComensales(1)} className="w-6 h-6 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-ui-border rounded-lg text-lg font-black leading-none active:scale-95 text-slate-700 dark:text-brand-nacar">+</button>
            </div>
          )}
        </div>

        {/* Lista de Artículos */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3 custom-scrollbar bg-slate-50/50 dark:bg-ui-obsidiana/50 transition-colors duration-500">
          {carrito.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 dark:text-ui-muted">
              <ReceiptText className="w-20 h-20 mb-6 opacity-30" />
              <p className="font-black text-center text-lg font-syne uppercase tracking-widest opacity-50">Comanda Vacía</p>
              <p className="font-bold text-center mt-2 text-sm">Selecciona productos del menú</p>
            </div>
          ) : (
            carrito.map(item => (
              <div key={item.id} className="bg-white dark:bg-ui-humo border border-slate-200 dark:border-ui-border p-4 rounded-2xl flex gap-3 hover:border-brand-amatista/30 transition-colors">
                <div className="flex-1">
                  <h4 className="font-black text-slate-800 dark:text-brand-nacar text-sm leading-tight">{item.nombre}</h4>
                  <p className="text-emerald-600 dark:text-brand-cesped font-black text-sm mt-1">
                    ${round2(getPrecio(item)*safeNumber(item.cantidad, 0)).toLocaleString('es-MX', {minimumFractionDigits:2})}
                  </p>
                  {(item.cantidad_enviada || 0) > 0 && (
                    <span className="text-[10px] font-black text-amber-600 dark:text-brand-ambar bg-amber-50 dark:bg-brand-ambar/10 border border-amber-200 dark:border-brand-ambar/20 px-2 py-1 rounded-md mt-2 inline-block uppercase tracking-widest">
                      En cocina: {item.cantidad_enviada}
                    </span>
                  )}
                </div>
                
                <div className="flex items-center gap-1 bg-slate-50 dark:bg-ui-obsidiana border border-slate-200 dark:border-ui-border p-1 rounded-xl shrink-0 h-fit">
                  <button onClick={() => modificarCantidad(item.id, -1)} className="w-8 h-8 bg-white dark:bg-ui-humo text-slate-700 dark:text-brand-nacar rounded-lg flex items-center justify-center active:scale-95 hover:bg-slate-100 dark:hover:bg-ui-border transition-colors shadow-sm dark:shadow-none">
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-8 text-center font-black text-slate-800 dark:text-brand-nacar">{safeNumber(item.cantidad, 0)}</span>
                  <button onClick={() => modificarCantidad(item.id, 1)} className="w-8 h-8 bg-white dark:bg-ui-humo text-slate-700 dark:text-brand-nacar rounded-lg flex items-center justify-center active:scale-95 hover:bg-slate-100 dark:hover:bg-ui-border transition-colors shadow-sm dark:shadow-none">
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                
                <button onClick={() => removerDelCarrito(item.id)} className="w-10 h-10 flex items-center justify-center text-rose-500 dark:text-brand-arrecife/80 hover:bg-rose-50 dark:hover:bg-brand-arrecife/20 hover:text-rose-600 dark:hover:text-brand-arrecife rounded-xl transition-colors shrink-0">
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Resumen Financiero y Acciones */}
        <div className="p-6 bg-white dark:bg-ui-humo border-t border-slate-200 dark:border-ui-border transition-colors duration-500">
          <div className="space-y-3 mb-6">
            <div className="flex justify-between text-slate-500 dark:text-ui-muted font-bold text-sm">
              <span>Subtotal</span>
              <span>${subtotal.toLocaleString('es-MX', {minimumFractionDigits:2})}</span>
            </div>
            <div className="flex justify-between text-slate-500 dark:text-ui-muted font-bold text-sm">
              <span>IVA ({ivaRaw * 100}%)</span>
              <span>${totalIva.toLocaleString('es-MX', {minimumFractionDigits:2})}</span>
            </div>
            <div className="flex justify-between text-slate-900 dark:text-brand-nacar font-black text-3xl pt-4 border-t border-slate-200 dark:border-ui-border border-dashed">
              <span>Total</span>
              <span className="text-emerald-500 dark:text-brand-cesped">${granTotal.toLocaleString('es-MX', {minimumFractionDigits:2})}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3">
            {isMesa && (
              <div className="grid grid-cols-2 gap-3">
                <button onClick={handleGuardarEnMesa} disabled={carrito.length === 0}
                  className="w-full bg-slate-100 dark:bg-ui-obsidiana hover:bg-slate-200 dark:hover:bg-ui-border border border-slate-200 dark:border-ui-border disabled:opacity-50 text-slate-800 dark:text-brand-nacar font-black py-4 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95 text-sm"
                >
                  <ChefHat className="w-5 h-5 text-indigo-500 dark:text-brand-amatista" /> A Producción
                </button>
                
                <button onClick={handlePedirCuenta} disabled={carrito.length === 0}
                  className="w-full bg-indigo-50 dark:bg-brand-amatista/10 hover:bg-indigo-100 dark:hover:bg-brand-amatista/20 border border-indigo-200 dark:border-brand-amatista/30 disabled:opacity-50 text-indigo-600 dark:text-brand-amatista font-black py-4 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95 text-sm"
                >
                  <BellRing className="w-5 h-5" /> Pedir Cuenta
                </button>
              </div>
            )}
            
            <button onClick={() => setShowModalCobro(true)} disabled={carrito.length === 0 || isProcessing}
              className={`w-full font-black py-5 rounded-xl shadow-lg flex items-center justify-center gap-2 transition-all active:scale-95 text-lg ${
                isMesa 
                ? 'bg-brand-arrecife text-white dark:text-brand-nacar shadow-brand-arrecife/20 hover:bg-orange-600' 
                : 'bg-emerald-500 dark:bg-brand-cesped text-white dark:text-ui-obsidiana shadow-emerald-500/20 dark:shadow-brand-cesped/20 hover:bg-emerald-600 dark:hover:bg-[#00c98c]'
              } disabled:opacity-50 disabled:shadow-none`}
            >
              <CreditCard className="w-6 h-6" /> 
              {isProcessing ? 'Procesando...' : (isMesa ? 'Cerrar Mesa y Cobrar' : 'Cobrar Ticket')}
            </button>
          </div>
        </div>
      </div>

      {showModalCobro && (
        <ModalCobro total={granTotal} comensales={isMesa ? safeNumber(mesaActual?.comensales_reales, 1) : 1}
          carrito={carrito} onClose={() => setShowModalCobro(false)} onProcesarPago={handleProcesarVenta}
        />
      )}

      {ticketGenerado && <TicketImpresion venta={ticketGenerado} onClose={handleCerrarTicket} />}

    </div>
  );
}