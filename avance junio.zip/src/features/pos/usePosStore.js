// src/features/pos/usePosStore.js
import { create } from 'zustand';
import { useAppStore } from '../../store/useAppStore';

export const usePosStore = create((set, get) => ({
    // Orden actual
    orden: [],           // [{ receta, cantidad, precioUnit, subtotal, nota }]
    busqueda: '',
    categoriaFiltro: '',
    metodoPago: 'efectivo',
    efectivoPagado: 0,
    descuento: 0,        // %
    propina: 0,          // %

    // Getters derivados del AppStore (fuente única de verdad)
    getMenu:       () => useAppStore.getState().recetas.filter(r => r.activo !== false),
    getCategorias: () => {
        const cats = [...new Set(useAppStore.getState().recetas.map(r => r.categoria || 'Sin categoría'))];
        return ['Todas', ...cats];
    },

    // Filtrado
    getMenuFiltrado: () => {
        const { busqueda, categoriaFiltro } = get();
        return get().getMenu().filter(r => {
            const matchTexto = !busqueda ||
                r.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
                (r.codigo_pos || '').toLowerCase().includes(busqueda.toLowerCase());
            const matchCat = !categoriaFiltro || r.categoria === categoriaFiltro;
            return matchTexto && matchCat;
        });
    },

    // Cálculos financieros
    getCalculos: () => {
        const { orden, descuento, propina } = get();
        const iva = useAppStore.getState().getIva();
        const subtotal     = orden.reduce((s, i) => s + i.subtotal, 0);
        const descuentoAmt = subtotal * (descuento / 100);
        const baseConDesc  = subtotal - descuentoAmt;
        const ivaAmt       = baseConDesc * iva;
        const propinaAmt   = baseConDesc * (propina / 100);
        const total        = baseConDesc + ivaAmt + propinaAmt;
        return { subtotal, descuentoAmt, ivaAmt, propinaAmt, total };
    },

    // Acciones
    setBusqueda:      (v) => set({ busqueda: v }),
    setCategoriaFiltro: (v) => set({ categoriaFiltro: v }),
    setMetodoPago:    (v) => set({ metodoPago: v, efectivoPagado: 0 }),
    setEfectivoPagado:(v) => set({ efectivoPagado: v }),
    setDescuento:     (v) => set({ descuento: Math.min(100, Math.max(0, v)) }),
    setPropina:       (v) => set({ propina: Math.min(100, Math.max(0, v)) }),

    agregarItem: (receta) => set(state => {
        const existe = state.orden.find(i => i.receta.id === receta.id);
        if (existe) {
            return {
                orden: state.orden.map(i =>
                    i.receta.id === receta.id
                        ? { ...i, cantidad: i.cantidad + 1, subtotal: (i.cantidad + 1) * i.precioUnit }
                        : i
                )
            };
        }
        return {
            orden: [...state.orden, {
                receta,
                cantidad: 1,
                precioUnit: receta.precio_venta,
                subtotal: receta.precio_venta,
                nota: '',
            }]
        };
    }),

    quitarItem: (recetaId) => set(state => ({
        orden: state.orden.filter(i => i.receta.id !== recetaId)
    })),

    actualizarCantidad: (recetaId, cantidad) => set(state => ({
        orden: cantidad <= 0
            ? state.orden.filter(i => i.receta.id !== recetaId)
            : state.orden.map(i =>
                i.receta.id === recetaId
                    ? { ...i, cantidad, subtotal: cantidad * i.precioUnit }
                    : i
            )
    })),

    setNota: (recetaId, nota) => set(state => ({
        orden: state.orden.map(i => i.receta.id === recetaId ? { ...i, nota } : i)
    })),

    limpiarOrden: () => set({
        orden: [], busqueda: '', descuento: 0,
        propina: 0, efectivoPagado: 0, metodoPago: 'efectivo',
    }),
}));
