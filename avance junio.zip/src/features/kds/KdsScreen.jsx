import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../../store/useAppStore';
import { supabase } from '../../api/supabase'; 
import { ChefHat, CheckCircle2, Clock, Trash2, CheckSquare, Square, AlertTriangle, Moon, Sun } from 'lucide-react';

const TicketTimer = ({ horaEntrada }) => {
  const [minutos, setMinutos] = useState(0);

  useEffect(() => {
    const calcularTiempo = () => {
      const diffMs = Date.now() - new Date(horaEntrada || Date.now()).getTime();
      setMinutos(Math.floor(diffMs / 60000));
    };
    calcularTiempo();
    const interval = setInterval(calcularTiempo, 10000);
    return () => clearInterval(interval);
  }, [horaEntrada]);

  let colorClass = 'bg-emerald-50 text-emerald-600 border border-emerald-200 dark:bg-brand-cesped/10 dark:text-brand-cesped dark:border-brand-cesped/20';
  if (minutos >= 15) colorClass = 'bg-rose-50 text-rose-600 border border-rose-200 dark:bg-brand-arrecife/10 dark:text-brand-arrecife dark:border-brand-arrecife/20 animate-pulse';
  else if (minutos >= 10) colorClass = 'bg-amber-50 text-amber-600 border border-amber-200 dark:bg-brand-ambar/10 dark:text-brand-ambar dark:border-brand-ambar/20';

  return (
    <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-widest ${colorClass} shadow-sm`}>
      <Clock className="w-3.5 h-3.5" />
      {minutos} min
    </div>
  );
};

export default function KdsScreen() {
  const { comandas_activas, iniciarSuscripcionKDS, showToast } = useAppStore();
  const navigate = useNavigate();
  
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(document.documentElement.classList.contains('dark'));

  const toggleTheme = () => {
    if (isDarkMode) {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
      setIsDarkMode(false);
    } else {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
      setIsDarkMode(true);
    }
  };

  useEffect(() => {
    const sub = iniciarSuscripcionKDS();
    return () => { if (sub) supabase.removeChannel(sub); };
  }, [iniciarSuscripcionKDS]);

  const toggleItemStatus = async (comandaId, itemId) => {
    const comanda = comandas_activas.find(c => c.id === comandaId);
    if (!comanda) return;
    const nuevosItems = comanda.items.map(item => 
      item.id === itemId ? { ...item, completado: !item.completado } : item
    );
    useAppStore.setState(prev => ({
      comandas_activas: prev.comandas_activas.map(c => c.id === comandaId ? { ...c, items: nuevosItems } : c)
    }));
    await supabase.from('comandas').update({ items: nuevosItems }).eq('id', comandaId);
  };

  const completarOrden = async (comandaId) => {
    await supabase.from('comandas').update({ estado: 'completada' }).eq('id', comandaId);
    useAppStore.setState(prev => ({ comandas_activas: prev.comandas_activas.filter(c => c.id !== comandaId) }));
  };

  const ejecutarLimpiezaTotal = async () => {
    const ids = comandas_activas.map(c => String(c.id));
    if (ids.length === 0) return;
    
    try {
      const { error } = await supabase.from('comandas').update({ estado: 'cancelada' }).in('id', ids);
      if (error) throw error;
      useAppStore.setState({ comandas_activas: [] });
      showToast('Todas las órdenes fueron canceladas', 'success');
    } catch (err) {
      console.error('⚠️ Error BD:', err.message);
      showToast('Fallo de red: No se pudieron cancelar las órdenes', 'error');
    } finally {
      setShowConfirmModal(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-ui-obsidiana p-6 md:p-8 text-slate-800 dark:text-ui-text font-sans overflow-y-auto custom-scrollbar transition-colors duration-500 relative z-0">
      
      {/* 🌟 PATRÓN DE FONDO (Diseño Texturizado) 🌟 */}
      <div className="fixed inset-0 opacity-[0.03] dark:opacity-[0.05] pointer-events-none -z-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)', backgroundSize: '24px 24px' }}></div>

      {/* HEADER KDS */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 border-b-2 border-slate-200 dark:border-ui-border pb-6 relative z-10 gap-4">
        <div className="flex items-center gap-5">
          <button 
            onClick={() => navigate('/dashboard')}
            className="p-3 bg-white dark:bg-ui-humo hover:bg-slate-100 dark:hover:bg-ui-border border-2 border-slate-200 dark:border-ui-border rounded-2xl transition-all active:scale-95 shadow-sm group"
            title="Volver al Dashboard"
          >
            <ChefHat className="w-8 h-8 text-indigo-500 dark:text-brand-amatista group-hover:scale-110 transition-transform" />
          </button>
          <div>
            <h1 className="text-3xl font-black font-syne text-slate-900 dark:text-brand-nacar tracking-tight">Monitor de Producción</h1>
            <p className="text-slate-500 dark:text-ui-muted font-bold tracking-widest uppercase text-xs mt-1">{comandas_activas?.length || 0} comandas en fila</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
          <button onClick={toggleTheme} className="p-3 bg-white dark:bg-ui-humo border-2 border-slate-200 dark:border-ui-border rounded-xl text-slate-500 dark:text-brand-ambar hover:bg-slate-100 dark:hover:bg-ui-border transition-all active:scale-95 shadow-sm">
            {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>

          {(comandas_activas?.length || 0) > 0 && (
            <button onClick={() => setShowConfirmModal(true)} className="flex items-center gap-2 px-5 py-3 bg-rose-50 dark:bg-brand-arrecife/10 hover:bg-rose-100 dark:hover:bg-brand-arrecife border-2 border-rose-200 dark:border-brand-arrecife/20 text-rose-600 dark:text-brand-arrecife dark:hover:text-ui-obsidiana rounded-xl font-black text-sm uppercase tracking-widest transition-all shadow-sm">
              <Trash2 className="w-4 h-4" /> Purgar Todo
            </button>
          )}
        </div>
      </div>

      {/* GRID DE TICKETS */}
      <div className="relative z-10">
        {(!comandas_activas || comandas_activas.length === 0) ? (
          <div className="h-[60vh] flex flex-col items-center justify-center text-slate-400 dark:text-ui-muted">
            <CheckCircle2 className="w-24 h-24 mb-6 opacity-20" />
            <h2 className="text-3xl font-black font-syne opacity-50">Cocina Despejada</h2>
            <p className="font-bold mt-2 uppercase tracking-widest text-xs">Esperando órdenes...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 items-start">
            {comandas_activas.map(orden => {
              const todosCompletos = orden.items.every(i => i.completado);
              
              return (
                <div key={orden.id} className={`bg-white/90 dark:bg-ui-humo/90 backdrop-blur-md border-2 rounded-[2rem] overflow-hidden shadow-xl transition-all duration-300 ${todosCompletos ? 'border-emerald-400 dark:border-brand-cesped/50 shadow-emerald-500/10' : 'border-slate-200 dark:border-ui-border'}`}>
                  
                  <div className={`p-5 flex justify-between items-start border-b-2 border-slate-100 dark:border-ui-border ${todosCompletos ? 'bg-emerald-50 dark:bg-brand-cesped/5' : 'bg-slate-50/50 dark:bg-ui-obsidiana/30'}`}>
                    <div>
                      <h3 className="text-2xl font-black text-slate-900 dark:text-brand-nacar font-syne leading-none">{orden.mesa}</h3>
                      <p className="text-[10px] font-black text-indigo-500 dark:text-brand-amatista mt-2 uppercase tracking-widest">{orden.mesero} • {orden.folio || orden.id.slice(-5)}</p>
                    </div>
                    <TicketTimer horaEntrada={orden.fecha_hora} />
                  </div>

                  <div className="p-3 space-y-2">
                    {orden.items.map((item, idx) => (
                      <div key={item.id || idx} onClick={() => toggleItemStatus(orden.id, item.id)}
                        className={`flex gap-3 p-4 rounded-2xl cursor-pointer transition-all border-2 ${
                          item.completado 
                          ? 'bg-slate-50 dark:bg-ui-obsidiana/50 border-slate-100 dark:border-ui-border opacity-50 scale-[0.98]' 
                          : 'bg-white dark:bg-ui-obsidiana border-slate-100 dark:border-ui-border hover:border-indigo-300 dark:hover:border-brand-amatista/50 shadow-sm'
                        }`}
                      >
                        <div className="mt-0.5">
                          {item.completado ? <CheckSquare className="w-6 h-6 text-emerald-500 dark:text-brand-cesped" /> : <Square className="w-6 h-6 text-slate-300 dark:text-ui-muted" />}
                        </div>
                        <div>
                          <p className={`font-black text-lg leading-tight ${item.completado ? 'text-emerald-600 dark:text-brand-cesped line-through' : 'text-slate-800 dark:text-brand-nacar'}`}>
                            <span className="text-indigo-500 dark:text-brand-amatista mr-2 text-xl">{item.cantidad}x</span>
                            {item.nombre}
                          </p>
                          {item.notas && (
                            <p className="text-xs font-black text-amber-700 dark:text-brand-ambar mt-2 bg-amber-100 dark:bg-brand-ambar/10 border border-amber-200 dark:border-brand-ambar/20 px-3 py-1.5 rounded-xl inline-block">
                              📝 {item.notas}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="p-4 bg-slate-50/50 dark:bg-ui-obsidiana/30 border-t-2 border-slate-100 dark:border-ui-border">
                    <button onClick={() => completarOrden(orden.id)}
                      className={`w-full py-4 rounded-2xl font-black text-sm tracking-widest uppercase transition-all active:scale-95 shadow-md ${
                        todosCompletos 
                          ? 'bg-emerald-500 hover:bg-emerald-600 dark:bg-brand-cesped dark:hover:bg-[#00c98c] text-white dark:text-ui-obsidiana shadow-emerald-500/30 dark:shadow-[0_0_20px_rgba(0,229,160,0.3)] scale-[1.02]' 
                          : 'bg-slate-200 hover:bg-slate-300 dark:bg-ui-border dark:hover:bg-ui-muted text-slate-600 dark:text-brand-nacar'
                      }`}
                    >
                      {todosCompletos ? '✓ Despachar Orden' : 'Forzar Salida'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* MODAL CUSTOM DE PURGA */}
      {showConfirmModal && (
        <div className="fixed inset-0 bg-slate-900/60 dark:bg-ui-obsidiana/80 backdrop-blur-md z-[100] flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-ui-humo rounded-[2.5rem] p-8 max-w-sm w-full shadow-2xl text-center border-2 border-slate-100 dark:border-ui-border animate-in zoom-in-95">
            <div className="w-20 h-20 bg-rose-100 dark:bg-brand-arrecife/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertTriangle className="w-10 h-10 text-rose-500 dark:text-brand-arrecife" />
            </div>
            <h2 className="text-2xl font-black font-syne text-slate-900 dark:text-brand-nacar mb-2">¿Purgar Producción?</h2>
            <p className="text-slate-500 dark:text-ui-muted font-bold text-sm mb-8">
              Esta acción cancelará <strong>todas</strong> las comandas activas en la pantalla. No se puede deshacer.
            </p>
            <div className="flex flex-col gap-3">
              <button 
                onClick={ejecutarLimpiezaTotal}
                className="w-full bg-rose-500 hover:bg-rose-600 dark:bg-brand-arrecife dark:hover:bg-orange-600 text-white dark:text-ui-obsidiana py-4 rounded-xl font-black uppercase tracking-widest shadow-lg shadow-rose-500/30 dark:shadow-brand-arrecife/20 transition-transform active:scale-95"
              >
                Sí, Purgar Todo
              </button>
              <button 
                onClick={() => setShowConfirmModal(false)}
                className="w-full bg-slate-100 dark:bg-ui-obsidiana hover:bg-slate-200 dark:hover:bg-ui-border text-slate-600 dark:text-brand-nacar py-4 rounded-xl font-bold transition-colors"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}