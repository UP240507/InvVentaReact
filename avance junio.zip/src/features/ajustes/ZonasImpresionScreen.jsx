import { useState, useEffect } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { useSyncStore } from '../../store/useSyncStore';
import { 
  Printer, Plus, X, Save, ChefHat, 
  ArrowRight, Tag, CheckCircle2, Server
} from 'lucide-react';

export default function ZonasImpresionScreen() {
  const { configuracion, updateConfiguracion, showToast } = useAppStore();
  const { enqueueAction } = useSyncStore();

  // Estado local para zonas de producción (Ej. ['Cocina', 'Barra', 'Parrilla'])
  const [zonas, setZonas] = useState(['Cocina', 'Barra']);
  const [nuevaZona, setNuevaZona] = useState('');

  // Estado local para el mapa de enrutamiento: { 'NombreCategoria': 'NombreZona' }
  const [enrutamiento, setEnrutamiento] = useState({});

  const categoriasMenu = configuracion?.categorias || [];

  // Cargar datos al montar
  useEffect(() => {
    if (configuracion) {
      if (configuracion.zonas_produccion?.length > 0) {
        setZonas(configuracion.zonas_produccion);
      }
      if (configuracion.enrutamiento) {
        setEnrutamiento(configuracion.enrutamiento);
      }
    }
  }, [configuracion]);

  // ─── ACCIONES DE ZONAS ──────────────────────────────────────────────────
  const agregarZona = (e) => {
    e.preventDefault();
    if (!nuevaZona.trim() || zonas.includes(nuevaZona.trim())) return;
    setZonas([...zonas, nuevaZona.trim()]);
    setNuevaZona('');
  };

  const quitarZona = (zonaEliminar) => {
    const nuevasZonas = zonas.filter(z => z !== zonaEliminar);
    setZonas(nuevasZonas);
    
    // Si eliminamos una zona, reasignamos sus categorías a la primera zona disponible
    const zonaFallback = nuevasZonas[0] || '';
    const nuevoEnrutamiento = { ...enrutamiento };
    Object.keys(nuevoEnrutamiento).forEach(cat => {
      if (nuevoEnrutamiento[cat] === zonaEliminar) {
        nuevoEnrutamiento[cat] = zonaFallback;
      }
    });
    setEnrutamiento(nuevoEnrutamiento);
  };

  const asignarCategoria = (categoria, zona) => {
    setEnrutamiento(prev => ({ ...prev, [categoria]: zona }));
  };

  // ─── GUARDADO GLOBAL ────────────────────────────────────────────────────
  const guardar = () => {
    const payload = { 
      ...configuracion, 
      zonas_produccion: zonas,
      enrutamiento: enrutamiento
    };

    updateConfiguracion(payload);
    enqueueAction('configuracion', 'upsert', payload);
    showToast('Enrutamiento de KDS/Impresión actualizado', 'success');
  };

  return (
    <div className="p-8 max-w-5xl mx-auto flex flex-col h-full animate-in fade-in duration-500">
      
      {/* HEADER */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-xl shadow-slate-200/50 mb-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-12 bg-indigo-50 rounded-full -mr-12 -mt-12 opacity-50" />
        <div className="flex items-center gap-6 relative z-10">
          <div className="bg-indigo-600 p-4 rounded-3xl shadow-lg shadow-indigo-600/40">
            <Printer className="w-8 h-8 text-ui-text" />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">Zonas de Producción</h1>
            <p className="text-slate-500 font-bold mt-1">Enruta los platillos al KDS de cocina o barra</p>
          </div>
        </div>
        <button onClick={guardar} className="w-full sm:w-auto bg-slate-900 hover:bg-black text-ui-text px-8 py-4 rounded-2xl font-black text-sm flex items-center justify-center gap-3 shadow-xl transition-all hover:scale-105 active:scale-95">
          <Save className="w-5 h-5" /> Guardar Reglas
        </button>
      </div>

      <div className="flex flex-col lg:flex-row gap-8 flex-1">
        
        {/* PANEL IZQUIERDO: CREAR ZONAS */}
        <div className="w-full lg:w-1/3 space-y-6">
          <div className="bg-white p-6 rounded-[2rem] border-2 border-slate-50 shadow-sm">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
              <Server className="w-4 h-4" /> Estaciones Activas
            </h3>

            <form onSubmit={agregarZona} className="flex gap-2 mb-6">
              <input type="text" value={nuevaZona} onChange={e => setNuevaZona(e.target.value)} placeholder="Ej. Parrilla, Postres..." 
                className="flex-1 px-4 py-3 bg-slate-50 border-2 border-slate-100 rounded-xl font-bold text-ui-text outline-none focus:border-indigo-500 transition-colors" />
              <button type="submit" className="px-4 py-3 bg-indigo-600 text-ui-text rounded-xl font-black hover:bg-indigo-700 transition-colors">
                <Plus className="w-5 h-5" />
              </button>
            </form>

            <div className="space-y-3">
              {zonas.map(zona => (
                <div key={zona} className="flex justify-between items-center bg-slate-50 border-2 border-slate-100 px-4 py-3 rounded-xl group">
                  <span className="font-black text-slate-700 flex items-center gap-3">
                    <ChefHat className="w-4 h-4 text-slate-400" /> {zona}
                  </span>
                  <button onClick={() => quitarZona(zona)} className="text-slate-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-all">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
              {zonas.length === 0 && (
                <p className="text-sm font-bold text-slate-400 text-center py-4">No hay zonas configuradas.</p>
              )}
            </div>
          </div>
        </div>

        {/* PANEL DERECHO: ENRUTAMIENTO */}
        <div className="w-full lg:w-2/3 bg-white rounded-[2rem] border-2 border-slate-50 shadow-sm p-6 lg:p-8 flex flex-col h-full">
          <h3 className="text-xl font-black text-ui-text mb-2">Mapa de Enrutamiento</h3>
          <p className="text-sm font-bold text-slate-500 mb-8">Selecciona hacia dónde se enviarán los tickets de cada categoría cuando el mesero tome una orden.</p>

          <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-3">
            {categoriasMenu.length === 0 ? (
              <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl p-10 text-center">
                <Tag className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                <h4 className="font-black text-slate-500">No hay categorías</h4>
                <p className="text-xs font-bold text-slate-400 mt-1">Ve a 'Configuración Global' para crear categorías del menú.</p>
              </div>
            ) : (
              categoriasMenu.map(cat => {
                const zonaAsignada = enrutamiento[cat] || zonas[0] || '';

                return (
                  <div key={cat} className="flex flex-col sm:flex-row justify-between items-center p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl gap-4 hover:border-indigo-200 transition-colors">
                    
                    <div className="flex items-center gap-3 w-full sm:w-1/2">
                      <div className="bg-white p-2.5 rounded-xl shadow-sm border border-slate-200"><Tag className="w-4 h-4 text-indigo-500" /></div>
                      <span className="font-black text-ui-text text-lg">{cat}</span>
                    </div>

                    <ArrowRight className="w-5 h-5 text-slate-300 hidden sm:block shrink-0" />

                    <div className="w-full sm:w-1/2">
                      <select 
                        value={zonaAsignada} 
                        onChange={e => asignarCategoria(cat, e.target.value)}
                        className="w-full px-4 py-3 bg-white border-2 border-slate-200 rounded-xl font-black text-indigo-700 outline-none focus:border-indigo-500 cursor-pointer shadow-sm transition-all"
                      >
                        {zonas.length === 0 && <option value="">Sin Zonas</option>}
                        {zonas.map(z => <option key={z} value={z}>Enviar a {z}</option>)}
                      </select>
                    </div>

                  </div>
                );
              })
            )}
          </div>
        </div>

      </div>
    </div>
  );
}