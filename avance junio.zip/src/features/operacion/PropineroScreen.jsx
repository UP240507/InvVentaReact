import { useState, useMemo } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { useAuthStore } from '../auth/useAuthStore';
import { useNavigate } from 'react-router-dom';
import { 
  DollarSign, Calculator, Users, CheckCircle, 
  AlertCircle, ReceiptText, ShieldCheck, Lock
} from 'lucide-react';

export default function PropineroScreen() {
  const { ventas, staff, cerrarTurno, showToast } = useAppStore();
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);

  const ventasHoy = useMemo(() => {
    return ventas || [];
  }, [ventas]);

  const metricas = useMemo(() => {
    let subtotalVentas = 0;
    let propinaTarjeta = 0;

    ventasHoy.forEach(v => {
      subtotalVentas += Number(v.total || 0);
      propinaTarjeta += Number(v.propina || 0); 
    });

    return { 
      ventasTotales: subtotalVentas, 
      propinasSistema: propinaTarjeta 
    };
  }, [ventasHoy]);

  const getPuntosPorRol = (rol) => {
    switch(rol?.toLowerCase()) {
      case 'mesero': return 10;
      case 'barista': return 8;
      case 'cocinero': return 6;
      case 'cajero': return 4;
      default: return 0;
    }
  };

  const [propinaEfectivoManual, setPropinaEfectivoManual] = useState(0);
  const totalARepartir = metricas.propinasSistema + Number(propinaEfectivoManual);

  const staffActivo = useMemo(() => (staff || []).filter(s => s.estado === 'activo'), [staff]);
  const puntosTotales = staffActivo.reduce((acc, emp) => acc + getPuntosPorRol(emp.rol), 0);

  const distribucionFinal = useMemo(() => {
    if (puntosTotales === 0) return [];
    const valorPorPunto = totalARepartir / puntosTotales;
    
    return staffActivo.map(emp => ({
      ...emp,
      puntos: getPuntosPorRol(emp.rol),
      monto_recibir: Math.round((getPuntosPorRol(emp.rol) * valorPorPunto) * 100) / 100
    })).filter(e => e.puntos > 0).sort((a, b) => b.monto_recibir - a.monto_recibir);
  }, [staffActivo, totalARepartir, puntosTotales]);

  const handleCerrarTurno = async () => {
    const confirmar = window.confirm('🚨 ¿Confirmas el cierre de turno y la dispersión de propinas? Esto bloqueará las ventas de hoy.');
    if (!confirmar) return;

    setIsProcessing(true);

    const datosCierre = {
      usuario: user?.nombre || 'Administrador',
      ventasTotales: metricas.ventasTotales,
      propinasTotales: totalARepartir,
      distribucion: distribucionFinal
    };

    await cerrarTurno(datosCierre);
    showToast('Turno cerrado y propinas registradas con éxito', 'success');
    navigate('/dashboard');
  };

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto h-full animate-in fade-in duration-500 transition-colors">
      
      <div className="flex items-center gap-4 mb-8">
        <div className="bg-indigo-500 dark:bg-brand-amatista/20 p-3 rounded-2xl shadow-lg shadow-indigo-500/30 dark:shadow-none border border-transparent dark:border-brand-amatista/30 transition-colors">
          <Calculator className="w-8 h-8 text-white dark:text-brand-amatista" />
        </div>
        <div>
          <h1 className="text-3xl font-black text-slate-900 dark:text-brand-nacar tracking-tight">Cierre y Propinero</h1>
          <p className="text-sm font-bold text-slate-500 dark:text-ui-muted uppercase tracking-widest mt-1">
            Auditoría de Turno y Dispersión
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* PANEL IZQUIERDO */}
        <div className="lg:col-span-1 space-y-6">
          
          <div className="bg-white dark:bg-ui-humo p-6 rounded-3xl border-2 border-slate-100 dark:border-ui-border shadow-sm transition-colors">
            <h3 className="text-xs font-black text-slate-400 dark:text-ui-muted uppercase tracking-widest flex items-center gap-2 mb-4">
              <ReceiptText className="w-4 h-4" /> Ventas del Turno
            </h3>
            <p className="text-3xl font-black text-slate-900 dark:text-brand-nacar mb-2">
              ${metricas.ventasTotales.toLocaleString('es-MX', {minimumFractionDigits: 2})}
            </p>
            <p className="text-sm font-bold text-slate-500 dark:text-ui-muted flex justify-between">
              <span>Tickets cobrados:</span>
              <span className="text-slate-900 dark:text-brand-nacar">{ventasHoy.length}</span>
            </p>
          </div>

          {/* CAJA FUERTE */}
          <div className="bg-slate-900 dark:bg-ui-obsidiana rounded-3xl p-6 text-white shadow-xl relative overflow-hidden border border-slate-800 dark:border-ui-border transition-colors">
            <div className="absolute -right-4 -top-4 opacity-10">
              <DollarSign className="w-32 h-32 text-white dark:text-brand-nacar" />
            </div>
            <h3 className="text-xs font-black text-slate-400 dark:text-ui-muted uppercase tracking-widest mb-6 relative z-10">Fondo a Repartir</h3>
            
            <div className="space-y-4 relative z-10">
              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-300 dark:text-ui-muted font-bold">Propinas en Tarjeta (POS)</span>
                <span className="font-black text-emerald-400 dark:text-brand-cesped">${metricas.propinasSistema.toLocaleString('es-MX', {minimumFractionDigits:2})}</span>
              </div>
              
              <div className="space-y-2">
                <label className="text-slate-300 dark:text-ui-muted font-bold text-sm block">Propinas en Efectivo (Caja)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 font-black text-slate-400 dark:text-ui-muted">$</span>
                  <input 
                    type="number" 
                    min="0"
                    value={propinaEfectivoManual} 
                    onChange={e => setPropinaEfectivoManual(e.target.value)}
                    className="w-full bg-slate-800 dark:bg-ui-humo border-2 border-slate-700 dark:border-ui-border rounded-xl py-3 pl-8 pr-4 font-black text-white dark:text-brand-nacar outline-none focus:border-indigo-500 dark:focus:border-brand-amatista transition-colors"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-700/50 dark:border-ui-border flex justify-between items-center">
                <span className="font-bold text-slate-300 dark:text-ui-muted">Fondo Total:</span>
                <span className="text-3xl font-black text-white dark:text-brand-nacar">${totalARepartir.toLocaleString('es-MX', {minimumFractionDigits:2})}</span>
              </div>
            </div>
          </div>

        </div>

        {/* PANEL DERECHO: DISPERSIÓN */}
        <div className="lg:col-span-2 bg-white dark:bg-ui-humo p-6 md:p-8 rounded-3xl border-2 border-slate-100 dark:border-ui-border shadow-sm flex flex-col transition-colors">
          
          <div className="flex justify-between items-end mb-6 border-b-2 border-slate-100 dark:border-ui-border pb-4 transition-colors">
            <div>
              <h2 className="text-xl font-black text-slate-900 dark:text-brand-nacar flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-500 dark:text-brand-amatista" /> Distribución Sugerida
              </h2>
              <p className="text-xs font-bold text-slate-500 dark:text-ui-muted mt-1">Calculada por puntos de responsabilidad</p>
            </div>
            <div className="text-right">
              <span className="text-xs font-black text-slate-400 dark:text-ui-muted uppercase tracking-widest block">Staff Activo</span>
              <span className="text-lg font-black text-indigo-600 dark:text-brand-amatista">{distribucionFinal.length} personas</span>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar space-y-3 pr-2 mb-6">
            {distribucionFinal.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 dark:text-ui-muted">
                <AlertCircle className="w-12 h-12 mb-3 opacity-20" />
                <p className="font-bold">No hay staff activo para repartir</p>
              </div>
            ) : (
              distribucionFinal.map((emp) => (
                <div key={emp.id} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-ui-obsidiana rounded-2xl border border-slate-100 dark:border-ui-border transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-brand-amatista/10 text-indigo-600 dark:text-brand-amatista font-black flex items-center justify-center border border-indigo-200 dark:border-brand-amatista/30">
                      {emp.nombre.charAt(0)}
                    </div>
                    <div>
                      <p className="font-black text-slate-900 dark:text-brand-nacar leading-tight">{emp.nombre}</p>
                      <p className="text-xs font-bold text-slate-500 dark:text-ui-muted">{emp.rol} • {emp.puntos} pts</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-black text-emerald-600 dark:text-brand-cesped">
                      ${emp.monto_recibir.toLocaleString('es-MX', {minimumFractionDigits: 2})}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>

          <button 
            onClick={handleCerrarTurno}
            disabled={isProcessing || distribucionFinal.length === 0 || totalARepartir === 0}
            className="w-full bg-slate-900 dark:bg-brand-arrecife hover:bg-slate-800 dark:hover:bg-orange-600 text-white dark:text-ui-obsidiana disabled:bg-slate-200 disabled:dark:bg-ui-border disabled:text-slate-400 disabled:dark:text-ui-muted font-black py-5 rounded-2xl shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            {isProcessing ? (
              'Procesando Cierre...'
            ) : (
              <>
                <Lock className="w-5 h-5" /> 
                Aprobar Distribución y Cerrar Turno
              </>
            )}
          </button>

          <p className="text-center text-[10px] font-bold text-slate-400 dark:text-ui-muted uppercase tracking-widest mt-4 flex items-center justify-center gap-1">
            <ShieldCheck className="w-3 h-3" /> Acción auditable por sistema
          </p>

        </div>
      </div>
    </div>
  );
}