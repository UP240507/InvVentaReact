import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../../store/useAppStore';
import { useSyncStore } from '../../store/useSyncStore';
import { Users, CreditCard, Utensils, Plus, Edit2, AlertCircle, LayoutGrid, X, MapPin, ArrowRightLeft, UserCheck, CheckSquare, Square } from 'lucide-react';

export default function MesasScreen() {
  const { mesas, staff, configuracion, showToast } = useAppStore();
  const { enqueueAction } = useSyncStore();
  const navigate = useNavigate();

  const [filtroZona, setFiltroZona] = useState('Todas');
  
  const [modalMesa, setModalMesa] = useState({ show: false, mesa: null });
  const [modalTraspaso, setModalTraspaso] = useState({ show: false, mesaOrigen: null });
  const [modalMeseros, setModalMeseros] = useState(false);

  const [formDataMesa, setFormDataMesa] = useState({ nombre: '', capacidad: 4, zona: 'Salón Principal' });
  const [formTraspaso, setFormTraspaso] = useState({ mesaDestinoId: '', itemsSeleccionados: [] });
  const [asignaciones, setAsignaciones] = useState({}); 

  const zonasUnicas = useMemo(() => {
    const zonas = (mesas || []).map(m => m.zona || 'Sin Área').filter(Boolean);
    return ['Todas', ...new Set(zonas)];
  }, [mesas]);

  const mesasFiltradasYOrdenadas = useMemo(() => {
    return (mesas || [])
      .filter(m => filtroZona === 'Todas' || (m.zona || 'Sin Área') === filtroZona)
      .sort((a, b) => a.nombre.localeCompare(b.nombre, undefined, { numeric: true }));
  }, [mesas, filtroZona]);

  const metricas = useMemo(() => ({
    total: mesas?.length || 0,
    libres: (mesas || []).filter(m => m.estado === 'libre').length,
    ocupadas: (mesas || []).filter(m => m.estado === 'ocupada').length,
    porCobrar: (mesas || []).filter(m => m.estado === 'por_cobrar').length,
  }), [mesas]);

  const meserosActivos = useMemo(() => (staff || []).filter(s => s.activo !== false), [staff]);

  const abrirModalMesa = (mesa = null) => {
    setModalMesa({ show: true, mesa });
    setFormDataMesa({ 
      nombre: mesa?.nombre || `Mesa ${(mesas?.length || 0) + 1}`, 
      capacidad: mesa?.capacidad || 4,
      zona: mesa?.zona || (filtroZona !== 'Todas' ? filtroZona : 'Salón Principal')
    });
  };

  const guardarMesa = (e) => {
    e.preventDefault();
    if (!formDataMesa.nombre.trim() || !formDataMesa.zona.trim()) return showToast('Nombre y Zona obligatorios', 'error');

    const payload = {
      id: modalMesa.mesa ? modalMesa.mesa.id : Date.now(),
      nombre: formDataMesa.nombre.trim(),
      capacidad: Number(formDataMesa.capacidad),
      zona: formDataMesa.zona.trim(),
      estado: modalMesa.mesa ? modalMesa.mesa.estado : 'libre',
      comensales_reales: modalMesa.mesa ? modalMesa.mesa.comensales_reales : 0,
      orden_actual: modalMesa.mesa ? modalMesa.mesa.orden_actual : null
    };

    enqueueAction('mesas', 'upsert', payload);
    useAppStore.setState(prev => {
      const existe = prev.mesas.find(m => m.id === payload.id);
      return { mesas: existe ? prev.mesas.map(m => m.id === payload.id ? payload : m) : [...prev.mesas, payload] };
    });

    showToast(`Mesa ${modalMesa.mesa ? 'actualizada' : 'creada'} exitosamente`, 'success');
    setModalMesa({ show: false, mesa: null });
  };

  const abrirModalTraspaso = (mesa) => {
    setModalTraspaso({ show: true, mesaOrigen: mesa });
    setFormTraspaso({ mesaDestinoId: '', itemsSeleccionados: [] });
  };

  const toggleItemTraspaso = (itemIdx) => {
    setFormTraspaso(prev => {
      const seleccionados = prev.itemsSeleccionados.includes(itemIdx)
        ? prev.itemsSeleccionados.filter(idx => idx !== itemIdx)
        : [...prev.itemsSeleccionados, itemIdx];
      return { ...prev, itemsSeleccionados: seleccionados };
    });
  };

  const seleccionarTodoTraspaso = () => {
    const todos = modalTraspaso.mesaOrigen?.orden_actual?.items?.map((_, idx) => idx) || [];
    setFormTraspaso(prev => ({ ...prev, itemsSeleccionados: prev.itemsSeleccionados.length === todos.length ? [] : todos }));
  };

  const ejecutarTraspaso = () => {
    const { mesaOrigen } = modalTraspaso;
    const { mesaDestinoId, itemsSeleccionados } = formTraspaso;
    
    if (!mesaDestinoId) return showToast('Selecciona una mesa destino', 'error');
    if (itemsSeleccionados.length === 0) return showToast('Selecciona al menos un producto', 'error');

    const destino = mesas.find(m => String(m.id) === String(mesaDestinoId));
    if (!destino) return showToast('Mesa destino no encontrada', 'error');

    const ivaRate = 1 + (configuracion?.iva || 0.16);
    const itemsOriginales = mesaOrigen.orden_actual.items || [];
    const itemsParaMover = itemsOriginales.filter((_, idx) => itemsSeleccionados.includes(idx));
    const itemsRestantes = itemsOriginales.filter((_, idx) => !itemsSeleccionados.includes(idx));

    const calcularTotal = (arr) => arr.reduce((acc, item) => acc + (Number(item.precio || 0) * Number(item.cantidad || 1) * ivaRate), 0);
    
    const payloadOrigen = {
      ...mesaOrigen,
      estado: itemsRestantes.length === 0 ? 'libre' : mesaOrigen.estado,
      comensales_reales: itemsRestantes.length === 0 ? 0 : mesaOrigen.comensales_reales,
      orden_actual: itemsRestantes.length === 0 ? null : { ...mesaOrigen.orden_actual, items: itemsRestantes, total: calcularTotal(itemsRestantes) }
    };

    const nuevosItemsDestino = [...(destino.orden_actual?.items || []), ...itemsParaMover];
    const payloadDestino = {
      ...destino,
      estado: 'ocupada',
      comensales_reales: Math.max(destino.comensales_reales || 1, 1),
      orden_actual: { items: nuevosItemsDestino, total: calcularTotal(nuevosItemsDestino) }
    };

    enqueueAction('mesas', 'upsert', payloadOrigen);
    enqueueAction('mesas', 'upsert', payloadDestino);
    
    useAppStore.setState(prev => ({
      mesas: prev.mesas.map(m => m.id === payloadOrigen.id ? payloadOrigen : m.id === payloadDestino.id ? payloadDestino : m)
    }));

    showToast('Traspaso completado con éxito', 'success');
    setModalTraspaso({ show: false, mesaOrigen: null });
  };

  const getEstadoUI = (estado) => {
    if (estado === 'ocupada') return { color: 'bg-rose-50 border-rose-200 text-rose-600 dark:bg-brand-arrecife/10 dark:text-brand-arrecife dark:border-brand-arrecife/40 shadow-[0_0_15px_rgba(255,95,64,0.15)]', icon: <Users className="w-5 h-5" /> };
    if (estado === 'por_cobrar') return { color: 'bg-amber-50 border-amber-200 text-amber-600 dark:bg-brand-ambar/10 dark:text-brand-ambar dark:border-brand-ambar/40 shadow-[0_0_15px_rgba(255,178,36,0.15)] animate-pulse', icon: <CreditCard className="w-5 h-5" /> };
    return { color: 'bg-emerald-50 border-emerald-200 text-emerald-600 dark:bg-brand-cesped/10 dark:text-brand-cesped dark:border-brand-cesped/30', icon: <Utensils className="w-5 h-5" /> };
  };

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto h-full animate-in fade-in duration-300 flex flex-col min-h-0 text-slate-800 dark:text-ui-text transition-colors">
      
      {/* ─── HEADER & KPI'S ─── */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 mb-6 shrink-0">
        <div>
          <h1 className="text-3xl font-black font-syne text-slate-900 dark:text-brand-nacar flex items-center gap-3 tracking-tight">
            <div className="bg-brand-amatista/10 p-2 rounded-xl">
               <LayoutGrid className="w-8 h-8 text-brand-amatista" />
            </div>
            Mapa Operativo
          </h1>
          <p className="text-xs font-bold text-slate-500 dark:text-ui-muted uppercase tracking-widest mt-2">Control de Piso y Cuentas</p>
        </div>

        <div className="flex flex-wrap items-center gap-2 bg-white dark:bg-ui-humo p-2 rounded-2xl border-2 border-slate-100 dark:border-ui-border shadow-sm">
          <div className="px-3 flex flex-col"><span className="text-[10px] font-black uppercase text-slate-400 dark:text-ui-muted">Libres</span><span className="text-xl font-black font-syne text-emerald-500 dark:text-brand-cesped">{metricas.libres}</span></div>
          <div className="w-px h-8 bg-slate-200 dark:bg-ui-border"></div>
          <div className="px-3 flex flex-col"><span className="text-[10px] font-black uppercase text-slate-400 dark:text-ui-muted">Ocupadas</span><span className="text-xl font-black font-syne text-rose-500 dark:text-brand-arrecife">{metricas.ocupadas}</span></div>
          <div className="w-px h-8 bg-slate-200 dark:bg-ui-border"></div>
          
          <div className="flex gap-2 pl-2">
            <button onClick={() => setModalMeseros(true)} className="bg-slate-50 dark:bg-ui-obsidiana border border-slate-200 dark:border-ui-border hover:border-brand-amatista hover:text-brand-amatista text-slate-400 dark:text-ui-muted p-3 rounded-xl transition-all" title="Asignar Plazas">
              <UserCheck className="w-5 h-5" />
            </button>
            <button onClick={() => abrirModalMesa()} className="bg-brand-amatista hover:bg-indigo-600 text-white dark:text-brand-nacar p-3 rounded-xl shadow-lg transition-transform active:scale-95" title="Añadir Mesa">
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* ─── NAVEGADOR DE ZONAS ─── */}
      <div className="flex gap-3 mb-6 overflow-x-auto custom-scrollbar pb-2 shrink-0">
        {zonasUnicas.map(zona => (
          <button key={zona} onClick={() => setFiltroZona(zona)}
            className={`px-5 py-2.5 rounded-xl font-black text-sm whitespace-nowrap transition-all border-2 flex items-center gap-2 ${
              filtroZona === zona 
              ? 'bg-brand-amatista text-white dark:text-brand-nacar border-brand-amatista shadow-lg shadow-brand-amatista/30' 
              : 'bg-white dark:bg-ui-humo text-slate-500 dark:text-ui-muted border-slate-100 dark:border-transparent hover:border-slate-300 dark:hover:border-ui-border'
            }`}
          >
            {zona !== 'Todas' && <MapPin className="w-4 h-4" />}{zona}
          </button>
        ))}
      </div>

      {/* ─── GRID DE MESAS ─── */}
      <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 pb-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-5">
          {mesasFiltradasYOrdenadas.map(mesa => {
            const ui = getEstadoUI(mesa.estado);
            
            return (
              <div key={mesa.id} className="relative group flex flex-col">
                <button onClick={() => navigate(`/pos?mesa=${mesa.id}`)} className={`flex-1 flex flex-col bg-white dark:bg-ui-humo border-2 rounded-[2rem] p-5 text-left transition-all hover:-translate-y-1 shadow-sm ${ui.color}`}>
                  <div className="flex justify-between items-start w-full mb-4">
                    <div className="p-2.5 rounded-xl bg-white/50 dark:bg-ui-obsidiana/30 backdrop-blur-sm shadow-inner">{ui.icon}</div>
                    {mesa.estado !== 'libre' && (
                       <span className="text-xl font-black font-syne tabular-nums">${(mesa.orden_actual?.total || 0).toLocaleString('es-MX', {minimumFractionDigits: 0})}</span>
                    )}
                  </div>
                  <div className="mt-auto">
                    <h3 className="text-xl font-black font-syne text-slate-900 dark:text-brand-nacar mb-1">{mesa.nombre}</h3>
                    <div className="flex flex-col gap-1.5 mt-2">
                      <span className="text-[9px] font-black uppercase tracking-widest text-indigo-600 dark:text-brand-amatista bg-indigo-50 dark:bg-brand-amatista/10 border border-indigo-200 dark:border-brand-amatista/20 px-2 py-0.5 rounded-md w-fit">
                        {mesa.zona || 'Sin Área'}
                      </span>
                      <span className="text-[10px] font-black uppercase tracking-widest flex items-center gap-1 opacity-80 mt-1">
                        <Users className="w-3 h-3" /> {mesa.estado === 'libre' ? `Cap: ${mesa.capacidad}` : `${mesa.comensales_reales}/${mesa.capacidad}`}
                      </span>
                    </div>
                  </div>
                </button>

                <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                  <button onClick={(e) => { e.stopPropagation(); abrirModalMesa(mesa); }} className="p-2.5 bg-white dark:bg-ui-obsidiana text-slate-500 dark:text-ui-muted hover:text-brand-amatista border border-slate-200 dark:border-ui-border rounded-full shadow-xl" title="Editar Mesa">
                    <Edit2 className="w-4 h-4" />
                  </button>
                  {mesa.estado !== 'libre' && (
                    <button onClick={(e) => { e.stopPropagation(); abrirModalTraspaso(mesa); }} className="p-2.5 bg-rose-500 dark:bg-brand-arrecife text-white dark:text-ui-obsidiana hover:bg-rose-600 dark:hover:bg-orange-500 border border-rose-600 dark:border-brand-arrecife/50 rounded-full shadow-xl" title="Traspasar Artículos">
                      <ArrowRightLeft className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ─── MODAL: TRASPASO DE CUENTAS ─── */}
      {modalTraspaso.show && (
        <div className="fixed inset-0 bg-slate-900/60 dark:bg-ui-obsidiana/80 backdrop-blur-md z-[100] flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-ui-humo rounded-[2.5rem] border-2 border-slate-100 dark:border-ui-border p-6 max-w-2xl w-full shadow-2xl animate-in zoom-in-95 flex flex-col max-h-[90vh]">
            <div className="flex justify-between items-center mb-6 border-b-2 border-slate-50 dark:border-ui-border pb-4 shrink-0">
              <h2 className="text-xl font-black font-syne text-slate-900 dark:text-brand-nacar flex items-center gap-2">
                <ArrowRightLeft className="w-5 h-5 text-rose-500 dark:text-brand-arrecife" /> Traspaso de Cuentas
              </h2>
              <button onClick={() => setModalTraspaso({show:false, mesaOrigen:null})} className="text-slate-400 dark:text-ui-muted hover:text-rose-500 dark:hover:text-brand-nacar p-1"><X className="w-5 h-5"/></button>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 space-y-6">
              <div className="bg-slate-50 dark:bg-ui-obsidiana border-2 border-slate-100 dark:border-ui-border p-5 rounded-2xl">
                <label className="block text-[10px] font-black text-slate-500 dark:text-ui-muted uppercase tracking-widest mb-3">Mover de <span className="text-rose-500 dark:text-brand-arrecife">{modalTraspaso.mesaOrigen?.nombre}</span> hacia:</label>
                <select 
                  value={formTraspaso.mesaDestinoId} 
                  onChange={(e) => setFormTraspaso({...formTraspaso, mesaDestinoId: e.target.value})}
                  className="w-full bg-white dark:bg-ui-humo border-2 border-slate-200 dark:border-ui-border text-slate-800 dark:text-brand-nacar font-bold px-4 py-3.5 rounded-xl outline-none focus:border-rose-500 dark:focus:border-brand-arrecife"
                >
                  <option value="">-- Selecciona Mesa Destino --</option>
                  {mesas.filter(m => m.id !== modalTraspaso.mesaOrigen?.id).map(m => (
                    <option key={m.id} value={m.id}>{m.nombre} ({m.zona || 'Sin Área'}) {m.estado !== 'libre' ? '- Ocupada' : ''}</option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex justify-between items-end mb-3">
                  <label className="block text-[10px] font-black text-slate-500 dark:text-ui-muted uppercase tracking-widest">Selecciona los productos a mover</label>
                  <button onClick={seleccionarTodoTraspaso} className="text-[10px] font-black text-brand-amatista uppercase hover:underline">Seleccionar Todo</button>
                </div>
                <div className="space-y-2">
                  {(modalTraspaso.mesaOrigen?.orden_actual?.items || []).map((item, idx) => (
                    <div key={idx} onClick={() => toggleItemTraspaso(idx)} className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-colors ${
                      formTraspaso.itemsSeleccionados.includes(idx) ? 'bg-rose-50 dark:bg-brand-arrecife/10 border-rose-500 dark:border-brand-arrecife text-slate-900 dark:text-brand-nacar' : 'bg-white dark:bg-ui-obsidiana border-slate-200 dark:border-ui-border text-slate-500 dark:text-ui-muted hover:border-slate-300 dark:hover:border-ui-muted'
                    }`}>
                      {formTraspaso.itemsSeleccionados.includes(idx) ? <CheckSquare className="w-5 h-5 text-rose-500 dark:text-brand-arrecife" /> : <Square className="w-5 h-5" />}
                      <div className="flex-1 font-bold text-sm">{item.cantidad}x {item.nombre}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-6 border-t-2 border-slate-50 dark:border-ui-border flex gap-3 shrink-0">
              <button onClick={() => setModalTraspaso({show:false, mesaOrigen:null})} className="flex-1 py-4 bg-slate-100 dark:bg-ui-obsidiana text-slate-500 dark:text-ui-muted font-bold rounded-2xl border-2 border-transparent hover:border-slate-200 dark:hover:border-ui-border transition-colors">Cancelar</button>
              <button onClick={ejecutarTraspaso} className="flex-1 py-4 bg-rose-500 hover:bg-rose-600 dark:bg-brand-arrecife dark:hover:bg-orange-600 text-white dark:text-ui-obsidiana font-black rounded-2xl shadow-lg shadow-rose-500/20 dark:shadow-brand-arrecife/20 transition-transform active:scale-95">Ejecutar Traspaso</button>
            </div>
          </div>
        </div>
      )}

      {/* ─── MODAL: CREAR / EDITAR MESA ─── */}
      {modalMesa.show && (
        <div className="fixed inset-0 bg-slate-900/60 dark:bg-ui-obsidiana/80 backdrop-blur-md z-[100] flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-ui-humo rounded-[2.5rem] border-2 border-slate-100 dark:border-ui-border p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95">
            <div className="flex justify-between items-center mb-6 border-b-2 border-slate-50 dark:border-ui-border pb-4">
              <h2 className="text-xl font-black font-syne text-slate-900 dark:text-brand-nacar flex items-center gap-2">
                <LayoutGrid className="w-5 h-5 text-brand-amatista" /> 
                {modalMesa.mesa ? 'Editar Mesa y Área' : 'Añadir Nueva Mesa'}
              </h2>
              <button onClick={() => setModalMesa({show:false, mesa:null})} className="text-slate-400 dark:text-ui-muted hover:text-brand-arrecife p-1 rounded-lg"><X className="w-5 h-5"/></button>
            </div>

            <form onSubmit={guardarMesa} className="space-y-5">
              <div>
                <label className="block text-[10px] font-black text-slate-500 dark:text-ui-muted uppercase tracking-widest mb-2 pl-2">Identificador</label>
                <input type="text" required value={formDataMesa.nombre} onChange={(e) => setFormDataMesa({...formDataMesa, nombre: e.target.value})} className="w-full bg-slate-50 dark:bg-ui-obsidiana border-2 border-slate-200 dark:border-ui-border text-slate-800 dark:text-brand-nacar font-bold px-4 py-3.5 rounded-2xl outline-none focus:border-brand-amatista" placeholder="Ej: Mesa 1, VIP A..." />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black text-slate-500 dark:text-ui-muted uppercase tracking-widest mb-2 pl-2">Capacidad</label>
                  <input type="number" min="1" required value={formDataMesa.capacidad} onChange={(e) => setFormDataMesa({...formDataMesa, capacidad: e.target.value})} className="w-full bg-slate-50 dark:bg-ui-obsidiana border-2 border-slate-200 dark:border-ui-border text-slate-800 dark:text-brand-nacar font-bold px-4 py-3.5 rounded-2xl outline-none focus:border-brand-amatista text-center" />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-500 dark:text-ui-muted uppercase tracking-widest mb-2 pl-2">Zona / Área</label>
                  <input type="text" list="zonas-list" required value={formDataMesa.zona} onChange={(e) => setFormDataMesa({...formDataMesa, zona: e.target.value})} className="w-full bg-slate-50 dark:bg-ui-obsidiana border-2 border-slate-200 dark:border-ui-border text-slate-800 dark:text-brand-nacar font-bold px-4 py-3.5 rounded-2xl outline-none focus:border-brand-amatista" placeholder="Ej: Terraza"/>
                  <datalist id="zonas-list">{zonasUnicas.filter(z => z !== 'Todas').map(z => <option key={z} value={z} />)}</datalist>
                </div>
              </div>
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => setModalMesa({show:false, mesa:null})} className="flex-1 py-4 bg-slate-100 dark:bg-ui-obsidiana text-slate-500 dark:text-ui-muted font-bold rounded-2xl border-2 border-transparent hover:border-slate-200 dark:hover:border-ui-border transition-colors">Cancelar</button>
                <button type="submit" className="flex-1 py-4 bg-brand-amatista hover:bg-indigo-600 text-white dark:text-brand-nacar font-black rounded-2xl shadow-lg shadow-brand-amatista/20 active:scale-95 transition-all">Guardar</button>
              </div>
            </form>
          </div>
        </div>
      )}
      
    </div>
  );
}