import { useState, useMemo } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { useSyncStore } from '../../store/useSyncStore';
import { 
  Users, Plus, Search, Edit2, Trash2, Shield, 
  Mail, Smartphone, Key, DollarSign, X, CheckCircle 
} from 'lucide-react';

export default function EmpleadosScreen() {
  const { staff, upsertStaff, showToast, registrarAuditoria } = useAppStore();
  const { enqueueAction } = useSyncStore();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  
  // 🌟 FIX SUPABASE: Se usa "activo: true" (Booleano) en lugar de "estado: 'activo'"
  const initialState = {
    id: '',
    nombre: '',
    rol: 'Mesero',
    email: '',
    telefono: '',
    pin: '',
    sueldo_base: '',
    activo: true 
  };
  
  const [formData, setFormData] = useState(initialState);

  // ─── FILTRO DE BÚSQUEDA ──────────────────────────────────────────────────
  const empleadosFiltrados = useMemo(() => {
    if (!searchTerm) return staff || [];
    return (staff || []).filter(emp => 
      emp.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.rol.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [staff, searchTerm]);

  // ─── MANEJADORES DEL MODAL ───────────────────────────────────────────────
  const handleOpenModal = (empleado = null) => {
    if (empleado) {
      setFormData(empleado);
      setIsEditing(true);
    } else {
      setFormData(initialState);
      setIsEditing(false);
    }
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setFormData(initialState);
  };

  // ─── LÓGICA DE GUARDADO (CON SYNC Y AUDITORÍA) ───────────────────────────
  const handleSubmit = (e) => {
    e.preventDefault();

    if (formData.pin.length < 4) {
      return showToast('El PIN debe tener entre 4 y 6 dígitos numéricos', 'error');
    }

    const pinDuplicado = (staff || []).find(s => s.pin === formData.pin && String(s.id) !== String(formData.id));
    if (pinDuplicado) {
      return showToast('Ese PIN ya está siendo usado por otro empleado', 'error');
    }

    const empleadoGuardar = {
      ...formData,
      id: isEditing ? formData.id : `EMP-${Date.now()}`,
      sueldo_base: Number(formData.sueldo_base) || 0
    };

    enqueueAction('staff', isEditing ? 'upsert' : 'insert', empleadoGuardar);
    upsertStaff(empleadoGuardar);

    registrarAuditoria({
      id: Date.now(),
      fecha: new Date().toISOString(),
      usuario: 'Administrador',
      accion: isEditing ? 'EDICIÓN_EMPLEADO' : 'ALTA_EMPLEADO',
      modulo: 'RRHH',
      nivel: 'warning',
      detalles: `Empleado: ${empleadoGuardar.nombre} | Rol: ${empleadoGuardar.rol}`
    });

    showToast(`Empleado ${isEditing ? 'actualizado' : 'registrado'} con éxito`, 'success');
    handleCloseModal();
  };

  // 🌟 FIX SUPABASE: Alternar el booleano "activo"
  const handleToggleEstado = (empleado) => {
    const nuevoEstado = !empleado.activo;
    const empleadoActualizado = { ...empleado, activo: nuevoEstado };
    
    enqueueAction('staff', 'upsert', empleadoActualizado);
    upsertStaff(empleadoActualizado);
    showToast(`El empleado ahora está ${nuevoEstado ? 'activo' : 'dado de baja'}`, 'info');
  };

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto h-full animate-in fade-in duration-500 flex flex-col transition-colors">
      
      {/* ─── HEADER ─── */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-900 dark:text-brand-nacar tracking-tight flex items-center gap-3">
            <Users className="w-8 h-8 text-indigo-500" /> Plantilla de Personal
          </h1>
          <p className="text-sm font-bold text-slate-500 dark:text-ui-muted mt-1 uppercase tracking-widest">
            Gestiona accesos, roles y pines operativos
          </p>
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-black flex items-center gap-2 active:scale-95 transition-all shadow-lg shadow-indigo-600/30"
        >
          <Plus className="w-5 h-5" /> Nuevo Empleado
        </button>
      </div>

      {/* ─── BUSCADOR ─── */}
      <div className="bg-white dark:bg-ui-humo p-4 rounded-2xl border-2 border-slate-100 dark:border-ui-border shadow-sm mb-6 flex items-center gap-3 transition-colors">
        <Search className="w-5 h-5 text-slate-400 dark:text-ui-muted" />
        <input 
          type="text" 
          placeholder="Buscar por nombre o rol..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-transparent border-none outline-none font-bold text-slate-800 dark:text-brand-nacar placeholder:text-slate-400 dark:placeholder:text-ui-muted"
        />
      </div>

      {/* ─── GRID DE EMPLEADOS ─── */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 flex-1 overflow-y-auto custom-scrollbar pb-10">
        {empleadosFiltrados.length === 0 ? (
          <div className="col-span-full flex flex-col items-center justify-center text-slate-400 dark:text-ui-muted py-20">
            <Users className="w-16 h-16 mb-4 opacity-20" />
            <p className="font-bold text-lg">No se encontraron empleados</p>
          </div>
        ) : (
          empleadosFiltrados.map((emp) => (
            <div key={emp.id} className={`bg-white dark:bg-ui-humo rounded-3xl p-6 border-2 border-slate-100 dark:border-ui-border shadow-sm hover:border-indigo-300 dark:hover:border-brand-amatista transition-colors group ${emp.activo === false ? 'opacity-75' : ''}`}>
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-4">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center font-black text-xl text-white shadow-inner ${emp.activo !== false ? 'bg-indigo-500' : 'bg-slate-400 dark:bg-ui-obsidiana'}`}>
                    {emp.nombre.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 dark:text-brand-nacar text-lg leading-tight line-clamp-1">{emp.nombre}</h3>
                    <span className="text-xs font-bold uppercase tracking-widest text-indigo-500 dark:text-brand-amatista flex items-center gap-1 mt-1">
                      <Shield className="w-3 h-3" /> {emp.rol}
                    </span>
                  </div>
                </div>
              </div>

              <div className="space-y-3 mb-6 bg-slate-50 dark:bg-ui-obsidiana p-4 rounded-2xl border border-slate-100 dark:border-ui-border transition-colors">
                <div className="flex items-center gap-3 text-sm font-bold text-slate-600 dark:text-brand-nacar">
                  <Key className="w-4 h-4 text-slate-400 dark:text-ui-muted" /> PIN: <span className="text-slate-900 dark:text-brand-nacar tracking-widest bg-white dark:bg-ui-humo px-2 py-0.5 rounded-md border border-slate-200 dark:border-ui-border">••••</span>
                </div>
                {emp.telefono && (
                  <div className="flex items-center gap-3 text-sm font-bold text-slate-600 dark:text-brand-nacar">
                    <Smartphone className="w-4 h-4 text-slate-400 dark:text-ui-muted" /> {emp.telefono}
                  </div>
                )}
                {emp.email && (
                  <div className="flex items-center gap-3 text-sm font-bold text-slate-600 dark:text-brand-nacar line-clamp-1">
                    <Mail className="w-4 h-4 text-slate-400 dark:text-ui-muted" /> {emp.email}
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <button 
                  onClick={() => handleOpenModal(emp)}
                  className="flex-1 bg-slate-100 dark:bg-ui-obsidiana hover:bg-slate-200 dark:hover:bg-ui-border text-slate-700 dark:text-brand-nacar font-black py-2.5 rounded-xl text-sm flex items-center justify-center gap-2 transition-colors"
                >
                  <Edit2 className="w-4 h-4" /> Editar
                </button>
                <button 
                  onClick={() => handleToggleEstado(emp)}
                  className={`flex-1 font-black py-2.5 rounded-xl text-sm flex items-center justify-center gap-2 transition-colors border-2 ${
                    emp.activo !== false 
                    ? 'border-rose-100 dark:border-brand-arrecife/30 text-rose-500 hover:bg-rose-50 dark:hover:bg-brand-arrecife/10' 
                    : 'border-emerald-100 dark:border-brand-cesped/30 text-emerald-500 hover:bg-emerald-50 dark:hover:bg-brand-cesped/10'
                  }`}
                >
                  {emp.activo !== false ? <Trash2 className="w-4 h-4" /> : <CheckCircle className="w-4 h-4" />}
                  {emp.activo !== false ? 'Baja' : 'Reactivar'}
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* ─── MODAL ALTA/EDICIÓN ─── */}
      {showModal && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-slate-900/60 dark:bg-ui-obsidiana/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-ui-humo w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh] transition-colors">
            
            <div className="p-6 border-b border-slate-100 dark:border-ui-border flex justify-between items-center bg-slate-50 dark:bg-ui-obsidiana transition-colors">
              <h2 className="text-xl font-black text-slate-900 dark:text-brand-nacar flex items-center gap-2">
                {isEditing ? <Edit2 className="w-5 h-5 text-indigo-500" /> : <Plus className="w-5 h-5 text-indigo-500" />}
                {isEditing ? 'Editar Empleado' : 'Nuevo Empleado'}
              </h2>
              <button onClick={handleCloseModal} className="p-2 bg-white dark:bg-ui-humo rounded-full hover:bg-rose-50 dark:hover:bg-ui-border text-slate-400 dark:text-ui-muted transition-colors shadow-sm">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-6">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 dark:text-ui-muted uppercase tracking-widest px-2">Nombre Completo *</label>
                  <input type="text" required value={formData.nombre} onChange={e => setFormData({...formData, nombre: e.target.value})} 
                    className="w-full px-4 py-3.5 bg-slate-50 dark:bg-ui-obsidiana border-2 border-slate-100 dark:border-ui-border rounded-2xl font-bold text-slate-900 dark:text-brand-nacar outline-none focus:border-indigo-500 transition-colors" 
                    placeholder="Ej. Carlos Muñoz" />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 dark:text-ui-muted uppercase tracking-widest px-2">Rol Operativo *</label>
                  <select value={formData.rol} onChange={e => setFormData({...formData, rol: e.target.value})} 
                    className="w-full px-4 py-3.5 bg-slate-50 dark:bg-ui-obsidiana border-2 border-slate-100 dark:border-ui-border rounded-2xl font-bold text-slate-900 dark:text-brand-nacar outline-none focus:border-indigo-500 transition-colors cursor-pointer">
                    <option value="Administrador">Administrador</option>
                    <option value="Gerente">Gerente</option>
                    <option value="Cajero">Cajero</option>
                    <option value="Cocinero">Cocinero</option>
                    <option value="Barista">Barista</option>
                    <option value="Mesero">Mesero</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 dark:text-ui-muted uppercase tracking-widest px-2 flex justify-between">
                    <span>PIN Acceso (Caja/Reloj) *</span>
                    <span className="text-indigo-500 dark:text-brand-amatista">4 a 6 dígitos</span>
                  </label>
                  <div className="relative">
                    <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-ui-muted" />
                    <input type="password" required maxLength={6} value={formData.pin} 
                      onChange={e => setFormData({...formData, pin: e.target.value.replace(/\D/g, '')})} 
                      className="w-full pl-12 pr-4 py-3.5 bg-indigo-50/50 dark:bg-brand-amatista/10 border-2 border-indigo-100 dark:border-brand-amatista/30 rounded-2xl font-black text-indigo-700 dark:text-brand-amatista outline-none focus:border-indigo-500 transition-colors tracking-widest" 
                      placeholder="Ej. 1234" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 dark:text-ui-muted uppercase tracking-widest px-2">Sueldo Base (Mensual/Quincenal)</label>
                  <div className="relative">
                    <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-ui-muted" />
                    <input type="number" min="0" step="0.01" value={formData.sueldo_base} 
                      onChange={e => setFormData({...formData, sueldo_base: e.target.value})} 
                      className="w-full pl-12 pr-4 py-3.5 bg-slate-50 dark:bg-ui-obsidiana border-2 border-slate-100 dark:border-ui-border rounded-2xl font-bold text-slate-900 dark:text-brand-nacar outline-none focus:border-indigo-500 transition-colors" 
                      placeholder="0.00" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 dark:text-ui-muted uppercase tracking-widest px-2">Teléfono</label>
                  <input type="tel" value={formData.telefono} onChange={e => setFormData({...formData, telefono: e.target.value})} 
                    className="w-full px-4 py-3.5 bg-slate-50 dark:bg-ui-obsidiana border-2 border-slate-100 dark:border-ui-border rounded-2xl font-bold text-slate-900 dark:text-brand-nacar outline-none focus:border-indigo-500 transition-colors" 
                    placeholder="10 dígitos" />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 dark:text-ui-muted uppercase tracking-widest px-2">Correo (Opcional)</label>
                  <input type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} 
                    className="w-full px-4 py-3.5 bg-slate-50 dark:bg-ui-obsidiana border-2 border-slate-100 dark:border-ui-border rounded-2xl font-bold text-slate-900 dark:text-brand-nacar outline-none focus:border-indigo-500 transition-colors" 
                    placeholder="correo@ejemplo.com" />
                </div>
              </div>

              <div className="pt-6 border-t border-slate-100 dark:border-ui-border flex gap-3 transition-colors">
                <button type="button" onClick={handleCloseModal} className="flex-1 bg-slate-100 dark:bg-ui-obsidiana hover:bg-slate-200 dark:hover:bg-ui-border text-slate-700 dark:text-brand-nacar font-black py-4 rounded-xl transition-colors">
                  Cancelar
                </button>
                <button type="submit" className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-black py-4 rounded-xl active:scale-95 transition-all shadow-lg shadow-indigo-600/30">
                  Guardar Empleado
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}