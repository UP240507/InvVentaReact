import { useEffect } from 'react';
import { useSyncStore } from '../store/useSyncStore';

export function useNetworkListener() {
  const { setOfflineStatus, processQueue } = useSyncStore();

  useEffect(() => {
    const handleOnline = () => {
      setOfflineStatus(false);
      // Cuando regresa el internet, procesamos todo lo atascado
      processQueue(); 
    };

    const handleOffline = () => {
      setOfflineStatus(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Limpieza de eventos al desmontar
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [setOfflineStatus, processQueue]);
}