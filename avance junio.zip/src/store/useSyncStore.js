import { create } from 'zustand';
import { localDB } from './localDB';
import { supabase } from '../api/supabase';

export const useSyncStore = create((set, get) => ({
  isOffline: !navigator.onLine,
  isProcessingQueue: false,
  pendingTasks: 0,
  
  setOfflineStatus: (status) => set({ isOffline: status }),

  enqueueAction: async (tabla, metodo, data) => {
    // 1. Clon profundo para evitar mutaciones extrañas en React
    const payload = JSON.parse(JSON.stringify(data));
    
    const queueItem = {
      tabla,
      metodo,
      data: payload,
      estado: 'pending',
      fecha: new Date().toISOString(),
      createdAt: Date.now(),
      intentos: 0,
      nextAttemptAt: null,
      error: null
    };

    // 2. Mutación local inmediata (Optimistic UI)
    try {
      if (tabla === 'configuracion' && metodo === 'delete') {
         if (payload?.id) await localDB[tabla].delete(payload.id);
         else await localDB[tabla].clear();
      } else if (metodo === 'insert' || metodo === 'upsert' || metodo === 'update') {
        await localDB[tabla].put(payload);
      } else if (metodo === 'delete') {
        if (!payload?.id) throw new Error(`Se requiere data.id para eliminar en ${tabla}`);
        await localDB[tabla].delete(payload.id);
      }
    } catch (e) {
      console.error(`Error en mutación local (${tabla}):`, e);
    }

    // 3. Encolar
    await localDB.sync_queue.add(queueItem);
    set({ pendingTasks: await localDB.sync_queue.count() });

    // 4. Intentar procesar si hay internet
    if (!get().isOffline) {
      get().processQueue();
    }
  },

  processQueue: async () => {
    const state = get();
    if (state.isProcessingQueue || state.isOffline) return;

    const MAX_ATTEMPTS = 5;
    const BASE_BACKOFF_MS = 1000; // 1s
    const MAX_BACKOFF_MS = 60 * 1000; // 60s
    
    set({ isProcessingQueue: true });
    let processedCount = 0;

    try {
      // Ordenar por createdAt para mantener el orden de creación
      const pendingItems = await localDB.sync_queue.orderBy('createdAt').toArray();
      
      for (const item of pendingItems) {
        if (item.estado === 'done') continue;
        
        const now = Date.now();
        // Saltar items que tienen programado un reintento en el futuro
        if (item.nextAttemptAt && item.nextAttemptAt > now) continue;

        try {
          await localDB.sync_queue.update(item.id, { estado: 'processing', error: null });
          
          let query = supabase.from(item.tabla);
          let res;
          
          if (item.tabla === 'configuracion' && item.metodo === 'delete') {
              res = await query.delete().eq('id', item.data.id);
          } else if (item.metodo === 'insert') {
              res = await query.insert(item.data);
          } else if (item.metodo === 'upsert' || item.metodo === 'update') {
              res = await query.upsert(item.data);
          } else if (item.metodo === 'delete') {
              res = await query.delete().eq('id', item.data.id);
          } else {
              throw new Error(`Método remoto no soportado: ${item.metodo}`);
          }
          
          if (res?.error) throw res.error;
          
          // Si pasó en la nube, lo borramos de la cola
          await localDB.sync_queue.delete(item.id);
          processedCount++;
          
        } catch (error) {
          console.error(`Error sincronizando tarea ${item.id}:`, error);
          const attempts = (item.intentos || 0) + 1;
          
          if (attempts >= MAX_ATTEMPTS) {
            // Mover a dead-letter para inspección manual
            try {
              await localDB.sync_dead.add({ ...item, estado: 'dead', intentos: attempts, lastError: error?.message || 'Error de red', fecha_error: new Date().toISOString() });
              await localDB.sync_queue.delete(item.id);
            } catch (e) {
              console.error('Error moviendo item a sync_dead:', e);
              // Si falló mover, marcamos como error y seguimos
              await localDB.sync_queue.update(item.id, {
                estado: 'error',
                intentos: attempts,
                error: error?.message || 'Error de red',
                fecha_error: new Date().toISOString()
              });
            }
          } else {
            // Exponencial backoff antes del siguiente intento
            const backoff = Math.min(BASE_BACKOFF_MS * (2 ** (attempts - 1)), MAX_BACKOFF_MS);
            const nextAttemptAt = Date.now() + backoff;
            await localDB.sync_queue.update(item.id, {
              estado: 'error',
              intentos: attempts,
              error: error?.message || 'Error de red',
              fecha_error: new Date().toISOString(),
              nextAttemptAt
            });
          }
        }
      }
    } finally {
      const remaining = await localDB.sync_queue.count();
      set({ isProcessingQueue: false, pendingTasks: remaining });
    }
  }
}));