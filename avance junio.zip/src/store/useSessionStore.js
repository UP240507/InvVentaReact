import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { useAppStore } from './useAppStore';

// ─── RUTAS PERMITIDAS POR ROL ─────────────────────────────────────────────────
export const RUTAS_POR_ROL = {
  Administrador: '*', // alias común en BD
  Admin: '*', // acceso total
  Gerente: [
    'dashboard',
    'mesas',
    'pos',
    'kds',
    'propinas',
    'ingredientes',
    'compras',
    'recepcion',
    'mermas',
    'proveedores',
    'empleados',
    'asistencias',
    'nominas',
    'permisos',
    'clientes',
    'reportes',
    'facturas',
    'zonas-produccion',
    'auditoria',
    'perfil',
    'configuracion',
  ],
  Cajero: ['pos', 'mesas', 'facturas', 'perfil', 'espera'],
  Mesero: ['mesas', 'pos', 'perfil', 'espera'],
  Chef: ['kds', 'perfil', 'espera'],
  Cocinero: ['kds', 'perfil', 'espera'],
  Barista: ['kds', 'perfil', 'espera'],
};

// Ruta de aterrizaje al entrar según rol
export const RUTA_INICIAL_POR_ROL = {
  Administrador: '/dashboard',
  Admin: '/dashboard',
  Gerente: '/dashboard',
  Cajero: '/pos',
  Mesero: '/mesas',
  Chef: '/kds',
  Cocinero: '/kds',
  Barista: '/kds',
};

export const useSessionStore = create(
  persist(
    (set, get) => ({
      // ── ESTADO DE EMPLEADO (RBAC) ───────────────────────────────────────
      empleadoActivo: null,
      horaEntrada: null,

      // ── ESTADO DE TURNO DE CAJA ─────────────────────────────────────────
      turnoActivo: null,

      // ── ABRIR / CERRAR SESIÓN DE EMPLEADO (Checador) ────────────────────
      abrirSesionEmpleado: (empleado) => {
        set({
          empleadoActivo: empleado,
          horaEntrada: new Date().toISOString(),
        });
      },

      cerrarSesionEmpleado: () => {
        set({ empleadoActivo: null, horaEntrada: null });
      },

      // ── ABRIR / CERRAR TURNO DE CAJA (Dashboard) ────────────────────────
      abrirTurno: (turnoData) => {
        set({ turnoActivo: turnoData });
      },

      cerrarTurno: () => {
        set({ turnoActivo: null });
      },

      // ── GUARDIA: ¿puede el empleado acceder a esta ruta? ────────────────
      puedeAcceder: (ruta) => {
        const { empleadoActivo } = get();
        if (!empleadoActivo) return false;

        // 🌟 FIX: Validamos rol y puesto para ser a prueba de balas
        const rol = empleadoActivo.rol || empleadoActivo.puesto || 'Mesero';

        if (['Administrador', 'Admin'].includes(rol)) return true;

        const rutaLimpia = ruta.replace(/^\//, '').split('/')[0] || 'dashboard';
        const permitidas = RUTAS_POR_ROL[rol] || RUTAS_POR_ROL['Mesero'];

        if (permitidas === '*') return true;

        return permitidas.includes(rutaLimpia);
      },

      // ── GUARDIA: ¿hay turno de caja abierto? ────────────────────────────
      hayTurnoActivo: () => {
        const { empleadoActivo, turnoActivo } = get();
        if (!empleadoActivo) return false;

        const rol = empleadoActivo.rol || empleadoActivo.puesto || 'Mesero';

        // Admin y Gerente bypasean esta validación
        if (['Administrador', 'Admin', 'Gerente'].includes(rol)) return true;

        // Validamos el turno local de la terminal primero.
        if (turnoActivo) return true;

        // Fallback a la base de datos local
        const turnosBD = useAppStore.getState().turnos || [];
        const hayTurnoEnBD = turnosBD.some((t) => t.estado === 'abierto');

        return hayTurnoEnBD;
      },

      // ── HELPER: ruta inicial según rol del empleado ──────────────────────
      getRutaInicial: () => {
        const { empleadoActivo } = get();
        if (!empleadoActivo) return '/checador';

        const rol = empleadoActivo.rol || empleadoActivo.puesto || 'Mesero';
        return RUTA_INICIAL_POR_ROL[rol] || '/mesas';
      },
    }),
    {
      name: 'session-empleado',
      partialize: (state) => ({
        empleadoActivo: state.empleadoActivo,
        horaEntrada: state.horaEntrada,
        turnoActivo: state.turnoActivo,
      }),
    },
  ),
);
