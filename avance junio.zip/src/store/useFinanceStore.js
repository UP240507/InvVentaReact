// src/features/finanzas/useFinanceStore.js
// Hoy: registra ventas en RAM.
// Al conectar Supabase: registrarVenta() inserta en tabla 'ventas' y llama al RPC decrementar_stock.
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export const useFinanceStore = create(
    persist(
        (set, get) => ({
            ventas: [], // Shape: ver types.js → Venta

            registrarVenta: (datos) => {
                const { subtotal, ivaAmt, propinaAmt, total, metodoPago, items } = datos;
                const venta = {
                    id: Date.now(),
                    folio: `POS-${Date.now().toString().slice(-5)}`,
                    subtotal,
                    iva: ivaAmt,
                    propina: propinaAmt ?? 0,
                    total,
                    metodo_pago: metodoPago,
                    usuario: 'Sistema', // TODO: usar useAuthStore().user.nombre
                    items: items.map(i => ({
                        recetaId: i.receta.id,
                        nombre:   i.receta.nombre,
                        cantidad: i.cantidad,
                        precio:   i.precioUnit,
                        subtotal: i.subtotal,
                    })),
                    fecha: new Date().toISOString(),
                };
                set(state => ({ ventas: [venta, ...state.ventas] }));
                return venta;
            },

            realizarCorteZ: () => {
                set({ ventas: [] });
            },

            // Getters para Dashboard
            getResumenHoy: () => {
                const { ventas } = get();
                const hoy = new Date().toDateString();
                const ventasHoy = ventas.filter(v => new Date(v.fecha).toDateString() === hoy);
                return {
                    count:     ventasHoy.length,
                    total:     ventasHoy.reduce((s, v) => s + v.total, 0),
                    subtotal:  ventasHoy.reduce((s, v) => s + v.subtotal, 0),
                    iva:       ventasHoy.reduce((s, v) => s + (v.iva ?? 0), 0),
                    propinas:  ventasHoy.reduce((s, v) => s + (v.propina ?? 0), 0),
                    efectivo:  ventasHoy.filter(v => v.metodo_pago === 'efectivo').reduce((s, v) => s + v.total, 0),
                    tarjeta:   ventasHoy.filter(v => v.metodo_pago === 'tarjeta').reduce((s, v) => s + v.total, 0),
                    ticketProm: ventasHoy.length > 0 ? (ventasHoy.reduce((s, v) => s + v.total, 0) / ventasHoy.length) : 0,
                };
            },
        }),
        { name: 'invventa-finanzas' }
    )
);
