import Dexie from 'dexie';

export const localDB = new Dexie('invVentaDB');

// Versiones previas intactas para no perder datos de usuarios en producción
localDB.version(1).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, fecha'
});

localDB.version(2).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, fecha'
});

localDB.version(3).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt'
});

localDB.version(4).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt'
});

localDB.version(5).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id'
});

localDB.version(6).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id'
});

localDB.version(7).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id', nominas: 'id'
});

localDB.version(8).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id', nominas: 'id',
    roles_permisos: 'rol'   // PK original (se migra en v13)
});

localDB.version(9).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id', nominas: 'id', roles_permisos: 'rol', clientes: 'id'
});

localDB.version(10).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id', nominas: 'id', roles_permisos: 'rol', clientes: 'id',
    auditoria: 'id'
});

localDB.version(11).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id', nominas: 'id', roles_permisos: 'rol', clientes: 'id',
    auditoria: 'id', asistencias: 'id'
});

localDB.version(12).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id', nominas: 'id', roles_permisos: 'rol', clientes: 'id',
    auditoria: 'id', asistencias: 'id', comandas: 'id'
});

// ✅ FIX #4: roles_permisos migra su PK de 'rol' → 'id'
// El enqueueAction hacía localDB.roles_permisos.delete(payload.id) pero el PK era 'rol',
// causando que ningún borrado de permisos se aplicara offline.
// REQUISITO: la tabla roles_permisos en Supabase debe tener columna 'id' (uuid o serial).
localDB.version(13).stores({
    configuracion: 'id', productos: 'id', recetas: 'id', mesas: 'id', ventas: 'id',
    movimientos: 'id', ordenes_compra: 'id', proveedores: 'id', usuarios: 'id', turnos: 'id',
    sync_queue: '++id, tabla, metodo, estado, fecha, createdAt, nextAttemptAt, intentos',
    facturas: '++id, folio_venta, rfc_receptor, fecha_emision, estado',
    sync_dead: '++id, tabla, metodo, estado, createdAt',
    modificadores: 'id', staff: 'id', nominas: 'id',
    roles_permisos: 'id, rol',  // ✅ PK = id; 'rol' queda como índice secundario
    clientes: 'id',
    auditoria: 'id', asistencias: 'id', comandas: 'id'
}).upgrade(tx => {
    // Dexie reescribirá la tabla con el nuevo PK automáticamente.
    // Los registros sin campo 'id' quedarán con id autogenerado (Dexie asigna undefined→auto).
    console.log('🔄 [DB v13] Migrando roles_permisos PK: rol → id');
});