import { useEffect } from 'react';
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  Outlet,
  useLocation,
} from 'react-router-dom';
import { useAppStore } from './store/useAppStore';
import { useAuthStore } from './features/auth/useAuthStore';
import { useSessionStore } from './store/useSessionStore';
import { useNetworkListener } from './hooks/useNetworkListener';

// Layout
import SidebarLayout from './components/SidebarLayout';

// Pantallas públicas
import LoginScreen from './features/auth/LoginScreen';
import RelojChecadorScreen from './features/rh/RelojChecadorScreen';
import EsperaScreen from './features/operacion/EsperaScreen';
import PaywallScreen from './features/suscripciones/PaywallScreen';

// Pantallas protegidas
import PerfilScreen from './features/auth/PerfilScreen';
import DashboardScreen from './features/dashboard/DashboardScreen';
import MesasScreen from './features/operacion/MesasScreen';
import PosScreen from './features/pos/PosScreen';
import KdsScreen from './features/kds/KdsScreen';
import PropineroScreen from './features/operacion/PropineroScreen';
import RecetasScreen from './features/catalogos/RecetasScreen';
import ModificadoresScreen from './features/catalogos/ModificadoresScreen';
import IngredientesScreen from './features/catalogos/IngredientesScreen';
import ComprasScreen from './features/compras/ComprasScreen';
import RecepcionScreen from './features/compras/RecepcionScreen';
import MermasScreen from './features/inventario/MermasScreen';
import ProveedoresScreen from './features/inventario/ProveedoresScreen';
import EmpleadosScreen from './features/rh/EmpleadosScreen';
import NominasScreen from './features/rh/NominasScreen';
import PermisosScreen from './features/rh/PermisosScreen';
import ClientesScreen from './features/crm/ClientesScreen';
import ReportesScreen from './features/analisis/ReportesScreen';
import FacturasScreen from './features/analisis/FacturasScreen';
import ConfiguracionScreen from './features/ajustes/ConfiguracionScreen';
import AuditoriaScreen from './features/ajustes/AuditoriaScreen';
import ZonasImpresionScreen from './features/ajustes/ZonasImpresionScreen';
import BillingScreen from './features/suscripciones/BillingScreen';

// ─── GUARD 1: Supabase Auth ───────────────────────────────────────────────────
function AdminRoute() {
  const user = useAuthStore((s) => s.user);
  const authLoading = useAuthStore((s) => s.isLoading);
  if (authLoading) return null;
  return user ? <Outlet /> : <Navigate to="/login" replace />;
}

// ─── GUARD 2: Suscripción activa ──────────────────────────────────────────────
function SuscripcionRoute() {
  const suscripcion = useAuthStore((s) => s.suscripcion);
  const isLoading = useAuthStore((s) => s.isLoading);
  if (isLoading) return null;
  if (!suscripcion) return <Navigate to="/paywall" replace />;
  return <Outlet />;
}

// ─── GUARD 3: Empleado con PIN validado ───────────────────────────────────────
function EmpleadoRoute() {
  const { empleadoActivo, puedeAcceder } = useSessionStore();
  const { user } = useAuthStore();
  const location = useLocation();

  // Admin y Gerente de Supabase Auth nunca necesitan PIN
  if (['Admin', 'Gerente'].includes(user?.rol)) return <Outlet />;

  if (!empleadoActivo) return <Navigate to="/checador" replace />;
  if (!puedeAcceder(location.pathname))
    return <Navigate to="/perfil" replace />;
  return <Outlet />;
}

// ─── GUARD 4: Turno de caja abierto ──────────────────────────────────────────
function TurnoRoute() {
  const { empleadoActivo } = useSessionStore();
  const { user } = useAuthStore();
  const turnos = useAppStore((s) => s.turnos);

  // Admin y Gerente nunca necesitan turno
  const rol =
    empleadoActivo?.rol || empleadoActivo?.puesto || user?.rol || 'Mesero';
  if (['Admin', 'Gerente'].includes(rol)) return <Outlet />;

  const hayTurno = (turnos || []).some((t) => t.estado === 'abierto');
  return hayTurno ? <Outlet /> : <Navigate to="/espera" replace />;
}

// ─── APP ─────────────────────────────────────────────────────────────────────
export default function App() {
  useNetworkListener();

  const checkSession = useAuthStore((s) => s.checkSession);
  const authLoading = useAuthStore((s) => s.isLoading);
  const dataLoading = useAppStore((s) => s.isLoading);

  useEffect(() => {
    const isDark =
      localStorage.getItem('theme') === 'dark' ||
      (!('theme' in localStorage) &&
        window.matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.classList.toggle('dark', isDark);
  }, []);

  useEffect(() => {
    if (checkSession) checkSession();
  }, [checkSession]);

  return (
    <div className="bg-slate-100 dark:bg-ui-obsidiana min-h-screen transition-colors duration-500 font-sans">
      {/* Spinner global como overlay — el BrowserRouter nunca se desmonta */}
      {(authLoading || dataLoading) && (
        <div className="fixed inset-0 z-[999] bg-slate-100 dark:bg-ui-obsidiana flex flex-col items-center justify-center">
          <div className="w-12 h-12 border-4 border-brand-arrecife border-t-transparent rounded-full animate-spin mb-4" />
          <h2 className="text-xl font-bold font-syne tracking-widest uppercase text-slate-800 dark:text-brand-nacar">
            Cargando...
          </h2>
        </div>
      )}

      <BrowserRouter>
        <Routes>
          {/* ── RUTAS PÚBLICAS ── */}
          <Route path="/login" element={<LoginScreen />} />
          <Route path="/checador" element={<RelojChecadorScreen />} />
          <Route path="/espera" element={<EsperaScreen />} />
          <Route path="/paywall" element={<PaywallScreen />} />

          {/* ── RUTAS PROTEGIDAS ── */}
          <Route element={<AdminRoute />}>
            <Route element={<SuscripcionRoute />}>
              <Route element={<SidebarLayout />}>
                <Route element={<EmpleadoRoute />}>
                  {/* Sin restricción de turno */}
                  <Route path="/perfil" element={<PerfilScreen />} />
                  <Route path="/dashboard" element={<DashboardScreen />} />
                  <Route
                    path="/asistencias"
                    element={<RelojChecadorScreen />}
                  />
                  <Route path="/empleados" element={<EmpleadosScreen />} />
                  <Route path="/nominas" element={<NominasScreen />} />
                  <Route path="/permisos" element={<PermisosScreen />} />
                  <Route path="/clientes" element={<ClientesScreen />} />
                  <Route path="/reportes" element={<ReportesScreen />} />
                  <Route path="/facturas" element={<FacturasScreen />} />
                  <Route path="/recetas" element={<RecetasScreen />} />
                  <Route
                    path="/modificadores"
                    element={<ModificadoresScreen />}
                  />
                  <Route
                    path="/ingredientes"
                    element={<IngredientesScreen />}
                  />
                  <Route path="/compras" element={<ComprasScreen />} />
                  <Route path="/recepcion" element={<RecepcionScreen />} />
                  <Route path="/mermas" element={<MermasScreen />} />
                  <Route path="/proveedores" element={<ProveedoresScreen />} />
                  <Route
                    path="/zonas-produccion"
                    element={<ZonasImpresionScreen />}
                  />
                  <Route path="/auditoria" element={<AuditoriaScreen />} />
                  <Route
                    path="/configuracion"
                    element={<ConfiguracionScreen />}
                  />
                  <Route path="/mi-plan" element={<BillingScreen />} />

                  {/* Con guard de turno de caja */}
                  <Route element={<TurnoRoute />}>
                    <Route path="/mesas" element={<MesasScreen />} />
                    <Route path="/pos" element={<PosScreen />} />
                    <Route path="/kds" element={<KdsScreen />} />
                    <Route path="/propinas" element={<PropineroScreen />} />
                  </Route>
                </Route>

                {/* Redirects */}
                <Route
                  path="/"
                  element={<Navigate to="/dashboard" replace />}
                />
                <Route
                  path="/inventario"
                  element={<Navigate to="/ingredientes" replace />}
                />
                <Route
                  path="*"
                  element={<Navigate to="/dashboard" replace />}
                />
              </Route>
            </Route>
          </Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}
